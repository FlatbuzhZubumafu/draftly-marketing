/**
 * Draftly admin screens: Check / Optimize / Approve / Revert on the posts list,
 * and the connect poll on the Connection screen. Plain DOM, no build step.
 * All text from Draftly is inserted with textContent, never as HTML, and the
 * only links built from a response are https links the PHP side has already
 * checked are on a Draftly host.
 */
( function () {
	'use strict';

	var cfg = window.draftlyAdmin;
	if ( ! cfg ) {
		return;
	}
	var t = cfg.i18n;

	function post( action, data ) {
		var body = new FormData();
		body.append( 'action', 'draftly_' + action );
		body.append( 'nonce', cfg.nonce );
		Object.keys( data || {} ).forEach( function ( key ) {
			var value = data[ key ];
			if ( Array.isArray( value ) ) {
				value.forEach( function ( v ) {
					body.append( key + '[]', v );
				} );
			} else {
				body.append( key, value );
			}
		} );
		return fetch( cfg.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: body } )
			.then( function ( res ) {
				return res.json().catch( function () {
					return { success: false, data: { message: t.error } };
				} );
			} )
			.then( function ( json ) {
				if ( ! json || ! json.success ) {
					var err = new Error( ( json && json.data && json.data.message ) || t.error );
					// Code, numbers and links for the error notice's buttons.
					err.data = ( json && json.data ) || {};
					throw err;
				}
				return json.data;
			} );
	}

	// "%s credits left." / "This needs %1$s credits and you have %2$s."
	function fmt( text ) {
		var args = Array.prototype.slice.call( arguments, 1 );
		var i = 0;
		return String( text ).replace( /%(\d+)\$s|%s/g, function ( match, n ) {
			var value = n ? args[ Number( n ) - 1 ] : args[ i++ ];
			return value === undefined ? match : String( value );
		} );
	}

	function number( n ) {
		return Number( n ).toLocaleString();
	}

	function safeLink( url ) {
		return typeof url === 'string' && /^https:\/\//.test( url ) ? url : '';
	}

	function el( tag, attrs, text ) {
		var node = document.createElement( tag );
		Object.keys( attrs || {} ).forEach( function ( key ) {
			node.setAttribute( key, attrs[ key ] );
		} );
		if ( text !== undefined && text !== null ) {
			node.textContent = String( text );
		}
		return node;
	}

	// Suggestions arrive as Markdown sentences; show them as readers see them.
	function plain( md ) {
		return String( md || '' )
			.replace( /\[([^\]]*)\]\([^)\s]+\)/g, '$1' )
			.replace( /\*\*([^*]+)\*\*|__([^_]+)__/g, '$1$2' )
			.replace( /`([^`]+)`/g, '$1' )
			.replace( /(^|\s)[*_]([^*_\s][^*_]*)[*_]/g, '$1$2' );
	}

	/**
	 * Shows one notice on Draftly's own screen. `extra.lines` are further
	 * sentences; `extra.actions` are buttons: { label, href } opens a Draftly
	 * page in a new tab, { label, onClick } runs in place.
	 */
	function notice( message, type, extra ) {
		var box = document.getElementById( 'draftly-notice' );
		if ( ! box ) {
			return;
		}
		box.textContent = '';
		if ( ! message ) {
			return;
		}
		extra = extra || {};
		var div = el( 'div', { class: 'notice notice-' + ( type || 'info' ) + ' draftly-notice' } );
		div.appendChild( el( 'p', {}, message ) );
		( extra.lines || [] ).forEach( function ( line ) {
			if ( line ) {
				div.appendChild( el( 'p', { class: 'draftly-notice-detail' }, line ) );
			}
		} );
		var actions = ( extra.actions || [] ).filter( function ( a ) {
			return a && a.label && ( a.onClick || safeLink( a.href ) );
		} );
		if ( actions.length ) {
			var row = el( 'p', { class: 'draftly-notice-actions' } );
			actions.forEach( function ( a, i ) {
				var node;
				if ( a.onClick ) {
					node = el( 'button', { type: 'button', class: 'button' + ( i === 0 ? ' button-primary' : '' ) }, a.label );
					node.addEventListener( 'click', a.onClick );
				} else {
					node = el( 'a', { class: 'button' + ( i === 0 ? ' button-primary' : '' ), href: safeLink( a.href ), target: '_blank', rel: 'noopener noreferrer' }, a.label );
					node.appendChild( el( 'span', { class: 'screen-reader-text' }, ' ' + t.newTab ) );
				}
				row.appendChild( node );
				row.appendChild( document.createTextNode( ' ' ) );
			} );
			div.appendChild( row );
		}
		box.appendChild( div );
	}

	// What a finished run cost and what is left, e.g. "2 credits used. 948 credits left."
	function usageNote( data ) {
		var parts = [];
		parts.push( data.charged ? fmt( t.creditsUsed, number( data.charged ) ) : t.noCharge );
		if ( data.allowance_left ) {
			parts.push( fmt( t.allowanceLeft, data.allowance_left ) );
		}
		if ( data.credits_remaining !== null && data.credits_remaining !== undefined ) {
			parts.push( fmt( t.creditsLeft, number( data.credits_remaining ) ) );
		}
		return parts.join( ' ' );
	}

	/**
	 * Turns a failed request into a notice that says what happened and what to
	 * do: top up or see plans when credits run out, try again when it may work
	 * next time, and a reference to quote to support.
	 */
	function showError( e, retry ) {
		var d = ( e && e.data ) || {};
		var code = d.code || '';
		var lines = [];
		var actions = [];
		renderFreePosts( d );
		if ( code === 'free_limit_reached' ) {
			// The free plugin's posts are used up: plans first, top-up credits also work.
			lines.push( t.notCharged );
			actions.push( { label: t.seePlans, href: safeLink( d.upgrade_url ) || cfg.plansUrl } );
			actions.push( { label: t.topUp, href: safeLink( d.top_up_url ) || cfg.topUpUrl } );
		} else if ( code === 'insufficient_credits' || code === 'allowance_exhausted' ) {
			// Draftly's message already has the numbers ("This needs 2 credits and you have 0.").
			lines.push( t.notCharged );
			actions.push( { label: t.topUp, href: safeLink( d.top_up_url ) || cfg.topUpUrl } );
			actions.push( { label: t.seePlans, href: safeLink( d.upgrade_url ) || cfg.plansUrl } );
		} else if ( code === 'revoked' || code === 'not_verified' || code === 'draftly_not_connected' ) {
			if ( cfg.connectionUrl ) {
				actions.push( { label: t.openConnection, onClick: function () {
					window.location.href = cfg.connectionUrl;
				} } );
			}
		} else if ( code !== 'too_long' && code !== 'empty' && code !== 'model_not_allowed' && code !== 'not_found' ) {
			// Failures that may work next time, including network errors and timeouts.
			if ( d.retryable !== false && retry ) {
				actions.push( { label: t.tryAgain, onClick: retry } );
			}
			if ( d.request_id ) {
				lines.push( fmt( t.support, t.supportEmail, d.request_id ) );
			}
		}
		notice( ( e && e.message ) || t.error, 'error', { lines: lines, actions: actions } );
	}

	// "Free: 3 of 5 posts used" above the list, when Draftly reports a free-posts counter.
	function renderFreePosts( data ) {
		var line = document.getElementById( 'draftly-free-posts' );
		if ( ! line || ! data || typeof data.free_posts_limit !== 'number' || typeof data.free_posts_used !== 'number' ) {
			return;
		}
		line.textContent = fmt( t.freePosts, number( Math.min( data.free_posts_used, data.free_posts_limit ) ), number( data.free_posts_limit ) );
		line.hidden = false;
	}

	function renderScores( postId, scores ) {
		var cell = document.querySelector( '.draftly-scores[data-post="' + postId + '"]' );
		if ( ! cell || ! scores ) {
			return;
		}
		cell.textContent = '';
		[ 'humanVoice', 'readability' ].forEach( function ( key ) {
			if ( scores[ key ] === null || scores[ key ] === undefined ) {
				return;
			}
			var value = Math.round( scores[ key ] );
			var tone = value >= 80 ? 'good' : value >= 60 ? 'ok' : 'low';
			cell.appendChild( el( 'span', { class: 'draftly-score draftly-score-' + tone }, t.scoreLabels[ key ] + ' ' + value ) );
			cell.appendChild( document.createTextNode( ' ' ) );
		} );
	}

	function setBusy( button, busy, label ) {
		var row = button.closest( 'tr' );
		( row ? row.querySelectorAll( '.draftly-action' ) : [ button ] ).forEach( function ( b ) {
			b.disabled = busy;
		} );
		if ( busy ) {
			notice( label, 'info' );
		}
	}

	function closeReview() {
		var panel = document.getElementById( 'draftly-review' );
		panel.hidden = true;
		panel.textContent = '';
	}

	function showReview( postId, data, button ) {
		var panel = document.getElementById( 'draftly-review' );
		panel.textContent = '';
		panel.hidden = false;
		panel.appendChild( el( 'h2', {}, data.post_title ) );
		panel.appendChild( el( 'p', { class: 'description' }, usageNote( data ) ) );
		if ( ! data.changes.length ) {
			panel.appendChild( el( 'p', {}, t.noChanges ) );
			var close = el( 'button', { type: 'button', class: 'button' }, t.discard );
			close.addEventListener( 'click', closeReview );
			panel.appendChild( close );
			return;
		}
		var list = el( 'ol', { class: 'draftly-changes' } );
		data.changes.forEach( function ( change ) {
			var item = el( 'li', { class: 'draftly-change' } );
			var label = el( 'label' );
			var box = el( 'input', { type: 'checkbox', value: change.id } );
			box.checked = true;
			label.appendChild( box );
			label.appendChild( el( 'strong', {}, ' ' + ( change.rule || '' ) ) );
			if ( change.reason ) {
				label.appendChild( el( 'span', { class: 'draftly-muted' }, ' ' + change.reason ) );
			}
			item.appendChild( label );
			var before = el( 'div', { class: 'draftly-before' } );
			before.appendChild( el( 'span', { class: 'draftly-tag' }, t.before ) );
			before.appendChild( el( 'del', {}, plain( change.before ) ) );
			var after = el( 'div', { class: 'draftly-after' } );
			after.appendChild( el( 'span', { class: 'draftly-tag' }, t.after ) );
			after.appendChild( el( 'ins', {}, plain( change.after ) ) );
			item.appendChild( before );
			item.appendChild( after );
			list.appendChild( item );
		} );
		panel.appendChild( list );

		var approve = el( 'button', { type: 'button', class: 'button button-primary' }, t.approve );
		var discard = el( 'button', { type: 'button', class: 'button' }, t.discard );
		approve.addEventListener( 'click', function () {
			var accepted = Array.prototype.map.call( panel.querySelectorAll( 'input[type=checkbox]:checked' ), function ( b ) {
				return b.value;
			} );
			approve.disabled = true;
			discard.disabled = true;
			notice( t.applying, 'info' );
			post( 'apply', { post_id: postId, document_id: data.document_id, accepted: accepted } )
				.then( function ( res ) {
					renderScores( postId, res.scores );
					closeReview();
					notice( t.saved, 'success' );
				} )
				.catch( function ( e ) {
					approve.disabled = false;
					discard.disabled = false;
					showError( e, function () {
						approve.click();
					} );
				} );
		} );
		discard.addEventListener( 'click', function () {
			closeReview();
			notice( '' );
			button.focus();
		} );
		var actions = el( 'p', { class: 'draftly-review-actions' } );
		actions.appendChild( approve );
		actions.appendChild( document.createTextNode( ' ' ) );
		actions.appendChild( discard );
		panel.appendChild( actions );
		panel.scrollIntoView( { behavior: 'smooth', block: 'start' } );
	}

	function runAction( button ) {
		var postId = button.getAttribute( 'data-post' );
		var action = button.getAttribute( 'data-action' );
		var label = action === 'check' ? t.checking : action === 'optimize' ? t.optimizing : t.reverting;
		setBusy( button, true, label );
		post( action, { post_id: postId } )
			.then( function ( data ) {
				renderFreePosts( data );
				if ( action === 'check' ) {
					renderScores( postId, data.scores );
					notice( t.checked + ' ' + usageNote( data ), 'success' );
				} else if ( action === 'optimize' ) {
					notice( '' );
					showReview( postId, data, button );
				} else {
					notice( t.reverted, 'success' );
					button.remove();
					var cell = document.querySelector( '.draftly-scores[data-post="' + postId + '"]' );
					if ( cell ) {
						cell.textContent = '';
					}
				}
			} )
			.catch( function ( e ) {
				showError( e, action === 'revert' ? null : function () {
					runAction( button );
				} );
			} )
			.then( function () {
				setBusy( button, false );
			} );
	}

	document.addEventListener( 'click', function ( event ) {
		var button = event.target.closest( '.draftly-action' );
		if ( ! button ) {
			return;
		}
		if ( button.getAttribute( 'data-action' ) === 'revert' && ! window.confirm( t.confirmRevert ) ) {
			return;
		}
		runAction( button );
	} );

	// Confirm before destructive forms (Disconnect).
	document.querySelectorAll( 'form.draftly-confirm' ).forEach( function ( form ) {
		form.addEventListener( 'submit', function ( event ) {
			if ( ! window.confirm( form.getAttribute( 'data-confirm' ) ) ) {
				event.preventDefault();
			}
		} );
	} );

	// Connection screen: poll while the admin approves in the Draftly tab.
	var status = document.getElementById( 'draftly-connect-status' );
	var form = document.getElementById( 'draftly-connect-form' );
	var timer = null;
	var tries = 0;
	function poll() {
		tries++;
		post( 'poll', {} )
			.then( function ( data ) {
				if ( data.status === 'approved' ) {
					status.textContent = t.connected;
					window.clearInterval( timer );
					window.setTimeout( function () {
						window.location.reload();
					}, 800 );
				} else if ( data.status === 'denied' || data.status === 'expired' || data.status === 'none' ) {
					window.clearInterval( timer );
					status.textContent = data.status === 'denied' ? t.denied : t.expired;
				}
			} )
			.catch( function () {} );
		if ( tries > 300 ) {
			window.clearInterval( timer );
		}
	}
	function startPolling() {
		if ( timer ) {
			window.clearInterval( timer );
		}
		tries = 0;
		status.textContent = t.waiting;
		timer = window.setInterval( poll, 3000 );
	}
	if ( status && form ) {
		form.addEventListener( 'submit', function () {
			// The form opens Draftly in a new tab; keep this tab waiting for the approval.
			window.setTimeout( startPolling, 1500 );
		} );
		if ( status.getAttribute( 'data-pending' ) ) {
			startPolling();
		}
	}

	var verify = document.getElementById( 'draftly-verify' );
	if ( verify ) {
		var verifyStatus = document.getElementById( 'draftly-verify-status' );
		var check = function () {
			post( 'verify', {} )
				.then( function ( data ) {
					if ( data.active ) {
						window.location.reload();
					}
				} )
				.catch( function ( e ) {
					verifyStatus.textContent = e.message;
				} );
		};
		verify.addEventListener( 'click', function () {
			verifyStatus.textContent = t.checking;
			check();
		} );
		// Draftly verifies in the background right after connecting; look again shortly.
		window.setTimeout( check, 4000 );
	}

	// Support box: copy the support email address.
	( function () {
		var btn = document.getElementById( 'draftly-copy-email' );
		if ( ! btn ) {
			return;
		}
		btn.addEventListener( 'click', function () {
			var email = btn.getAttribute( 'data-email' ) || '';
			var done = function () {
				var label = btn.textContent;
				btn.textContent = ( window.draftlyAdmin && draftlyAdmin.i18n && draftlyAdmin.i18n.copied ) || 'Copied';
				window.setTimeout( function () { btn.textContent = label; }, 1500 );
			};
			if ( navigator.clipboard && navigator.clipboard.writeText ) {
				navigator.clipboard.writeText( email ).then( done, function () {} );
			} else {
				var range = document.createRange();
				range.selectNodeContents( document.getElementById( 'draftly-support-address' ) );
				var sel = window.getSelection();
				sel.removeAllRanges();
				sel.addRange( range );
			}
		} );
	}() );
}() );

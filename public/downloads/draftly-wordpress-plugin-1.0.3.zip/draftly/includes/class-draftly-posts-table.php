<?php
/**
 * The post list on Draftly > Optimize posts.
 *
 * @package Draftly
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_List_Table' ) ) {
	require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

/**
 * Posts with their Draftly scores and actions.
 */
class Draftly_Posts_Table extends WP_List_Table {

	/**
	 * Whether Draftly actions are available.
	 *
	 * @var bool
	 */
	private $connected;

	/**
	 * Constructor.
	 *
	 * @param bool $connected Connected and verified.
	 */
	public function __construct( $connected ) {
		$this->connected = $connected;
		parent::__construct(
			array(
				'singular' => 'draftly-post',
				'plural'   => 'draftly-posts',
				'ajax'     => false,
			)
		);
	}

	/**
	 * Columns.
	 *
	 * @return array
	 */
	public function get_columns() {
		return array(
			'title'    => __( 'Post', 'draftly' ),
			'status'   => __( 'Status', 'draftly' ),
			'modified' => __( 'Last modified', 'draftly' ),
			'score'    => __( 'Draftly score', 'draftly' ),
			'actions'  => __( 'Actions', 'draftly' ),
		);
	}

	/**
	 * Loads the current page of posts.
	 */
	public function prepare_items() {
		$per_page = 20;
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- read-only list filters.
		$search = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';
		// phpcs:enable
		$query                 = new WP_Query(
			array(
				'post_type'      => Draftly_Posts::POST_TYPES,
				'post_status'    => array( 'publish', 'draft', 'pending', 'future', 'private' ),
				'posts_per_page' => $per_page,
				'paged'          => $this->get_pagenum(),
				's'              => $search,
				'orderby'        => 'modified',
				'order'          => 'DESC',
				'perm'           => 'editable',
			)
		);
		$this->items           = $query->posts;
		$this->_column_headers = array( $this->get_columns(), array(), array() );
		$this->set_pagination_args(
			array(
				'total_items' => (int) $query->found_posts,
				'per_page'    => $per_page,
			)
		);
	}

	/**
	 * Empty list message.
	 */
	public function no_items() {
		esc_html_e( 'No posts found.', 'draftly' );
	}

	/**
	 * Title column.
	 *
	 * @param WP_Post $post Post.
	 * @return string
	 */
	public function column_title( $post ) {
		$title = get_the_title( $post );
		$edit  = get_edit_post_link( $post->ID );
		return '<strong>' . ( $edit ? '<a href="' . esc_url( $edit ) . '">' . esc_html( '' !== $title ? $title : __( '(no title)', 'draftly' ) ) . '</a>' : esc_html( $title ) ) . '</strong>';
	}

	/**
	 * Status column.
	 *
	 * @param WP_Post $post Post.
	 * @return string
	 */
	public function column_status( $post ) {
		$object = get_post_status_object( $post->post_status );
		return esc_html( $object ? $object->label : $post->post_status );
	}

	/**
	 * Modified column.
	 *
	 * @param WP_Post $post Post.
	 * @return string
	 */
	public function column_modified( $post ) {
		return esc_html( get_the_modified_date( '', $post ) );
	}

	/**
	 * Score column.
	 *
	 * @param WP_Post $post Post.
	 * @return string
	 */
	public function column_score( $post ) {
		$scores = Draftly_Posts::scores( $post->ID );
		$out    = '<div class="draftly-scores" data-post="' . esc_attr( $post->ID ) . '">';
		if ( ! $scores ) {
			$out .= '<span class="draftly-muted">' . esc_html__( 'Not checked', 'draftly' ) . '</span>';
		} else {
			$labels = array(
				'humanVoice'  => __( 'Human voice', 'draftly' ),
				'readability' => __( 'Readability', 'draftly' ),
			);
			foreach ( $labels as $key => $label ) {
				if ( isset( $scores[ $key ] ) && null !== $scores[ $key ] ) {
					$value = (int) $scores[ $key ];
					$tone  = $value >= 80 ? 'good' : ( $value >= 60 ? 'ok' : 'low' );
					$out  .= '<span class="draftly-score draftly-score-' . esc_attr( $tone ) . '">' . esc_html( $label ) . ' ' . esc_html( (string) $value ) . '</span> ';
				}
			}
		}
		return $out . '</div>';
	}

	/**
	 * Actions column.
	 *
	 * @param WP_Post $post Post.
	 * @return string
	 */
	public function column_actions( $post ) {
		if ( ! $this->connected || ! current_user_can( 'edit_post', $post->ID ) ) {
			return '';
		}
		$id   = esc_attr( $post->ID );
		$out  = '<button type="button" class="button draftly-action" data-action="check" data-post="' . $id . '">' . esc_html__( 'Check', 'draftly' ) . '</button> ';
		$out .= '<button type="button" class="button button-primary draftly-action" data-action="optimize" data-post="' . $id . '">' . esc_html__( 'Optimize', 'draftly' ) . '</button> ';
		if ( Draftly_Posts::can_revert( $post->ID ) ) {
			$out .= '<button type="button" class="button-link draftly-action" data-action="revert" data-post="' . $id . '">' . esc_html__( 'Revert', 'draftly' ) . '</button>';
		}
		return $out;
	}

	/**
	 * Fallback for other columns.
	 *
	 * @param WP_Post $item        Post.
	 * @param string  $column_name Column.
	 * @return string
	 */
	public function column_default( $item, $column_name ) {
		return '';
	}
}

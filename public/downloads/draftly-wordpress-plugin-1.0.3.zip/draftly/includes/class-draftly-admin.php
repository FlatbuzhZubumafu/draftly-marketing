<?php
/**
 * Admin screens: Draftly (optimize posts) and Draftly > Connection.
 *
 * Notices are only shown on these two screens. Nothing here calls Draftly
 * until the site is connected, except the Connect button itself.
 *
 * @package Draftly
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Admin pages and AJAX handlers.
 */
class Draftly_Admin {

	const PAGE_POSTS      = 'draftly';
	const PAGE_CONNECTION = 'draftly-connection';
	const NONCE_AJAX      = 'draftly_admin';
	const PLANS_URL       = 'https://www.draftly.blog/wordpress-ai-plugin';
	const TOP_UP_URL      = 'https://app.draftly.blog/#settings?tab=billing';
	const SUPPORT_EMAIL   = 'support@draftly.blog';

	/** Hosts Draftly's own links in error responses may point to. */
	const LINK_HOSTS = array( 'app.draftly.blog', 'www.draftly.blog', 'draftly.blog' );

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'admin_post_draftly_connect', array( __CLASS__, 'handle_connect' ) );
		add_action( 'admin_post_draftly_disconnect', array( __CLASS__, 'handle_disconnect' ) );
		add_filter( 'allowed_redirect_hosts', array( __CLASS__, 'allowed_redirect_hosts' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( DRAFTLY_FILE ), array( __CLASS__, 'action_links' ) );
		foreach ( array( 'check', 'optimize', 'apply', 'revert', 'poll', 'verify' ) as $action ) {
			add_action( 'wp_ajax_draftly_' . $action, array( __CLASS__, 'ajax_' . $action ) );
		}
	}

	/**
	 * Menu: Draftly (edit_posts) and Draftly > Connection (manage_options).
	 */
	public static function menu() {
		add_menu_page(
			__( 'Draftly', 'draftly' ),
			__( 'Draftly', 'draftly' ),
			'edit_posts',
			self::PAGE_POSTS,
			array( __CLASS__, 'render_posts' ),
			'dashicons-edit-page',
			26
		);
		add_submenu_page( self::PAGE_POSTS, __( 'Optimize posts', 'draftly' ), __( 'Optimize posts', 'draftly' ), 'edit_posts', self::PAGE_POSTS, array( __CLASS__, 'render_posts' ) );
		add_submenu_page( self::PAGE_POSTS, __( 'Draftly connection', 'draftly' ), __( 'Connection', 'draftly' ), 'manage_options', self::PAGE_CONNECTION, array( __CLASS__, 'render_connection' ) );
	}

	/**
	 * Settings link on the Plugins screen.
	 *
	 * @param array $links Links.
	 * @return array
	 */
	public static function action_links( $links ) {
		if ( current_user_can( 'manage_options' ) ) {
			array_unshift( $links, '<a href="' . esc_url( admin_url( 'admin.php?page=' . self::PAGE_CONNECTION ) ) . '">' . esc_html__( 'Connect', 'draftly' ) . '</a>' );
		}
		return $links;
	}

	/**
	 * Lets wp_safe_redirect send the admin to Draftly's approval page.
	 *
	 * @param array $hosts Hosts.
	 * @return array
	 */
	public static function allowed_redirect_hosts( $hosts ) {
		$hosts[] = 'app.draftly.blog';
		if ( defined( 'DRAFTLY_APP_HOST' ) ) {
			$hosts[] = DRAFTLY_APP_HOST;
		}
		return $hosts;
	}

	/**
	 * Scripts and styles, only on Draftly's own screens.
	 *
	 * @param string $hook Screen hook.
	 */
	public static function assets( $hook ) {
		if ( false === strpos( (string) $hook, self::PAGE_POSTS ) ) {
			return;
		}
		wp_enqueue_style( 'draftly-admin', plugins_url( 'assets/css/admin.css', DRAFTLY_FILE ), array(), DRAFTLY_VERSION );
		wp_enqueue_script( 'draftly-admin', plugins_url( 'assets/js/admin.js', DRAFTLY_FILE ), array(), DRAFTLY_VERSION, true );
		wp_localize_script(
			'draftly-admin',
			'draftlyAdmin',
			array(
				'ajaxUrl'       => admin_url( 'admin-ajax.php' ),
				'nonce'         => wp_create_nonce( self::NONCE_AJAX ),
				'connectionUrl' => current_user_can( 'manage_options' ) ? admin_url( 'admin.php?page=' . self::PAGE_CONNECTION ) : '',
				'topUpUrl'      => self::TOP_UP_URL,
				'plansUrl'      => self::PLANS_URL,
				'i18n'          => array(
					'checking'       => __( 'Checking...', 'draftly' ),
					'optimizing'     => __( 'Optimizing... this can take up to a minute.', 'draftly' ),
					'applying'       => __( 'Saving...', 'draftly' ),
					'reverting'      => __( 'Reverting...', 'draftly' ),
					'noChanges'      => __( 'Draftly found nothing to change in this post.', 'draftly' ),
					'approve'        => __( 'Approve selected', 'draftly' ),
					'discard'        => __( 'Discard', 'draftly' ),
					'before'         => __( 'Before', 'draftly' ),
					'after'          => __( 'After', 'draftly' ),
					'saved'          => __( 'Saved as a new revision. Reload to see the updated score.', 'draftly' ),
					'reverted'       => __( 'Reverted to the version before Draftly changed it.', 'draftly' ),
					'confirmRevert'  => __( 'Restore the version from before Draftly changed this post?', 'draftly' ),
					'error'          => __( 'Draftly did not answer as expected. Try again in a minute.', 'draftly' ),
					'checked'        => __( 'Checked.', 'draftly' ),
					'copied'         => __( 'Copied', 'draftly' ),
					/* translators: %s: number of credits */
					'creditsUsed'    => __( '%s credits used.', 'draftly' ),
					/* translators: %s: number of credits */
					'creditsLeft'    => __( '%s credits left.', 'draftly' ),
					/* translators: %s: what is left on the plan, e.g. "29 post scans" */
					'allowanceLeft'  => __( '%s left on your plan.', 'draftly' ),
					'noCharge'       => __( 'No credits used.', 'draftly' ),
					'notCharged'     => __( 'You were not charged.', 'draftly' ),
					/* translators: 1: support email address, 2: reference code */
					'support'        => __( 'If this keeps happening, email %1$s and quote reference %2$s.', 'draftly' ),
					'topUp'          => __( 'Top up credits', 'draftly' ),
					'seePlans'       => __( 'See plans', 'draftly' ),
					'tryAgain'       => __( 'Try again', 'draftly' ),
					'openConnection' => __( 'Open Draftly connection', 'draftly' ),
					'newTab'         => __( '(opens in a new tab)', 'draftly' ),
					'supportEmail'   => self::SUPPORT_EMAIL,
					'scoreLabels'    => array(
						'humanVoice'  => __( 'Human voice', 'draftly' ),
						'readability' => __( 'Readability', 'draftly' ),
					),
					/* translators: 1: posts used, 2: posts included on the free plan */
					'freePosts'      => __( 'Free: %1$s of %2$s posts used', 'draftly' ),
					'waiting'        => __( 'Waiting for you to approve in the Draftly tab...', 'draftly' ),
					'connected'      => __( 'Connected. Reloading...', 'draftly' ),
					'denied'         => __( 'The connection was cancelled in Draftly.', 'draftly' ),
					'expired'        => __( 'The connection request expired. Click Connect to Draftly again.', 'draftly' ),
				),
			)
		);
	}

	// ---- Connection screen ---------------------------------------------------------

	/**
	 * Admin-post handler for "Connect to Draftly": opens a connect request and redirects (in a new tab) to Draftly.
	 */
	public static function handle_connect() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to connect this site.', 'draftly' ), 403 );
		}
		check_admin_referer( 'draftly_connect' );
		$url = Draftly_Connection::start();
		if ( is_wp_error( $url ) ) {
			wp_die( esc_html( $url->get_error_message() ), esc_html__( 'Draftly', 'draftly' ), array( 'back_link' => true ) );
		}
		wp_safe_redirect( $url );
		exit;
	}

	/**
	 * Admin-post handler for Disconnect.
	 */
	public static function handle_disconnect() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to disconnect this site.', 'draftly' ), 403 );
		}
		check_admin_referer( 'draftly_disconnect' );
		Draftly_Connection::disconnect();
		wp_safe_redirect( admin_url( 'admin.php?page=' . self::PAGE_CONNECTION . '&draftly_disconnected=1' ) );
		exit;
	}

	/**
	 * Draftly > Connection.
	 */
	public static function render_connection() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		// Coming back from Draftly's approval page: collect the secret now rather than waiting for the poll.
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only flag; the exchange itself is authenticated by the PKCE verifier.
		$returned = isset( $_GET['draftly_connect'] ) ? sanitize_key( wp_unslash( $_GET['draftly_connect'] ) ) : '';
		if ( 'approved' === $returned && Draftly_Connection::pending() ) {
			Draftly_Connection::exchange();
		}
		$conn    = Draftly_Connection::get();
		$pending = $conn ? null : Draftly_Connection::pending();
		$status  = null;
		if ( $conn ) {
			$status = Draftly_Connection::refresh_status();
			$conn   = Draftly_Connection::get();
		}
		?>
		<div class="wrap draftly-wrap">
			<h1><?php esc_html_e( 'Draftly connection', 'draftly' ); ?></h1>
			<?php
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- display-only flag.
			if ( isset( $_GET['draftly_disconnected'] ) ) {
				echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Disconnected. Draftly no longer has access to this site.', 'draftly' ) . '</p></div>';
			}
			if ( 'denied' === $returned ) {
				echo '<div class="notice notice-warning is-dismissible"><p>' . esc_html__( 'The connection was cancelled in Draftly.', 'draftly' ) . '</p></div>';
			}
			if ( $conn && is_wp_error( $status ) && 'revoked' !== $status->get_error_code() ) {
				echo '<div class="notice notice-error"><p>' . esc_html( $status->get_error_message() ) . '</p></div>';
			}
			?>

			<?php if ( $conn ) : ?>
				<?php self::render_connected( $conn, is_wp_error( $status ) ? null : $status ); ?>
			<?php else : ?>
				<div class="draftly-card">
					<h2><?php esc_html_e( 'Connect this site to Draftly', 'draftly' ); ?></h2>
					<p><?php esc_html_e( 'Draftly checks your posts for readability and AI-sounding writing, suggests edits in your brand voice, and saves the ones you approve as WordPress revisions you can undo.', 'draftly' ); ?></p>
					<p><?php esc_html_e( 'Connecting opens Draftly in a new tab. Sign in or create a free account there and approve this site. No WordPress password or application password is shared.', 'draftly' ); ?></p>
					<p class="description">
						<?php esc_html_e( 'When you click Connect, this site sends Draftly its address, its REST API address, the address of this page and the plugin and WordPress versions. Nothing is sent before you click.', 'draftly' ); ?>
						<a href="https://www.draftly.blog/privacy-policy" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Privacy policy', 'draftly' ); ?></a>
					</p>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" target="_blank" id="draftly-connect-form">
						<input type="hidden" name="action" value="draftly_connect" />
						<?php wp_nonce_field( 'draftly_connect' ); ?>
						<?php submit_button( __( 'Connect to Draftly', 'draftly' ), 'primary', 'submit', false ); ?>
					</form>
					<div id="draftly-connect-status" class="draftly-status" aria-live="polite" <?php echo $pending ? 'data-pending="1"' : ''; ?>>
						<?php
						if ( $pending ) {
							esc_html_e( 'Waiting for you to approve in the Draftly tab...', 'draftly' );
						}
						?>
					</div>
					<p><a href="<?php echo esc_url( self::PLANS_URL ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'What Draftly includes, and plans', 'draftly' ); ?></a></p>
				</div>
			<?php endif; ?>
			<?php self::render_support(); ?>
		</div>
		<?php
	}

	/**
	 * The connected state.
	 *
	 * @param array      $conn   Connection.
	 * @param array|null $status Status from Draftly.
	 */
	private static function render_connected( array $conn, $status ) {
		$active    = 'active' === ( $conn['status'] ?? '' );
		$account   = is_array( $status['account'] ?? null ) ? $status['account'] : array();
		$seo       = Draftly_Seo_Meta::provider();
		$seo_names = array(
			'yoast'    => 'Yoast SEO',
			'rankmath' => 'Rank Math',
			'aioseo'   => 'All in One SEO',
			'none'     => __( 'none (the post excerpt is used as the description)', 'draftly' ),
		);
		?>
		<div class="draftly-card">
			<h2>
				<?php
				if ( $active ) {
					esc_html_e( 'Connected to Draftly', 'draftly' );
				} else {
					esc_html_e( 'Connected, waiting for Draftly to verify this site', 'draftly' );
				}
				?>
			</h2>
			<?php if ( ! $active ) : ?>
				<p><?php esc_html_e( 'Draftly needs to reach this site once to confirm the connection. This usually takes a few seconds.', 'draftly' ); ?></p>
				<p><button type="button" class="button" id="draftly-verify"><?php esc_html_e( 'Retry verification', 'draftly' ); ?></button> <span id="draftly-verify-status" class="draftly-status" aria-live="polite"></span></p>
			<?php endif; ?>
			<table class="form-table" role="presentation">
				<tr><th scope="row"><?php esc_html_e( 'Draftly account', 'draftly' ); ?></th><td><?php echo esc_html( $account['email'] ?? ( $conn['account_email'] ?? '' ) ); ?></td></tr>
				<?php if ( ! empty( $status['website_name'] ) ) : ?>
					<tr><th scope="row"><?php esc_html_e( 'Draftly website', 'draftly' ); ?></th><td><?php echo esc_html( $status['website_name'] ); ?></td></tr>
				<?php endif; ?>
				<?php if ( isset( $account['plan'] ) ) : ?>
					<tr><th scope="row"><?php esc_html_e( 'Plan', 'draftly' ); ?></th><td><?php echo esc_html( ucfirst( (string) $account['plan'] ) ); ?></td></tr>
				<?php endif; ?>
				<?php if ( isset( $account['credits'] ) && null !== $account['credits'] ) : ?>
					<tr><th scope="row"><?php esc_html_e( 'Credits left', 'draftly' ); ?></th><td><?php echo esc_html( number_format_i18n( (int) $account['credits'] ) ); ?></td></tr>
				<?php endif; ?>
				<tr><th scope="row"><?php esc_html_e( 'SEO titles and descriptions', 'draftly' ); ?></th><td><?php echo esc_html( $seo_names[ $seo ] ); ?></td></tr>
			</table>
			<p>
				<a class="button button-primary" href="<?php echo esc_url( admin_url( 'admin.php?page=' . self::PAGE_POSTS ) ); ?>"><?php esc_html_e( 'Optimize posts', 'draftly' ); ?></a>
				<a class="button" href="https://app.draftly.blog" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Open Draftly', 'draftly' ); ?></a>
				<a href="<?php echo esc_url( self::PLANS_URL ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Plans', 'draftly' ); ?></a>
			</p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="draftly-confirm" data-confirm="<?php echo esc_attr__( 'Disconnect this site from Draftly? Draftly will no longer be able to read or update your posts.', 'draftly' ); ?>">
				<input type="hidden" name="action" value="draftly_disconnect" />
				<?php wp_nonce_field( 'draftly_disconnect' ); ?>
				<?php submit_button( __( 'Disconnect', 'draftly' ), 'delete', 'submit', false ); ?>
			</form>
		</div>
		<?php
	}

	// ---- Posts screen ---------------------------------------------------------------

	/**
	 * Draftly > Optimize posts.
	 */
	public static function render_posts() {
		if ( ! current_user_can( 'edit_posts' ) ) {
			return;
		}
		$conn = Draftly_Connection::get();
		?>
		<div class="wrap draftly-wrap">
			<h1><?php esc_html_e( 'Optimize posts with Draftly', 'draftly' ); ?></h1>
			<?php if ( ! $conn ) : ?>
				<div class="notice notice-info">
					<p>
						<?php
						if ( current_user_can( 'manage_options' ) ) {
							printf(
								/* translators: %s: link to the Connection screen */
								esc_html__( 'Connect this site to Draftly first: %s.', 'draftly' ),
								'<a href="' . esc_url( admin_url( 'admin.php?page=' . self::PAGE_CONNECTION ) ) . '">' . esc_html__( 'Draftly > Connection', 'draftly' ) . '</a>'
							);
						} else {
							esc_html_e( 'Ask a site administrator to connect this site to Draftly.', 'draftly' );
						}
						?>
					</p>
				</div>
			<?php elseif ( ! Draftly_Connection::is_active() ) : ?>
				<div class="notice notice-warning"><p>
					<?php
					printf(
						/* translators: %s: link to the Connection screen */
						esc_html__( 'Draftly has not verified this site yet. See %s.', 'draftly' ),
						'<a href="' . esc_url( admin_url( 'admin.php?page=' . self::PAGE_CONNECTION ) ) . '">' . esc_html__( 'Draftly > Connection', 'draftly' ) . '</a>'
					);
					?>
				</p></div>
			<?php endif; ?>
			<p class="description"><?php esc_html_e( 'Check scores each post for Human voice and Readability. Optimize suggests edits you can review one by one; approved edits are saved as a new revision, and Revert restores the version from before Draftly changed it. Both use Draftly credits.', 'draftly' ); ?></p>
			<?php
			$free_posts = Draftly_Connection::free_posts();
			?>
			<p id="draftly-free-posts" class="draftly-free-posts draftly-muted"<?php echo $free_posts ? '' : ' hidden'; ?>>
				<?php
				if ( $free_posts ) {
					printf(
						/* translators: 1: posts used, 2: posts included on the free plan */
						esc_html__( 'Free: %1$s of %2$s posts used', 'draftly' ),
						esc_html( number_format_i18n( min( (int) $free_posts['used'], (int) $free_posts['limit'] ) ) ),
						esc_html( number_format_i18n( (int) $free_posts['limit'] ) )
					);
				}
				?>
			</p>
			<div id="draftly-notice" class="draftly-status" aria-live="polite"></div>
			<form method="get">
				<input type="hidden" name="page" value="<?php echo esc_attr( self::PAGE_POSTS ); ?>" />
				<?php
				$table = new Draftly_Posts_Table( (bool) $conn && Draftly_Connection::is_active() );
				$table->prepare_items();
				$table->search_box( __( 'Search posts', 'draftly' ), 'draftly-search' );
				$table->display();
				?>
			</form>
			<div id="draftly-review" class="draftly-review" hidden></div>
			<?php self::render_support(); ?>
		</div>
		<?php
	}

	/**
	 * Support and feedback box: shows the support email. The plugin sends nothing;
	 * the link opens the user's own email app.
	 */
	private static function render_support() {
		$email   = 'preston@draftly.blog';
		$subject = __( 'Draftly WordPress plugin feedback', 'draftly' );
		$body    = sprintf(
			/* translators: 1: site address, 2: plugin version, 3: WordPress version */
			__( "Hi Preston,\n\n\n\n---\nSite: %1\$s\nPlugin: %2\$s\nWordPress: %3\$s", 'draftly' ),
			home_url(),
			DRAFTLY_VERSION,
			get_bloginfo( 'version' )
		);
		$mailto = 'mailto:' . $email . '?subject=' . rawurlencode( $subject ) . '&body=' . rawurlencode( $body );
		?>
		<div class="draftly-card draftly-support">
			<h2><?php esc_html_e( 'Questions, bugs or ideas?', 'draftly' ); ?></h2>
			<p><?php esc_html_e( 'Email Preston, the founder of Draftly. He reads every message and replies personally.', 'draftly' ); ?></p>
			<p class="draftly-support-email">
				<a class="button" href="<?php echo esc_url( $mailto, array( 'mailto' ) ); ?>"><?php esc_html_e( 'Email support', 'draftly' ); ?></a>
				<code id="draftly-support-address"><?php echo esc_html( $email ); ?></code>
				<button type="button" class="button-link" id="draftly-copy-email" data-email="<?php echo esc_attr( $email ); ?>"><?php esc_html_e( 'Copy', 'draftly' ); ?></button>
			</p>
			<p class="description"><?php esc_html_e( 'Feature requests are welcome. Tell us what you would like Draftly to do next.', 'draftly' ); ?></p>
		</div>
		<?php
	}

	// ---- AJAX ---------------------------------------------------------------------

	/**
	 * Checks the AJAX nonce and that the user may edit the post. Returns the post.
	 *
	 * @return WP_Post
	 */
	private static function ajax_post() {
		check_ajax_referer( self::NONCE_AJAX, 'nonce' );
		$post_id = isset( $_POST['post_id'] ) ? absint( wp_unslash( $_POST['post_id'] ) ) : 0;
		$post    = $post_id ? get_post( $post_id ) : null;
		if ( ! $post || ! in_array( $post->post_type, Draftly_Posts::POST_TYPES, true ) || ! current_user_can( 'edit_post', $post_id ) ) {
			wp_send_json_error( array( 'message' => __( 'You cannot edit this post.', 'draftly' ) ), 403 );
		}
		if ( ! Draftly_Connection::is_active() ) {
			wp_send_json_error( array( 'message' => __( 'Connect this site to Draftly first.', 'draftly' ) ), 400 );
		}
		return $post;
	}

	/**
	 * Sends a Draftly error to the browser.
	 *
	 * @param WP_Error $error Error.
	 */
	private static function send_error( WP_Error $error ) {
		$data   = $error->get_error_data();
		$data   = is_array( $data ) ? $data : array();
		$status = isset( $data['http_status'] ) ? (int) $data['http_status'] : 502;
		$out    = array(
			'message' => $error->get_error_message(),
			'code'    => sanitize_key( (string) $error->get_error_code() ),
		);
		// Only these fields from Draftly reach the browser, each cleaned for its type.
		if ( isset( $data['request_id'] ) && is_string( $data['request_id'] ) ) {
			$out['request_id'] = substr( preg_replace( '/[^A-Za-z0-9_-]/', '', $data['request_id'] ), 0, 40 );
		}
		foreach ( array( 'credits_needed', 'credits_available', 'words', 'max_words', 'charged' ) as $key ) {
			if ( isset( $data[ $key ] ) && is_numeric( $data[ $key ] ) ) {
				$out[ $key ] = absint( $data[ $key ] );
			}
		}
		if ( isset( $data['retryable'] ) ) {
			$out['retryable'] = (bool) $data['retryable'];
		}
		Draftly_Connection::remember_free_posts( $data );
		$out = array_merge( $out, self::free_posts_fields( $data ) );
		if ( in_array( $out['code'], array( 'insufficient_credits', 'allowance_exhausted', 'free_limit_reached' ), true ) ) {
			$out['top_up_url']  = self::draftly_link( $data['top_up_url'] ?? '', self::TOP_UP_URL );
			$out['upgrade_url'] = self::draftly_link( $data['upgrade_url'] ?? '', self::PLANS_URL );
		}
		wp_send_json_error( $out, $status >= 400 && $status < 600 ? $status : 502 );
	}

	/**
	 * A link from Draftly's response, used only if it is https on a Draftly host.
	 *
	 * @param mixed  $url      URL from the response.
	 * @param string $fallback Default link.
	 * @return string
	 */
	private static function draftly_link( $url, $fallback ) {
		if ( ! is_string( $url ) || '' === $url ) {
			return $fallback;
		}
		$clean = esc_url_raw( $url, array( 'https' ) );
		$host  = wp_parse_url( $clean, PHP_URL_HOST );
		return ( $clean && in_array( $host, self::LINK_HOSTS, true ) ) ? $clean : $fallback;
	}

	/**
	 * What is left after a run, for the success notice.
	 *
	 * @param array $result Draftly's response.
	 * @return array
	 */
	private static function usage( array $result ) {
		$out = array(
			'charged'           => (int) ( $result['charged'] ?? 0 ),
			'credits_remaining' => isset( $result['credits_remaining'] ) && is_numeric( $result['credits_remaining'] ) ? absint( $result['credits_remaining'] ) : null,
			'allowance_left'    => '',
		);
		if ( is_array( $result['allowance'] ?? null ) && isset( $result['allowance']['label'] ) && is_string( $result['allowance']['label'] ) ) {
			$out['allowance_left'] = sanitize_text_field( $result['allowance']['label'] );
		}
		Draftly_Connection::remember_free_posts( $result );
		return array_merge( $out, self::free_posts_fields( $result ) );
	}

	/**
	 * The free-posts counter for the browser (nulls when the account has none).
	 *
	 * @param array $data Draftly's response or error data.
	 * @return array
	 */
	private static function free_posts_fields( array $data ) {
		$has = isset( $data['free_posts_used'], $data['free_posts_limit'] ) && is_numeric( $data['free_posts_used'] ) && is_numeric( $data['free_posts_limit'] );
		return array(
			'free_posts_used'  => $has ? absint( $data['free_posts_used'] ) : null,
			'free_posts_limit' => $has ? absint( $data['free_posts_limit'] ) : null,
		);
	}

	/**
	 * The post as Draftly needs it.
	 *
	 * @param WP_Post $post Post.
	 * @return array
	 */
	private static function post_payload( WP_Post $post ) {
		return array(
			'id'      => $post->ID,
			'title'   => get_the_title( $post ),
			'url'     => get_permalink( $post ),
			'content' => $post->post_content,
		);
	}

	/**
	 * AJAX: score a post.
	 */
	public static function ajax_check() {
		$post   = self::ajax_post();
		$result = Draftly_Connection::signed( 'check', array( 'post' => self::post_payload( $post ) ), 120 );
		if ( is_wp_error( $result ) ) {
			self::send_error( $result );
		}
		Draftly_Posts::save_scores( $post->ID, $result['scores'] ?? null );
		wp_send_json_success(
			array_merge(
				array(
					'scores' => Draftly_Posts::scores( $post->ID ),
					'issues' => $result['document_issues'] ?? array(),
					'flags'  => (int) ( $result['flags'] ?? 0 ),
				),
				self::usage( $result )
			)
		);
	}

	/**
	 * AJAX: get suggested edits for a post (nothing is saved yet).
	 */
	public static function ajax_optimize() {
		$post   = self::ajax_post();
		$result = Draftly_Connection::signed( 'optimize', array( 'post' => self::post_payload( $post ) ), 180 );
		if ( is_wp_error( $result ) ) {
			self::send_error( $result );
		}
		Draftly_Posts::save_scores( $post->ID, $result['scores'] ?? null );
		if ( ! empty( $result['document_id'] ) && is_array( $result['scores_after'] ?? null ) ) {
			// Shown as the post's score once the edits are approved.
			set_transient( 'draftly_after_' . md5( $result['document_id'] ), $result['scores_after'], DAY_IN_SECONDS );
		}
		$changes = array();
		foreach ( (array) ( $result['changes'] ?? array() ) as $change ) {
			$changes[] = array(
				'id'     => sanitize_key( $change['id'] ?? '' ),
				'before' => sanitize_textarea_field( $change['before'] ?? '' ),
				'after'  => sanitize_textarea_field( $change['after'] ?? '' ),
				'rule'   => sanitize_text_field( $change['rule'] ?? '' ),
				'reason' => sanitize_text_field( $change['reason'] ?? '' ),
			);
		}
		wp_send_json_success(
			array_merge(
				array(
					'document_id'  => sanitize_text_field( $result['document_id'] ?? '' ),
					'post_title'   => get_the_title( $post ),
					'scores'       => $result['scores'] ?? null,
					'scores_after' => $result['scores_after'] ?? null,
					'changes'      => $changes,
				),
				self::usage( $result )
			)
		);
	}

	/**
	 * AJAX: apply the approved edits as a new revision.
	 */
	public static function ajax_apply() {
		check_ajax_referer( self::NONCE_AJAX, 'nonce' );
		$post        = self::ajax_post();
		$document_id = isset( $_POST['document_id'] ) ? sanitize_text_field( wp_unslash( $_POST['document_id'] ) ) : '';
		$accepted    = isset( $_POST['accepted'] ) ? array_map( 'sanitize_key', (array) wp_unslash( $_POST['accepted'] ) ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- each item is sanitized by sanitize_key.
		if ( '' === $document_id || ! $accepted ) {
			wp_send_json_error( array( 'message' => __( 'Pick at least one change to approve.', 'draftly' ) ), 400 );
		}
		// Draftly places the stored suggestions into the current body; only Draftly's own suggestions can be applied.
		$result = Draftly_Connection::signed(
			'apply',
			array(
				'document_id'         => $document_id,
				'post_id'             => $post->ID,
				'accepted_change_ids' => array_values( $accepted ),
				'content'             => $post->post_content,
			),
			60
		);
		if ( is_wp_error( $result ) ) {
			self::send_error( $result );
		}
		if ( ! isset( $result['content'] ) || ! is_string( $result['content'] ) ) {
			wp_send_json_error( array( 'message' => __( 'Draftly did not return the updated post.', 'draftly' ) ), 502 );
		}
		$saved = Draftly_Posts::update( $post, array( 'content' => $result['content'] ) );
		if ( is_wp_error( $saved ) ) {
			self::send_error( $saved );
		}
		$after = get_transient( 'draftly_after_' . md5( $document_id ) );
		if ( is_array( $after ) ) {
			Draftly_Posts::save_scores( $post->ID, $after );
		}
		wp_send_json_success(
			array(
				'applied' => count( (array) ( $result['applied'] ?? array() ) ),
				'skipped' => count( (array) ( $result['skipped'] ?? array() ) ),
				'scores'  => Draftly_Posts::scores( $post->ID ),
			)
		);
	}

	/**
	 * AJAX: undo Draftly's last change to a post. Local only; Draftly isn't contacted.
	 */
	public static function ajax_revert() {
		check_ajax_referer( self::NONCE_AJAX, 'nonce' );
		$post_id = isset( $_POST['post_id'] ) ? absint( wp_unslash( $_POST['post_id'] ) ) : 0;
		$post    = $post_id ? get_post( $post_id ) : null;
		if ( ! $post || ! current_user_can( 'edit_post', $post_id ) ) {
			wp_send_json_error( array( 'message' => __( 'You cannot edit this post.', 'draftly' ) ), 403 );
		}
		$restored = Draftly_Posts::revert( $post );
		if ( is_wp_error( $restored ) ) {
			wp_send_json_error( array( 'message' => $restored->get_error_message() ), 409 );
		}
		wp_send_json_success( array( 'reverted' => true ) );
	}

	/**
	 * AJAX: the Connection screen polls this while the admin approves in the Draftly tab.
	 */
	public static function ajax_poll() {
		check_ajax_referer( self::NONCE_AJAX, 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Not allowed.', 'draftly' ) ), 403 );
		}
		$status = Draftly_Connection::exchange();
		if ( 'approved' === $status && Draftly_Connection::get() && ! Draftly_Connection::is_active() ) {
			Draftly_Connection::refresh_status();
		}
		wp_send_json_success(
			array(
				'status' => $status,
				'active' => Draftly_Connection::is_active(),
			)
		);
	}

	/**
	 * AJAX: retry site verification.
	 */
	public static function ajax_verify() {
		check_ajax_referer( self::NONCE_AJAX, 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Not allowed.', 'draftly' ) ), 403 );
		}
		if ( ! Draftly_Connection::is_active() ) {
			Draftly_Connection::request_verification();
			Draftly_Connection::refresh_status();
		}
		wp_send_json_success( array( 'active' => Draftly_Connection::is_active() ) );
	}
}

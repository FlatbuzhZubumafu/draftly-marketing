<?php
/**
 * The connection to Draftly: stored credentials, the connect handshake and
 * signed calls to the Draftly API.
 *
 * Nothing in this file contacts Draftly until an administrator clicks
 * "Connect to Draftly".
 *
 * @package Draftly
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Stores the connection and talks to Draftly.
 */
class Draftly_Connection {

	/** Option holding the live connection (never autoloaded). */
	const OPTION = 'draftly_connection';

	/** Option holding a connect request in progress (never autoloaded). */
	const PENDING_OPTION = 'draftly_pending_connect';

	/** Option holding the free-posts counter Draftly last reported (Free accounts only). */
	const FREE_POSTS_OPTION = 'draftly_free_posts';

	/** Route Draftly signs plugin requests over. */
	const API_ROUTE = '/wordpress-plugin';

	/**
	 * Draftly API endpoint. Overridable with DRAFTLY_API_URL in wp-config.php (development only).
	 *
	 * @return string
	 */
	public static function api_url() {
		return defined( 'DRAFTLY_API_URL' ) ? DRAFTLY_API_URL : 'https://app.draftly.blog/api/wordpress-plugin';
	}

	/**
	 * The stored connection, or null.
	 *
	 * @return array|null
	 */
	public static function get() {
		$conn = get_option( self::OPTION );
		if ( ! is_array( $conn ) || empty( $conn['connection_id'] ) || empty( $conn['secret'] ) ) {
			return null;
		}
		return $conn;
	}

	/**
	 * Saves the connection. autoload is off so the secret isn't loaded on every request.
	 *
	 * @param array $conn Connection.
	 */
	public static function save( array $conn ) {
		delete_option( self::OPTION );
		add_option( self::OPTION, $conn, '', false );
	}

	/**
	 * Forgets the connection and any pending request.
	 */
	public static function forget() {
		delete_option( self::OPTION );
		delete_option( self::PENDING_OPTION );
		delete_option( self::FREE_POSTS_OPTION );
	}

	/**
	 * Whether the connection has been verified by Draftly.
	 *
	 * @return bool
	 */
	public static function is_active() {
		$conn = self::get();
		return $conn && 'active' === ( $conn['status'] ?? '' );
	}

	/**
	 * The pending connect request, if it hasn't expired.
	 *
	 * @return array|null
	 */
	public static function pending() {
		$pending = get_option( self::PENDING_OPTION );
		if ( ! is_array( $pending ) || empty( $pending['request_id'] ) || (int) ( $pending['expires'] ?? 0 ) < time() ) {
			return null;
		}
		return $pending;
	}

	/**
	 * Starts a connect request with Draftly. Returns the URL to open, or a WP_Error.
	 * Called only from the "Connect to Draftly" button (manage_options + nonce).
	 *
	 * @return string|WP_Error
	 */
	public static function start() {
		$verifier = wp_generate_password( 64, false, false );
		$response = self::post_json(
			array(
				'action'         => 'start',
				'site_url'       => site_url(),
				'rest_url'       => rest_url(),
				'return_url'     => admin_url( 'admin.php?page=draftly-connection' ),
				'plugin_version' => DRAFTLY_VERSION,
				'wp_version'     => get_bloginfo( 'version' ),
				'challenge'      => Draftly_Signature::pkce_challenge( $verifier ),
			),
			array(),
			20
		);
		if ( is_wp_error( $response ) ) {
			return $response;
		}
		if ( empty( $response['request_id'] ) || empty( $response['connect_url'] ) ) {
			return new WP_Error( 'draftly_start_failed', __( 'Draftly did not return a connection link. Try again.', 'draftly' ) );
		}
		delete_option( self::PENDING_OPTION );
		add_option(
			self::PENDING_OPTION,
			array(
				'request_id' => sanitize_text_field( $response['request_id'] ),
				'verifier'   => $verifier,
				'expires'    => time() + (int) ( $response['expires_in'] ?? 900 ),
				'user_id'    => get_current_user_id(),
			),
			'',
			false
		);
		return esc_url_raw( $response['connect_url'] );
	}

	/**
	 * Asks Draftly whether the pending request was approved and, if so, collects
	 * the site secret (once). Returns the status string.
	 *
	 * @return string pending|approved|denied|expired|none|error
	 */
	public static function exchange() {
		$pending = self::pending();
		if ( ! $pending ) {
			return self::get() ? 'approved' : 'none';
		}
		$response = self::post_json(
			array(
				'action'     => 'exchange',
				'request_id' => $pending['request_id'],
				'verifier'   => $pending['verifier'],
			),
			array(),
			20
		);
		if ( is_wp_error( $response ) ) {
			// 404 / 409 answers still carry a status (not_found, already_exchanged).
			$data     = $response->get_error_data();
			$response = is_array( $data ) && isset( $data['status'] ) && is_string( $data['status'] ) ? array( 'status' => $data['status'] ) : array( 'status' => 'error' );
		}
		$status = isset( $response['status'] ) ? sanitize_key( $response['status'] ) : 'error';
		if ( 'approved' === $status && ! empty( $response['secret'] ) && ! empty( $response['connection_id'] ) ) {
			self::save(
				array(
					'connection_id' => sanitize_text_field( $response['connection_id'] ),
					'secret'        => (string) $response['secret'],
					'account_email' => sanitize_email( $response['account_email'] ?? '' ),
					'site_url'      => esc_url_raw( $response['site_url'] ?? site_url() ),
					'user_id'       => (int) ( $pending['user_id'] ?? get_current_user_id() ),
					'connected_at'  => time(),
					'status'        => 'pending_verification',
				)
			);
			delete_option( self::PENDING_OPTION );
			self::request_verification();
			return 'approved';
		}
		if ( in_array( $status, array( 'denied', 'expired', 'already_exchanged', 'not_found' ), true ) ) {
			delete_option( self::PENDING_OPTION );
		}
		return $status;
	}

	/**
	 * Asks Draftly to reach this site and confirm it holds the secret.
	 * Draftly answers at once and calls back afterwards.
	 */
	public static function request_verification() {
		self::signed( 'verify', array(), 15 );
	}

	/**
	 * Account and connection state from Draftly. Updates the stored status.
	 *
	 * @return array|WP_Error
	 */
	public static function refresh_status() {
		$status = self::signed( 'connection_status', array(), 15 );
		if ( is_wp_error( $status ) ) {
			return $status;
		}
		self::remember_free_posts( $status );
		$conn    = self::get();
		$current = $conn['status'] ?? '';
		if ( $conn && ! empty( $status['status'] ) && $current !== $status['status'] ) {
			$conn['status'] = sanitize_key( $status['status'] );
			self::save( $conn );
		}
		return $status;
	}

	/**
	 * Keeps the free-posts counter Draftly sends with each answer (Free accounts only).
	 * Draftly enforces the limit; this copy is only for the "Free: N of M posts used" line.
	 *
	 * @param array $data Draftly's response or error data.
	 */
	public static function remember_free_posts( $data ) {
		if ( ! is_array( $data ) || ! array_key_exists( 'free_posts_limit', $data ) ) {
			return;
		}
		if ( is_numeric( $data['free_posts_limit'] ) && isset( $data['free_posts_used'] ) && is_numeric( $data['free_posts_used'] ) ) {
			update_option(
				self::FREE_POSTS_OPTION,
				array(
					'used'  => absint( $data['free_posts_used'] ),
					'limit' => absint( $data['free_posts_limit'] ),
				),
				false
			);
		} else {
			delete_option( self::FREE_POSTS_OPTION );
		}
	}

	/**
	 * The last free-posts counter from Draftly, or null for accounts without one.
	 *
	 * @return array|null { used: int, limit: int }
	 */
	public static function free_posts() {
		$value = get_option( self::FREE_POSTS_OPTION );
		return is_array( $value ) && isset( $value['used'], $value['limit'] ) ? $value : null;
	}

	/**
	 * Disconnects on both sides. The local credentials are removed even if Draftly can't be reached.
	 */
	public static function disconnect() {
		if ( self::get() ) {
			self::signed( 'disconnect', array(), 10 );
		}
		self::forget();
	}

	/**
	 * A signed call to Draftly.
	 *
	 * @param string $action  Action.
	 * @param array  $payload Payload.
	 * @param int    $timeout Seconds.
	 * @return array|WP_Error
	 */
	public static function signed( $action, array $payload, $timeout = 30 ) {
		$conn = self::get();
		if ( ! $conn ) {
			return new WP_Error( 'draftly_not_connected', __( 'This site is not connected to Draftly.', 'draftly' ) );
		}
		$body    = wp_json_encode( array_merge( $payload, array( 'action' => $action ) ) );
		$headers = Draftly_Signature::headers( $conn['secret'], $conn['connection_id'], 'POST', self::API_ROUTE, array(), $body );
		$result  = self::post_json( null, $headers, $timeout, $body );
		if ( is_wp_error( $result ) && 'revoked' === $result->get_error_code() ) {
			// Draftly no longer knows this connection (disconnected in the app, or reconnected elsewhere).
			self::forget();
		}
		return $result;
	}

	/**
	 * POSTs JSON to Draftly and decodes the answer.
	 *
	 * @param array|null  $payload Payload (ignored when $raw is given).
	 * @param array       $headers Extra headers.
	 * @param int         $timeout Seconds.
	 * @param string|null $raw     Pre-encoded body (signed requests).
	 * @return array|WP_Error
	 */
	private static function post_json( $payload, array $headers, $timeout, $raw = null ) {
		$response = wp_remote_post(
			self::api_url(),
			array(
				'timeout' => $timeout,
				'headers' => array_merge(
					array(
						'Content-Type' => 'application/json',
						'Accept'       => 'application/json',
					),
					$headers
				),
				'body'    => null !== $raw ? $raw : wp_json_encode( $payload ),
			)
		);
		if ( is_wp_error( $response ) ) {
			return new WP_Error( 'draftly_unreachable', __( 'Could not reach Draftly, or it took too long to answer. Try again in a minute.', 'draftly' ), array( 'retryable' => true ) );
		}
		$code = (int) wp_remote_retrieve_response_code( $response );
		$data = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( ! is_array( $data ) ) {
			$data = array();
		}
		if ( $code >= 400 ) {
			$error_code = isset( $data['code'] ) ? sanitize_key( $data['code'] ) : 'draftly_http_' . $code;
			$message    = isset( $data['error'] ) && is_string( $data['error'] ) ? sanitize_text_field( $data['error'] ) : __( 'Draftly could not finish this request. Try again in a minute.', 'draftly' );
			return new WP_Error( $error_code, $message, array_merge( $data, array( 'http_status' => $code ) ) );
		}
		return $data;
	}
}

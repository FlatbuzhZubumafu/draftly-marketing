<?php
/**
 * SEO title and meta description, stored wherever the site's SEO plugin keeps them.
 *
 *   Yoast SEO       post meta _yoast_wpseo_title, _yoast_wpseo_metadesc (_yoast_wpseo_focuskw)
 *   Rank Math       post meta rank_math_title, rank_math_description (rank_math_focus_keyword)
 *   All in One SEO  its own aioseo_posts table, through AIOSEO's Post model
 *   none            the post excerpt holds the description; there is no separate title
 *
 * @package Draftly
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Reads and writes SEO meta for a post.
 */
class Draftly_Seo_Meta {

	/**
	 * Which SEO plugin is active: yoast, rankmath, aioseo or none.
	 *
	 * @return string
	 */
	public static function provider() {
		if ( defined( 'WPSEO_VERSION' ) ) {
			return 'yoast';
		}
		if ( defined( 'RANK_MATH_VERSION' ) || class_exists( 'RankMath' ) ) {
			return 'rankmath';
		}
		if ( defined( 'AIOSEO_VERSION' ) || function_exists( 'aioseo' ) ) {
			return 'aioseo';
		}
		return 'none';
	}

	/**
	 * AIOSEO's post model class, when the installed version has the API we use.
	 *
	 * @return string|null
	 */
	private static function aioseo_model() {
		$class = '\AIOSEO\Plugin\Common\Models\Post';
		return class_exists( $class ) ? $class : null;
	}

	/**
	 * The post's SEO title and description.
	 *
	 * @param int $post_id Post id.
	 * @return array { title: string|null, description: string|null, source: string }
	 */
	public static function get( $post_id ) {
		$provider = self::provider();
		switch ( $provider ) {
			case 'yoast':
				return self::shape( get_post_meta( $post_id, '_yoast_wpseo_title', true ), get_post_meta( $post_id, '_yoast_wpseo_metadesc', true ), $provider );
			case 'rankmath':
				return self::shape( get_post_meta( $post_id, 'rank_math_title', true ), get_post_meta( $post_id, 'rank_math_description', true ), $provider );
			case 'aioseo':
				$model = self::aioseo_model();
				if ( $model && method_exists( $model, 'getPost' ) ) {
					$row = $model::getPost( $post_id );
					return self::shape( $row->title ?? '', $row->description ?? '', $provider );
				}
				// Older AIOSEO versions mirror the values in post meta.
				return self::shape( get_post_meta( $post_id, '_aioseo_title', true ), get_post_meta( $post_id, '_aioseo_description', true ), $provider );
			default:
				$post = get_post( $post_id );
				return self::shape( '', $post ? $post->post_excerpt : '', 'excerpt' );
		}
	}

	/**
	 * Writes the given fields (null leaves a field as it is). Returns the stored values, or WP_Error.
	 *
	 * @param int         $post_id       Post id.
	 * @param string|null $title         SEO title.
	 * @param string|null $description   Meta description.
	 * @param string|null $focus_keyword Focus keyword (Yoast, Rank Math only).
	 * @return array|WP_Error
	 */
	public static function set( $post_id, $title, $description, $focus_keyword = null ) {
		$title         = null === $title ? null : sanitize_text_field( $title );
		$description   = null === $description ? null : sanitize_textarea_field( $description );
		$focus_keyword = null === $focus_keyword ? null : sanitize_text_field( $focus_keyword );
		$provider      = self::provider();

		switch ( $provider ) {
			case 'yoast':
				self::update( $post_id, '_yoast_wpseo_title', $title );
				self::update( $post_id, '_yoast_wpseo_metadesc', $description );
				self::update( $post_id, '_yoast_wpseo_focuskw', $focus_keyword );
				break;
			case 'rankmath':
				self::update( $post_id, 'rank_math_title', $title );
				self::update( $post_id, 'rank_math_description', $description );
				self::update( $post_id, 'rank_math_focus_keyword', $focus_keyword );
				break;
			case 'aioseo':
				$model = self::aioseo_model();
				if ( ! $model || ! method_exists( $model, 'savePost' ) ) {
					// TODO: AIOSEO without its Post model API (versions before 4.0). Writing its
					// table directly would bypass AIOSEO's own caching, so it is not done here.
					return new WP_Error( 'draftly_aioseo_unsupported', __( 'This version of All in One SEO does not support updates from Draftly. Update All in One SEO and try again.', 'draftly' ) );
				}
				$data = array();
				if ( null !== $title ) {
					$data['title'] = $title;
				}
				if ( null !== $description ) {
					$data['description'] = $description;
				}
				if ( $data ) {
					$model::savePost( $post_id, $data );
				}
				break;
			default:
				if ( null !== $description ) {
					$saved = wp_update_post(
						array(
							'ID'           => $post_id,
							'post_excerpt' => $description,
						),
						true
					);
					if ( is_wp_error( $saved ) ) {
						return $saved;
					}
				}
		}
		return self::get( $post_id );
	}

	/**
	 * Updates one meta key unless the value is null.
	 *
	 * @param int         $post_id Post id.
	 * @param string      $key     Meta key.
	 * @param string|null $value   Value.
	 */
	private static function update( $post_id, $key, $value ) {
		if ( null !== $value ) {
			update_post_meta( $post_id, $key, $value );
		}
	}

	/**
	 * Normalised shape.
	 *
	 * @param mixed  $title       Title.
	 * @param mixed  $description Description.
	 * @param string $source      Source.
	 * @return array
	 */
	private static function shape( $title, $description, $source ) {
		return array(
			'title'       => is_string( $title ) && '' !== $title ? $title : null,
			'description' => is_string( $description ) && '' !== $description ? $description : null,
			'source'      => $source,
		);
	}
}

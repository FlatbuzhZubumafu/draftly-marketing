<?php
/**
 * The connection to Draftly: stored credentials, the connect handshake and
 * signed calls to the Draftly API.
 *
 * Nothing in this file contacts Draftly until an administrator clicks
 * "Connect to Draftly".
 *
 * @package Draftly
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Stores the connection and talks to Draftly.
 */
class Draftly_Connection {

	/** Option holding the live connection (never autoloaded). */
	const OPTION = 'draftly_connection';

	/** Option holding a connect request in progress (never autoloaded). */
	const PENDING_OPTION = 'draftly_pending_connect';

	/** Option holding the free-posts counter Draftly last reported (Free accounts only). */
	const FREE_POSTS_OPTION = 'draftly_free_posts';

	/** Option holding the auto-mode state Draftly last reported (never autoloaded). */
	const AUTO_MODE_OPTION = 'draftly_auto_mode';

	/** When connection_status was last asked for (success or not), so screens don't ask on every load. */
	const STATUS_CHECKED_OPTION = 'draftly_status_checked';

	/** Route Draftly signs plugin requests over. */
	const API_ROUTE = '/wordpress-plugin';

	/**
	 * Draftly API endpoint. Overridable with DRAFTLY_API_URL in wp-config.php (development only).
	 *
	 * @return string
	 */
	public static function api_url() {
		return defined( 'DRAFTLY_API_URL' ) ? DRAFTLY_API_URL : 'https://app.draftly.blog/api/wordpress-plugin';
	}

	/**
	 * A fingerprint of this WordPress install: where it lives on disk, which
	 * database and table prefix it uses, and which (sub-)site it is. A staging
	 * clone or copied site carries the same options, secret included, but
	 * almost never the same install (H1).
	 *
	 * @return string
	 */
	public static function fingerprint() {
		global $wpdb;
		$parts = array(
			defined( 'ABSPATH' ) ? ABSPATH : '',
			defined( 'DB_NAME' ) ? DB_NAME : '',
			defined( 'DB_HOST' ) ? DB_HOST : '',
			isset( $wpdb->base_prefix ) ? $wpdb->base_prefix : '',
			(string) get_current_blog_id(),
		);
		return hash( 'sha256', implode( '|', $parts ) );
	}

	/**
	 * A site address for comparison: host (lowercase), port and path; no scheme or trailing slash.
	 *
	 * @param string $url URL.
	 * @return string
	 */
	public static function address_key( $url ) {
		$parts = wp_parse_url( (string) $url );
		if ( ! is_array( $parts ) || empty( $parts['host'] ) ) {
			return '';
		}
		$port = isset( $parts['port'] ) && ! in_array( (int) $parts['port'], array( 80, 443 ), true ) ? ':' . (int) $parts['port'] : '';
		return strtolower( $parts['host'] ) . $port . untrailingslashit( isset( $parts['path'] ) ? $parts['path'] : '' );
	}

	/**
	 * When this install is a copy of the connected site (a staging clone, or a
	 * site copied to a new address): the connected site's address. Otherwise ''.
	 *
	 * @param array|null $conn Connection (default: the stored one).
	 * @return string
	 */
	public static function copy_of( $conn = null ) {
		$conn = null === $conn ? self::get() : $conn;
		if ( ! $conn ) {
			return '';
		}
		$bound = isset( $conn['home_url'] ) ? (string) $conn['home_url'] : '';
		$moved = '' !== $bound && self::address_key( $bound ) !== self::address_key( home_url() );
		$other = ! empty( $conn['fingerprint'] ) && ! hash_equals( (string) $conn['fingerprint'], self::fingerprint() );
		if ( ! $moved && ! $other ) {
			return '';
		}
		return '' !== $bound ? $bound : (string) ( $conn['site_url'] ?? '' );
	}

	/**
	 * "This looks like a copy of example.com. Connect it separately."
	 *
	 * @param string $original The connected site's address.
	 * @return string
	 */
	public static function copy_message( $original ) {
		$host = wp_parse_url( $original, PHP_URL_HOST );
		/* translators: %s: the address of the site Draftly is connected to */
		return sprintf( __( 'This looks like a copy of %s. Connect it separately.', 'draftly' ), $host ? $host : $original );
	}

	/**
	 * Connections saved by 1.1.0 or earlier have no binding: bind them to this
	 * install the first time 1.1.1 sees them (Draftly also checks the address).
	 */
	public static function bind_legacy() {
		$conn = get_option( self::OPTION );
		if ( is_array( $conn ) && ! empty( $conn['connection_id'] ) && empty( $conn['fingerprint'] ) ) {
			$conn['home_url']    = home_url();
			$conn['fingerprint'] = self::fingerprint();
			self::save( $conn );
		}
	}

	/**
	 * The stored connection, or null.
	 *
	 * @return array|null
	 */
	public static function get() {
		$conn = get_option( self::OPTION );
		if ( ! is_array( $conn ) || empty( $conn['connection_id'] ) || empty( $conn['secret'] ) ) {
			return null;
		}
		return $conn;
	}

	/**
	 * Saves the connection. autoload is off so the secret isn't loaded on every request.
	 *
	 * @param array $conn Connection.
	 */
	public static function save( array $conn ) {
		delete_option( self::OPTION );
		add_option( self::OPTION, $conn, '', false );
	}

	/**
	 * Forgets the connection and any pending request.
	 */
	public static function forget() {
		delete_option( self::OPTION );
		delete_option( self::PENDING_OPTION );
		delete_option( self::FREE_POSTS_OPTION );
		delete_option( self::AUTO_MODE_OPTION );
		delete_option( self::STATUS_CHECKED_OPTION );
	}

	/**
	 * Whether the connection has been verified by Draftly.
	 *
	 * @return bool
	 */
	public static function is_active() {
		$conn = self::get();
		return $conn && 'active' === ( $conn['status'] ?? '' );
	}

	/**
	 * The pending connect request, if it hasn't expired.
	 *
	 * @return array|null
	 */
	public static function pending() {
		$pending = get_option( self::PENDING_OPTION );
		if ( ! is_array( $pending ) || empty( $pending['request_id'] ) || (int) ( $pending['expires'] ?? 0 ) < time() ) {
			return null;
		}
		return $pending;
	}

	/**
	 * Starts a connect request with Draftly. Returns the URL to open, or a WP_Error.
	 * Called only from the "Connect to Draftly" button (manage_options + nonce).
	 *
	 * @return string|WP_Error
	 */
	public static function start() {
		$verifier = wp_generate_password( 64, false, false );
		$response = self::post_json(
			array(
				'action'         => 'start',
				'site_url'       => site_url(),
				'rest_url'       => rest_url(),
				'return_url'     => admin_url( 'admin.php?page=draftly-connection' ),
				'plugin_version' => DRAFTLY_VERSION,
				'wp_version'     => get_bloginfo( 'version' ),
				'challenge'      => Draftly_Signature::pkce_challenge( $verifier ),
			),
			array(),
			20
		);
		if ( is_wp_error( $response ) ) {
			return $response;
		}
		if ( empty( $response['request_id'] ) || empty( $response['connect_url'] ) ) {
			return new WP_Error( 'draftly_start_failed', __( 'Draftly did not return a connection link. Try again.', 'draftly' ) );
		}
		delete_option( self::PENDING_OPTION );
		add_option(
			self::PENDING_OPTION,
			array(
				'request_id' => sanitize_text_field( $response['request_id'] ),
				'verifier'   => $verifier,
				'expires'    => time() + (int) ( $response['expires_in'] ?? 900 ),
				'user_id'    => get_current_user_id(),
			),
			'',
			false
		);
		return esc_url_raw( $response['connect_url'] );
	}

	/**
	 * Asks Draftly whether the pending request was approved and, if so, collects
	 * the site secret (once). Returns the status string.
	 *
	 * @return string pending|approved|denied|expired|none|error
	 */
	public static function exchange() {
		$pending = self::pending();
		if ( ! $pending ) {
			return self::get() ? 'approved' : 'none';
		}
		$response = self::post_json(
			array(
				'action'     => 'exchange',
				'request_id' => $pending['request_id'],
				'verifier'   => $pending['verifier'],
			),
			array(),
			20
		);
		if ( is_wp_error( $response ) ) {
			// 404 / 409 answers still carry a status (not_found, already_exchanged).
			$data     = $response->get_error_data();
			$response = is_array( $data ) && isset( $data['status'] ) && is_string( $data['status'] ) ? array( 'status' => $data['status'] ) : array( 'status' => 'error' );
		}
		$status = isset( $response['status'] ) ? sanitize_key( $response['status'] ) : 'error';
		if ( 'approved' === $status && ! empty( $response['secret'] ) && ! empty( $response['connection_id'] ) ) {
			self::save(
				array(
					'connection_id' => sanitize_text_field( $response['connection_id'] ),
					'secret'        => (string) $response['secret'],
					'account_email' => sanitize_email( $response['account_email'] ?? '' ),
					'site_url'      => esc_url_raw( $response['site_url'] ?? site_url() ),
					'user_id'       => (int) ( $pending['user_id'] ?? get_current_user_id() ),
					'connected_at'  => time(),
					'status'        => 'pending_verification',
					// Bound to this install (H1): a copy of the site won't act on this connection.
					'home_url'      => home_url(),
					'fingerprint'   => self::fingerprint(),
				)
			);
			delete_option( self::PENDING_OPTION );
			self::request_verification();
			return 'approved';
		}
		if ( in_array( $status, array( 'denied', 'expired', 'already_exchanged', 'not_found' ), true ) ) {
			delete_option( self::PENDING_OPTION );
		}
		return $status;
	}

	/**
	 * Asks Draftly to reach this site and confirm it holds the secret.
	 * Draftly answers at once and calls back afterwards.
	 */
	public static function request_verification() {
		self::signed( 'verify', array(), 15 );
	}

	/**
	 * Account and connection state from Draftly. Updates the stored status,
	 * the auto-mode state and the free-posts counter, and fills in post
	 * statuses this site is missing from Draftly's record.
	 *
	 * @param int $timeout Seconds to wait for Draftly.
	 * @return array|WP_Error
	 */
	public static function refresh_status( $timeout = 15 ) {
		update_option( self::STATUS_CHECKED_OPTION, time(), false );
		$status = self::signed( 'connection_status', array(), $timeout );
		if ( is_wp_error( $status ) ) {
			return $status;
		}
		self::remember_free_posts( $status );
		self::remember_auto_mode( $status['auto_mode'] ?? null );
		if ( isset( $status['post_statuses'] ) && is_array( $status['post_statuses'] ) ) {
			Draftly_Posts::reconcile( $status['post_statuses'] );
		}
		$conn    = self::get();
		$current = $conn['status'] ?? '';
		if ( $conn && ! empty( $status['status'] ) && $current !== $status['status'] ) {
			$conn['status'] = sanitize_key( $status['status'] );
			self::save( $conn );
		}
		return $status;
	}

	/**
	 * Keeps the free-posts counter Draftly sends with each answer (Free accounts only).
	 * Draftly enforces the limit; this copy is only for the "Free: N of M posts used" line.
	 *
	 * @param array $data Draftly's response or error data.
	 */
	public static function remember_free_posts( $data ) {
		if ( ! is_array( $data ) || ! array_key_exists( 'free_posts_limit', $data ) ) {
			return;
		}
		if ( is_numeric( $data['free_posts_limit'] ) && isset( $data['free_posts_used'] ) && is_numeric( $data['free_posts_used'] ) ) {
			update_option(
				self::FREE_POSTS_OPTION,
				array(
					'used'  => absint( $data['free_posts_used'] ),
					'limit' => absint( $data['free_posts_limit'] ),
				),
				false
			);
		} else {
			delete_option( self::FREE_POSTS_OPTION );
		}
	}

	/**
	 * The last free-posts counter from Draftly, or null for accounts without one.
	 *
	 * @return array|null { used: int, limit: int }
	 */
	public static function free_posts() {
		$value = get_option( self::FREE_POSTS_OPTION );
		return is_array( $value ) && isset( $value['used'], $value['limit'] ) ? $value : null;
	}

	/**
	 * Keeps the auto-mode state Draftly sends (switch, level, exclusions, last run,
	 * allowance left). Draftly is the source of truth; this copy is for display.
	 *
	 * @param mixed $state Draftly's auto_mode object.
	 */
	public static function remember_auto_mode( $state ) {
		if ( ! is_array( $state ) ) {
			return;
		}
		$run   = is_array( $state['last_run'] ?? null ) ? $state['last_run'] : null;
		$allow = is_array( $state['allowance'] ?? null ) ? $state['allowance'] : null;
		$clean = array(
			'eligible'              => ! empty( $state['eligible'] ),
			'reason'                => sanitize_key( (string) ( $state['reason'] ?? '' ) ),
			'message'               => sanitize_text_field( (string) ( $state['message'] ?? '' ) ),
			'enabled'               => ! empty( $state['enabled'] ),
			'level'                 => 'full' === ( $state['level'] ?? '' ) ? 'full' : 'safe',
			'excluded_post_ids'     => array_values( array_filter( array_map( 'absint', (array) ( $state['excluded_post_ids'] ?? array() ) ) ) ),
			'excluded_category_ids' => array_values( array_filter( array_map( 'absint', (array) ( $state['excluded_category_ids'] ?? array() ) ) ) ),
			'paused_reason'         => sanitize_key( (string) ( $state['paused_reason'] ?? '' ) ),
			'disabled_globally'     => ! empty( $state['disabled_globally'] ),
			'allowance'             => $allow ? sanitize_text_field( (string) ( $allow['label'] ?? '' ) ) : '',
			'last_run'              => null,
			'updated'               => time(),
		);
		if ( $run ) {
			$clean['last_run'] = array(
				'id'              => preg_replace( '/[^A-Za-z0-9-]/', '', (string) ( $run['id'] ?? '' ) ),
				'trigger'         => sanitize_key( (string) ( $run['trigger'] ?? '' ) ),
				'level'           => sanitize_key( (string) ( $run['level'] ?? '' ) ),
				'status'          => sanitize_key( (string) ( $run['status'] ?? '' ) ),
				'started_at'      => sanitize_text_field( (string) ( $run['started_at'] ?? '' ) ),
				'finished_at'     => sanitize_text_field( (string) ( $run['finished_at'] ?? '' ) ),
				'posts_processed' => absint( $run['posts_processed'] ?? 0 ),
				'changes_applied' => absint( $run['changes_applied'] ?? 0 ),
				'error_count'     => absint( $run['error_count'] ?? 0 ),
				'stop_reason'     => sanitize_key( (string) ( $run['stop_reason'] ?? '' ) ),
				'reverted'        => ! empty( $run['reverted_at'] ),
			);
		}
		update_option( self::AUTO_MODE_OPTION, $clean, false );
	}

	/**
	 * The auto-mode state Draftly last reported, or null before the first answer.
	 *
	 * @return array|null
	 */
	public static function auto_mode() {
		$value = get_option( self::AUTO_MODE_OPTION );
		return is_array( $value ) ? $value : null;
	}

	/**
	 * Disconnects on both sides. The local credentials are removed even if Draftly can't be reached.
	 *
	 * @param int $timeout Seconds to wait for Draftly.
	 */
	public static function disconnect( $timeout = 10 ) {
		// A copy of the site forgets locally only: revoking would disconnect the original site (H1).
		if ( self::get() && '' === self::copy_of() ) {
			self::signed( 'disconnect', array(), $timeout );
		}
		self::forget();
	}

	/**
	 * A signed call to Draftly.
	 *
	 * @param string $action  Action.
	 * @param array  $payload Payload.
	 * @param int    $timeout Seconds.
	 * @return array|WP_Error
	 */
	public static function signed( $action, array $payload, $timeout = 30 ) {
		$conn = self::get();
		if ( ! $conn ) {
			return new WP_Error( 'draftly_not_connected', __( 'This site is not connected to Draftly.', 'draftly' ) );
		}
		$original = self::copy_of( $conn );
		if ( '' !== $original ) {
			return new WP_Error( 'site_copy', self::copy_message( $original ), array( 'http_status' => 409 ) );
		}
		// The plugin version rides along so Draftly knows which features this
		// site has; the site address lets Draftly refuse a copy of the site.
		$body    = wp_json_encode(
			array_merge(
				$payload,
				array(
					'action'         => $action,
					'plugin_version' => defined( 'DRAFTLY_VERSION' ) ? DRAFTLY_VERSION : '',
					'site_url'       => site_url(),
				)
			)
		);
		$headers = Draftly_Signature::headers( $conn['secret'], $conn['connection_id'], 'POST', self::API_ROUTE, array(), $body );
		$result  = self::post_json( null, $headers, $timeout, $body );
		if ( is_wp_error( $result ) && 'revoked' === $result->get_error_code() ) {
			// Draftly no longer knows this connection (disconnected in the app, or reconnected elsewhere).
			self::forget();
		}
		if ( class_exists( 'Draftly_Activity' ) && ! in_array( $action, array( 'connection_status', 'post_status' ), true ) ) {
			Draftly_Activity::log_result( $action, $result, $payload );
		}
		return $result;
	}

	/**
	 * POSTs JSON to Draftly and decodes the answer.
	 *
	 * @param array|null  $payload Payload (ignored when $raw is given).
	 * @param array       $headers Extra headers.
	 * @param int         $timeout Seconds.
	 * @param string|null $raw     Pre-encoded body (signed requests).
	 * @return array|WP_Error
	 */
	private static function post_json( $payload, array $headers, $timeout, $raw = null ) {
		$response = wp_remote_post(
			self::api_url(),
			array(
				'timeout' => $timeout,
				'headers' => array_merge(
					array(
						'Content-Type' => 'application/json',
						'Accept'       => 'application/json',
					),
					$headers
				),
				'body'    => null !== $raw ? $raw : wp_json_encode( $payload ),
			)
		);
		if ( is_wp_error( $response ) ) {
			return new WP_Error( 'draftly_unreachable', __( 'Could not reach Draftly, or it took too long to answer. Try again in a minute.', 'draftly' ), array( 'retryable' => true ) );
		}
		$code = (int) wp_remote_retrieve_response_code( $response );
		$data = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( ! is_array( $data ) ) {
			$data = array();
		}
		if ( $code >= 400 ) {
			$error_code = isset( $data['code'] ) ? sanitize_key( $data['code'] ) : 'draftly_http_' . $code;
			$message    = isset( $data['error'] ) && is_string( $data['error'] ) ? sanitize_text_field( $data['error'] ) : __( 'Draftly could not finish this request. Try again in a minute.', 'draftly' );
			return new WP_Error( $error_code, $message, array_merge( $data, array( 'http_status' => $code ) ) );
		}
		return $data;
	}
}

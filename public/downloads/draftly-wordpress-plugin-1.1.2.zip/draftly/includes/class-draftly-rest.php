<?php
/**
 * REST routes Draftly calls (namespace draftly/v1).
 *
 * Every route requires a request signed with this site's secret (see
 * Draftly_Signature): no WordPress password or application password is
 * involved. A valid request acts as the administrator who connected the site,
 * so it can never do more than that user can.
 *
 *   GET  /status?challenge=        proof that this site holds the secret
 *   GET  /posts                    list posts (status, page, per_page, search, include_content)
 *   GET  /posts/{id}               one post: raw and rendered body, excerpt, SEO meta
 *   POST /posts                    create (publishing from Draftly)
 *   POST /posts/{id}               update content, title, excerpt and SEO meta only (status, date,
 *                                  featured image, slug... are refused with 400). Before the save
 *                                  the post is snapshotted for Revert. expected_modified_gmt and
 *                                  expected_hash (409 if the post changed since Draftly read it),
 *                                  draftly { state, run_id, source } (the post's Draftly status).
 *                                  403 draftly_unfiltered_html when WordPress's HTML filtering
 *                                  would change the post for the connected user.
 *   POST /posts/{id}/revert        undo Draftly's last change from the snapshot; 409 if the post
 *                                  was edited since, unless { force: true }
 *   POST /disconnect               Draftly disconnected this site; forget the secret
 *
 * @package Draftly
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers and serves the draftly/v1 routes.
 */
class Draftly_Rest {

	const NAMESPACE_V1 = 'draftly/v1';

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register' ) );
	}

	/**
	 * Registers the routes.
	 */
	public static function register() {
		$signed = array( __CLASS__, 'authorize' );
		$id     = array(
			'id' => array(
				'validate_callback' => static function ( $value ) {
					return is_numeric( $value ) && (int) $value > 0;
				},
			),
		);

		register_rest_route(
			self::NAMESPACE_V1,
			'/status',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'status' ),
				'permission_callback' => $signed,
			)
		);
		register_rest_route(
			self::NAMESPACE_V1,
			'/posts',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( __CLASS__, 'list_posts' ),
					'permission_callback' => $signed,
				),
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( __CLASS__, 'create_post' ),
					'permission_callback' => $signed,
				),
			)
		);
		register_rest_route(
			self::NAMESPACE_V1,
			'/posts/(?P<id>\d+)',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( __CLASS__, 'get_post' ),
					'permission_callback' => $signed,
					'args'                => $id,
				),
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( __CLASS__, 'update_post' ),
					'permission_callback' => $signed,
					'args'                => $id,
				),
			)
		);
		register_rest_route(
			self::NAMESPACE_V1,
			'/posts/(?P<id>\d+)/revert',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'revert_post' ),
				'permission_callback' => $signed,
				'args'                => $id,
			)
		);
		register_rest_route(
			self::NAMESPACE_V1,
			'/disconnect',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'disconnect' ),
				'permission_callback' => $signed,
			)
		);
	}

	/**
	 * Permission check for every route: a fresh, correctly signed request from Draftly.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return true|WP_Error
	 */
	public static function authorize( WP_REST_Request $request ) {
		$conn = Draftly_Connection::get();
		if ( ! $conn ) {
			return new WP_Error( 'draftly_not_connected', 'This site is not connected to Draftly.', array( 'status' => 401 ) );
		}
		$query = $request->get_query_params();
		foreach ( $query as $value ) {
			if ( is_array( $value ) ) {
				return new WP_Error( 'draftly_bad_request', 'Unsupported query.', array( 'status' => 400 ) );
			}
		}
		$result = Draftly_Signature::verify(
			$conn['secret'],
			$conn['connection_id'],
			array(
				'connection' => (string) $request->get_header( 'x_draftly_connection' ),
				'timestamp'  => (string) $request->get_header( 'x_draftly_timestamp' ),
				'nonce'      => (string) $request->get_header( 'x_draftly_nonce' ),
				'signature'  => (string) $request->get_header( 'x_draftly_signature' ),
			),
			$request->get_method(),
			$request->get_route(),
			$query,
			$request->get_body(),
			time()
		);
		if ( true !== $result ) {
			return new WP_Error( 'draftly_bad_signature', 'Request signature rejected: ' . $result, array( 'status' => 401 ) );
		}
		// A copy of the connected site (staging clone) holds the same secret but must not act for it (H1).
		$original = Draftly_Connection::copy_of( $conn );
		if ( '' !== $original ) {
			Draftly_Activity::add(
				'request',
				false,
				array(
					'source'  => 'draftly',
					'code'    => 'draftly_site_copy',
					'message' => Draftly_Connection::copy_message( $original ),
				)
			);
			return new WP_Error( 'draftly_site_copy', Draftly_Connection::copy_message( $original ), array( 'status' => 409 ) );
		}
		// Each nonce is accepted once within the signature's lifetime.
		$nonce_key = 'draftly_n_' . md5( (string) $request->get_header( 'x_draftly_nonce' ) );
		if ( get_transient( $nonce_key ) ) {
			return new WP_Error( 'draftly_replay', 'Request already used.', array( 'status' => 401 ) );
		}
		set_transient( $nonce_key, 1, 2 * Draftly_Signature::MAX_SKEW_SECONDS );

		// Act as the administrator who connected the site, never as anyone more powerful.
		$user_id = (int) ( $conn['user_id'] ?? 0 );
		if ( ! $user_id || ! user_can( $user_id, 'edit_posts' ) ) {
			return new WP_Error( 'draftly_no_user', 'The WordPress user who connected Draftly can no longer edit posts. Reconnect from Draftly > Connection.', array( 'status' => 403 ) );
		}
		wp_set_current_user( $user_id );
		return true;
	}

	/**
	 * GET /status.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function status( WP_REST_Request $request ) {
		$conn      = Draftly_Connection::get();
		$challenge = (string) $request->get_param( 'challenge' );
		$out       = array(
			'ok'             => true,
			'plugin_version' => DRAFTLY_VERSION,
			'wp_version'     => get_bloginfo( 'version' ),
			'seo_plugin'     => Draftly_Seo_Meta::provider(),
		);
		if ( '' !== $challenge && preg_match( '/^[A-Za-z0-9_-]{16,64}$/', $challenge ) ) {
			$out['proof'] = Draftly_Signature::verification_proof( $conn['secret'], $conn['connection_id'], $challenge );
			// Draftly reached the site and is checking the proof: it will mark the connection active.
			if ( 'active' !== ( $conn['status'] ?? '' ) ) {
				$conn['status'] = 'active';
				Draftly_Connection::save( $conn );
			}
		}
		return rest_ensure_response( $out );
	}

	/**
	 * GET /posts.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function list_posts( WP_REST_Request $request ) {
		$status   = sanitize_key( (string) $request->get_param( 'status' ) );
		$statuses = array( 'publish', 'draft', 'pending', 'private', 'future' );
		$per_page = min( 100, max( 1, (int) ( $request->get_param( 'per_page' ) ? $request->get_param( 'per_page' ) : 20 ) ) );
		$page     = max( 1, (int) ( $request->get_param( 'page' ) ? $request->get_param( 'page' ) : 1 ) );
		$query    = new WP_Query(
			array(
				'post_type'           => Draftly_Posts::POST_TYPES,
				'post_status'         => in_array( $status, $statuses, true ) ? $status : ( 'any' === $status ? $statuses : 'publish' ),
				'posts_per_page'      => $per_page,
				'paged'               => $page,
				's'                   => sanitize_text_field( (string) $request->get_param( 'search' ) ),
				'orderby'             => 'date',
				'order'               => 'DESC',
				'ignore_sticky_posts' => true,
				'no_found_rows'       => false,
			)
		);
		$include  = (bool) $request->get_param( 'include_content' );
		$posts    = array();
		foreach ( $query->posts as $post ) {
			$posts[] = Draftly_Posts::summary( $post, $include );
		}
		return rest_ensure_response(
			array(
				'posts'       => $posts,
				'total'       => (int) $query->found_posts,
				'total_pages' => (int) $query->max_num_pages,
			)
		);
	}

	/**
	 * A post Draftly may work on, or an error.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_Post|WP_Error
	 */
	private static function post_from( WP_REST_Request $request ) {
		$post = get_post( (int) $request['id'] );
		if ( ! $post || ! in_array( $post->post_type, Draftly_Posts::POST_TYPES, true ) || 'trash' === $post->post_status ) {
			return new WP_Error( 'draftly_not_found', 'Post not found.', array( 'status' => 404 ) );
		}
		if ( ! current_user_can( 'edit_post', $post->ID ) ) {
			return new WP_Error( 'draftly_forbidden', 'The connected user cannot edit this post.', array( 'status' => 403 ) );
		}
		return $post;
	}

	/**
	 * GET /posts/{id}.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function get_post( WP_REST_Request $request ) {
		$post = self::post_from( $request );
		return is_wp_error( $post ) ? $post : rest_ensure_response( Draftly_Posts::detail( $post ) );
	}

	/**
	 * Decoded JSON body.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return array
	 */
	private static function body( WP_REST_Request $request ) {
		$data = json_decode( $request->get_body(), true );
		return is_array( $data ) ? $data : array();
	}

	/**
	 * POST /posts (publish from Draftly).
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function create_post( WP_REST_Request $request ) {
		if ( ! current_user_can( 'edit_posts' ) ) {
			return new WP_Error( 'draftly_forbidden', 'The connected user cannot create posts.', array( 'status' => 403 ) );
		}
		$post = Draftly_Posts::create( self::body( $request ) );
		Draftly_Activity::log_incoming( 'create', is_wp_error( $post ) ? 0 : $post->ID, $post );
		if ( is_wp_error( $post ) ) {
			return $post;
		}
		return rest_ensure_response( self::saved( $post ) );
	}

	/**
	 * POST /posts/{id}.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function update_post( WP_REST_Request $request ) {
		$post = self::post_from( $request );
		if ( is_wp_error( $post ) ) {
			return $post;
		}
		$saved = Draftly_Posts::update( $post, self::body( $request ) );
		Draftly_Activity::log_incoming( 'update', $post->ID, $saved );
		if ( is_wp_error( $saved ) ) {
			return $saved;
		}
		return rest_ensure_response( self::saved( $saved ) );
	}

	/**
	 * POST /posts/{id}/revert.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function revert_post( WP_REST_Request $request ) {
		$post = self::post_from( $request );
		if ( is_wp_error( $post ) ) {
			return $post;
		}
		$body     = self::body( $request );
		$restored = Draftly_Posts::revert( $post, ! empty( $body['force'] ) && true === $body['force'] );
		Draftly_Activity::log_incoming( 'revert', $post->ID, $restored );
		if ( is_wp_error( $restored ) ) {
			return $restored;
		}
		return rest_ensure_response( self::saved( $restored ) );
	}

	/**
	 * POST /disconnect.
	 *
	 * @return WP_REST_Response
	 */
	public static function disconnect() {
		Draftly_Activity::log_incoming( 'disconnect', 0, true );
		Draftly_Connection::forget();
		return rest_ensure_response( array( 'ok' => true ) );
	}

	/**
	 * Response for a saved post.
	 *
	 * @param WP_Post $post Post.
	 * @return array
	 */
	private static function saved( WP_Post $post ) {
		return array(
			'id'              => $post->ID,
			'link'            => get_permalink( $post ),
			'status'          => $post->post_status,
			'meta'            => Draftly_Seo_Meta::get( $post->ID ),
			'can_revert'      => Draftly_Posts::can_revert( $post->ID ),
			// The post's modified time after this save, and the revision Revert restores.
			'modified_gmt'    => $post->post_modified_gmt,
			'content_hash'    => Draftly_Posts::content_hash( $post ),
			'revert_revision' => Draftly_Posts::revert_revision( $post->ID ),
		);
	}
}

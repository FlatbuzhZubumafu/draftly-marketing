<?php
/**
 * Request signing shared with Draftly.
 *
 * Every request between this site and Draftly after connecting is signed with
 * the per-site secret (HMAC-SHA256) over:
 *
 *   DRAFTLY-HMAC-SHA256\n<connection id>\n<METHOD>\n<route>\n<canonical query>\n<timestamp>\n<nonce>\n<sha256 hex of body>
 *
 * Draftly builds the identical string (supabase/functions/_shared/wp-plugin-signing.ts
 * in the Draftly app). The receiver rejects timestamps more than five minutes
 * off and nonces it has already seen.
 *
 * @package Draftly
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * HMAC signing and verification helpers.
 */
class Draftly_Signature {

	const SCHEME            = 'DRAFTLY-HMAC-SHA256';
	const MAX_SKEW_SECONDS  = 300;
	const HEADER_CONNECTION = 'X-Draftly-Connection';
	const HEADER_TIMESTAMP  = 'X-Draftly-Timestamp';
	const HEADER_NONCE      = 'X-Draftly-Nonce';
	const HEADER_SIGNATURE  = 'X-Draftly-Signature';

	/**
	 * Sorted key=value pairs, RFC 3986 encoded. rest_route is transport, not part of the request.
	 *
	 * @param array $query Query parameters.
	 * @return string
	 */
	public static function canonical_query( array $query ) {
		unset( $query['rest_route'] );
		$pairs = array();
		foreach ( $query as $key => $value ) {
			if ( null === $value || is_array( $value ) || is_object( $value ) ) {
				continue;
			}
			$pairs[ (string) $key ] = (string) $value;
		}
		ksort( $pairs, SORT_STRING );
		$out = array();
		foreach ( $pairs as $key => $value ) {
			$out[] = rawurlencode( $key ) . '=' . rawurlencode( $value );
		}
		return implode( '&', $out );
	}

	/**
	 * The string that gets signed.
	 *
	 * @param string $connection_id Connection id.
	 * @param string $method        HTTP method.
	 * @param string $route         Route, e.g. /draftly/v1/posts.
	 * @param array  $query         Query parameters.
	 * @param int    $timestamp     Unix seconds.
	 * @param string $nonce         Random nonce.
	 * @param string $body          Raw body.
	 * @return string
	 */
	public static function canonical_string( $connection_id, $method, $route, array $query, $timestamp, $nonce, $body ) {
		return implode(
			"\n",
			array(
				self::SCHEME,
				$connection_id,
				strtoupper( $method ),
				$route,
				self::canonical_query( $query ),
				(string) $timestamp,
				$nonce,
				hash( 'sha256', (string) $body ),
			)
		);
	}

	/**
	 * Hex HMAC-SHA256 signature.
	 *
	 * @param string $secret Per-site secret.
	 * @param string $connection_id Connection id.
	 * @param string $method HTTP method.
	 * @param string $route Route.
	 * @param array  $query Query.
	 * @param int    $timestamp Unix seconds.
	 * @param string $nonce Nonce.
	 * @param string $body Raw body.
	 * @return string
	 */
	public static function sign( $secret, $connection_id, $method, $route, array $query, $timestamp, $nonce, $body ) {
		return hash_hmac( 'sha256', self::canonical_string( $connection_id, $method, $route, $query, $timestamp, $nonce, $body ), $secret );
	}

	/**
	 * A fresh base64url nonce.
	 *
	 * @return string
	 */
	public static function nonce() {
		return self::base64url( random_bytes( 16 ) );
	}

	/**
	 * Base64url without padding.
	 *
	 * @param string $bytes Raw bytes.
	 * @return string
	 */
	public static function base64url( $bytes ) {
		// base64 here is encoding for transport, not obfuscation.
		return rtrim( strtr( base64_encode( $bytes ), '+/', '-_' ), '=' ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
	}

	/**
	 * Headers for a signed request.
	 *
	 * @param string $secret Secret.
	 * @param string $connection_id Connection id.
	 * @param string $method Method.
	 * @param string $route Route.
	 * @param array  $query Query.
	 * @param string $body Body.
	 * @return array
	 */
	public static function headers( $secret, $connection_id, $method, $route, array $query, $body ) {
		$timestamp = time();
		$nonce     = self::nonce();
		return array(
			self::HEADER_CONNECTION => $connection_id,
			self::HEADER_TIMESTAMP  => (string) $timestamp,
			self::HEADER_NONCE      => $nonce,
			self::HEADER_SIGNATURE  => self::sign( $secret, $connection_id, $method, $route, $query, $timestamp, $nonce, $body ),
		);
	}

	/**
	 * Checks a signature and its freshness. Nonce reuse is checked by the caller.
	 *
	 * @param string $secret        Secret.
	 * @param string $connection_id Expected connection id.
	 * @param array  $given         Headers: connection, timestamp, nonce, signature.
	 * @param string $method        Method.
	 * @param string $route         Route.
	 * @param array  $query         Query.
	 * @param string $body          Body.
	 * @param int    $now           Unix seconds.
	 * @return true|string True, or a reason: missing, malformed, wrong_connection, stale, bad_signature.
	 */
	public static function verify( $secret, $connection_id, array $given, $method, $route, array $query, $body, $now ) {
		foreach ( array( 'connection', 'timestamp', 'nonce', 'signature' ) as $key ) {
			if ( empty( $given[ $key ] ) || ! is_string( $given[ $key ] ) ) {
				return 'missing';
			}
		}
		if ( ! preg_match( '/^\d{1,12}$/', $given['timestamp'] ) || ! preg_match( '/^[A-Za-z0-9_-]{16,64}$/', $given['nonce'] ) || ! preg_match( '/^[0-9a-f]{64}$/', $given['signature'] ) ) {
			return 'malformed';
		}
		if ( ! hash_equals( strtolower( $connection_id ), strtolower( $given['connection'] ) ) ) {
			return 'wrong_connection';
		}
		if ( abs( $now - (int) $given['timestamp'] ) > self::MAX_SKEW_SECONDS ) {
			return 'stale';
		}
		$expected = self::sign( $secret, $connection_id, $method, $route, $query, (int) $given['timestamp'], $given['nonce'], $body );
		if ( ! hash_equals( $expected, $given['signature'] ) ) {
			return 'bad_signature';
		}
		return true;
	}

	/**
	 * Proof for Draftly's site verification: shows this site holds the secret.
	 *
	 * @param string $secret Secret.
	 * @param string $connection_id Connection id.
	 * @param string $challenge Challenge from Draftly.
	 * @return string
	 */
	public static function verification_proof( $secret, $connection_id, $challenge ) {
		return hash_hmac( 'sha256', "draftly-verify\n" . $connection_id . "\n" . $challenge, $secret );
	}

	/**
	 * PKCE S256 challenge for a verifier.
	 *
	 * @param string $verifier Verifier.
	 * @return string
	 */
	public static function pkce_challenge( $verifier ) {
		return self::base64url( hash( 'sha256', $verifier, true ) );
	}
}

<?php
/**
 * Admin screens: Draftly (optimize posts), Draftly > Connection and Draftly >
 * Support. Draftly > Settings (auto mode) is in class-draftly-auto-mode.php.
 *
 * Notices are only shown on Draftly's own screens. Nothing here calls Draftly
 * until the site is connected, except the Connect button itself.
 *
 * @package Draftly
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Admin pages and AJAX handlers.
 */
class Draftly_Admin {

	const PAGE_POSTS      = 'draftly';
	const PAGE_CONNECTION = 'draftly-connection';
	const NONCE_AJAX      = 'draftly_admin';
	const PLANS_URL       = 'https://www.draftly.blog/wordpress-ai-plugin';
	const TOP_UP_URL      = 'https://app.draftly.blog/#settings?tab=billing';
	const PAGE_SUPPORT    = 'draftly-support';

	/** Copied to the clipboard by Draftly > Support; never shown on a screen unless copying fails. */
	const SUPPORT_EMAIL = 'preston@draftly.blog';

	/** Seconds between refreshes of Draftly's account state when the posts screen opens. */
	const STATUS_MAX_AGE = 300;

	/** Hosts Draftly's own links in error responses may point to. */
	const LINK_HOSTS = array( 'app.draftly.blog', 'www.draftly.blog', 'draftly.blog' );

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		// After Draftly > Settings (priority 20), so Support is last.
		add_action( 'admin_menu', array( __CLASS__, 'support_menu' ), 30 );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'admin_post_draftly_connect', array( __CLASS__, 'handle_connect' ) );
		add_action( 'admin_post_draftly_disconnect', array( __CLASS__, 'handle_disconnect' ) );
		add_action( 'admin_post_draftly_forget_copy', array( __CLASS__, 'handle_forget_copy' ) );
		add_action( 'admin_init', array( 'Draftly_Connection', 'bind_legacy' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( DRAFTLY_FILE ), array( __CLASS__, 'action_links' ) );
		foreach ( array( 'check', 'optimize', 'apply', 'revert', 'poll', 'verify', 'diagnostics' ) as $action ) {
			add_action( 'wp_ajax_draftly_' . $action, array( __CLASS__, 'ajax_' . $action ) );
		}
	}

	/**
	 * Menu: Draftly (edit_posts) and Draftly > Connection (manage_options).
	 */
	public static function menu() {
		add_menu_page(
			__( 'Draftly', 'draftly' ),
			__( 'Draftly', 'draftly' ),
			'edit_posts',
			self::PAGE_POSTS,
			array( __CLASS__, 'render_posts' ),
			'dashicons-edit-page',
			26
		);
		add_submenu_page( self::PAGE_POSTS, __( 'Optimize posts', 'draftly' ), __( 'Optimize posts', 'draftly' ), 'edit_posts', self::PAGE_POSTS, array( __CLASS__, 'render_posts' ) );
		add_submenu_page( self::PAGE_POSTS, __( 'Draftly connection', 'draftly' ), __( 'Connection', 'draftly' ), 'manage_options', self::PAGE_CONNECTION, array( __CLASS__, 'render_connection' ) );
	}

	/**
	 * Draftly > Support (edit_posts).
	 */
	public static function support_menu() {
		add_submenu_page( self::PAGE_POSTS, __( 'Draftly support', 'draftly' ), __( 'Support', 'draftly' ), 'edit_posts', self::PAGE_SUPPORT, array( __CLASS__, 'render_support' ) );
	}

	/**
	 * Settings link on the Plugins screen.
	 *
	 * @param array $links Links.
	 * @return array
	 */
	public static function action_links( $links ) {
		if ( current_user_can( 'manage_options' ) ) {
			array_unshift( $links, '<a href="' . esc_url( admin_url( 'admin.php?page=' . self::PAGE_CONNECTION ) ) . '">' . esc_html__( 'Connect', 'draftly' ) . '</a>' );
		}
		return $links;
	}

	/**
	 * Lets wp_safe_redirect send the admin to Draftly's approval page.
	 *
	 * @param array $hosts Hosts.
	 * @return array
	 */
	public static function allowed_redirect_hosts( $hosts ) {
		$hosts[] = 'app.draftly.blog';
		if ( defined( 'DRAFTLY_APP_HOST' ) ) {
			$hosts[] = DRAFTLY_APP_HOST;
		}
		return $hosts;
	}

	/**
	 * Scripts and styles, only on Draftly's own screens.
	 *
	 * @param string $hook Screen hook.
	 */
	public static function assets( $hook ) {
		if ( false === strpos( (string) $hook, self::PAGE_POSTS ) ) {
			return;
		}
		wp_enqueue_style( 'draftly-admin', plugins_url( 'assets/css/admin.css', DRAFTLY_FILE ), array(), DRAFTLY_VERSION );
		wp_enqueue_script( 'draftly-admin', plugins_url( 'assets/js/admin.js', DRAFTLY_FILE ), array(), DRAFTLY_VERSION, true );
		wp_localize_script(
			'draftly-admin',
			'draftlyAdmin',
			array(
				'ajaxUrl'       => admin_url( 'admin-ajax.php' ),
				'nonce'         => wp_create_nonce( self::NONCE_AJAX ),
				'connectionUrl' => current_user_can( 'manage_options' ) ? admin_url( 'admin.php?page=' . self::PAGE_CONNECTION ) : '',
				'topUpUrl'      => self::TOP_UP_URL,
				'plansUrl'      => self::PLANS_URL,
				'i18n'          => array(
					'checking'             => __( 'Checking...', 'draftly' ),
					'optimizing'           => __( 'Optimizing... this can take up to a minute.', 'draftly' ),
					'applying'             => __( 'Saving...', 'draftly' ),
					'reverting'            => __( 'Reverting...', 'draftly' ),
					'noChanges'            => __( 'Draftly found nothing to change in this post.', 'draftly' ),
					'approve'              => __( 'Approve selected', 'draftly' ),
					'discard'              => __( 'Discard', 'draftly' ),
					'before'               => __( 'Before', 'draftly' ),
					'after'                => __( 'After', 'draftly' ),
					'saved'                => __( 'Saved as a new revision.', 'draftly' ),
					'revert'               => __( 'Revert', 'draftly' ),
					/* translators: 1: optimized posts, 2: published posts */
					'progress'             => __( 'Optimized %1$s of %2$s posts', 'draftly' ),
					'supportCopied'        => __( 'Email address copied — paste it into your email app.', 'draftly' ),
					'supportManual'        => __( 'Copy this address into your email app:', 'draftly' ),
					'reverted'             => __( 'Reverted to the version before Draftly changed it.', 'draftly' ),
					'confirmRevert'        => __( 'Restore the version from before Draftly changed this post?', 'draftly' ),
					'confirmRevertChanged' => __( 'This post was edited after Draftly changed it. Reverting restores the version from before Draftly and also removes those later edits (they stay in the post\'s revision history). Revert anyway?', 'draftly' ),
					'diagnosticsCopied'    => __( 'Diagnostics copied. Paste them into your email to support.', 'draftly' ),
					'diagnosticsShown'     => __( 'Copy the text below and paste it into your email to support.', 'draftly' ),
					'error'                => __( 'Draftly did not answer as expected. Try again in a minute.', 'draftly' ),
					'checked'              => __( 'Checked.', 'draftly' ),
					/* translators: %s: number of credits */
					'creditsUsed'          => __( '%s credits used.', 'draftly' ),
					/* translators: %s: number of credits */
					'creditsLeft'          => __( '%s credits left.', 'draftly' ),
					/* translators: %s: what is left on the plan, e.g. "29 post scans" */
					'allowanceLeft'        => __( '%s left on your plan.', 'draftly' ),
					'noCharge'             => __( 'No credits used.', 'draftly' ),
					'notCharged'           => __( 'You were not charged.', 'draftly' ),
					/* translators: %s: reference code */
					'support'              => __( 'If this keeps happening, contact us from Draftly > Support and quote reference %s.', 'draftly' ),
					'topUp'                => __( 'Top up credits', 'draftly' ),
					'seePlans'             => __( 'See plans', 'draftly' ),
					'tryAgain'             => __( 'Try again', 'draftly' ),
					'openConnection'       => __( 'Open Draftly connection', 'draftly' ),
					'newTab'               => __( '(opens in a new tab)', 'draftly' ),
					'scoreLabels'          => array(
						'humanVoice'  => __( 'Human voice', 'draftly' ),
						'readability' => __( 'Readability', 'draftly' ),
					),
					/* translators: 1: posts used, 2: posts included on the free plan */
					'freePosts'            => __( 'Free: %1$s of %2$s posts used', 'draftly' ),
					'waiting'              => __( 'Waiting for you to approve in the Draftly tab...', 'draftly' ),
					'connected'            => __( 'Connected. Reloading...', 'draftly' ),
					'denied'               => __( 'The connection was cancelled in Draftly.', 'draftly' ),
					'expired'              => __( 'The connection request expired. Click Connect to Draftly again.', 'draftly' ),
					'autoRunStarted'       => __( 'Auto mode is working on the next few posts. Reload this page in a few minutes to see the result.', 'draftly' ),
					'starting'             => __( 'Starting...', 'draftly' ),
					'confirmRevertRun'     => __( 'Revert every post this run changed to the version from before Draftly changed it?', 'draftly' ),
					/* translators: %s: number of posts */
					'revertedRun'          => __( 'Reverted %s posts. Reloading...', 'draftly' ),
					/* translators: %s: number of posts */
					'revertRunSkipped'     => __( '%s posts were edited after the run and were left as they are.', 'draftly' ),
					'excludePost'          => __( 'Exclude from auto mode', 'draftly' ),
					'includePost'          => __( 'Include in auto mode', 'draftly' ),
					'excluded'             => __( 'Excluded', 'draftly' ),
					'holdingBack'          => __( 'What is holding this back', 'draftly' ),
					'statusLabels'         => array(
						'not_checked' => __( 'Not checked', 'draftly' ),
						'checked'     => __( 'Needs work', 'draftly' ),
						'needs_work'  => __( 'Needs work', 'draftly' ),
						'optimized'   => __( 'Optimized', 'draftly' ),
						'changed'     => __( 'Changed since optimized', 'draftly' ),
					),
				),
			)
		);
	}

	// ---- Connection screen ---------------------------------------------------------

	/**
	 * Admin-post handler for "Connect to Draftly": opens a connect request and redirects (in a new tab) to Draftly.
	 */
	public static function handle_connect() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to connect this site.', 'draftly' ), 403 );
		}
		check_admin_referer( 'draftly_connect' );
		// Only this redirect may go to Draftly's approval page (not every wp_safe_redirect on the site).
		add_filter( 'allowed_redirect_hosts', array( __CLASS__, 'allowed_redirect_hosts' ) );
		$url = Draftly_Connection::start();
		if ( is_wp_error( $url ) ) {
			wp_die( esc_html( $url->get_error_message() ), esc_html__( 'Draftly', 'draftly' ), array( 'back_link' => true ) );
		}
		wp_safe_redirect( $url );
		exit;
	}

	/**
	 * Admin-post handler for Disconnect.
	 */
	public static function handle_disconnect() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to disconnect this site.', 'draftly' ), 403 );
		}
		check_admin_referer( 'draftly_disconnect' );
		Draftly_Connection::disconnect();
		wp_safe_redirect( admin_url( 'admin.php?page=' . self::PAGE_CONNECTION . '&draftly_disconnected=1' ) );
		exit;
	}

	/**
	 * Admin-post handler on a copy of a connected site: forget the copied
	 * connection here only, so this site can be connected separately. The
	 * original site stays connected.
	 */
	public static function handle_forget_copy() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to change the Draftly connection.', 'draftly' ), 403 );
		}
		check_admin_referer( 'draftly_forget_copy' );
		Draftly_Activity::add( 'forget_copy', true, array( 'message' => 'Forgot the connection copied from ' . Draftly_Connection::copy_of() ) );
		Draftly_Connection::forget();
		wp_safe_redirect( admin_url( 'admin.php?page=' . self::PAGE_CONNECTION ) );
		exit;
	}

	/**
	 * The "copy of another site" notice, with the button to connect separately.
	 *
	 * @return bool Whether this site is a copy.
	 */
	private static function render_copy_notice() {
		$original = Draftly_Connection::copy_of();
		if ( '' === $original ) {
			return false;
		}
		echo '<div class="notice notice-warning draftly-copy-notice"><p><strong>' . esc_html( Draftly_Connection::copy_message( $original ) ) . '</strong></p>';
		echo '<p>' . esc_html__( 'This site has the Draftly connection of another site (for example a staging copy). Draftly will not read, change or bill anything through it here, and deleting the plugin here will not disconnect the original site.', 'draftly' ) . '</p>';
		if ( current_user_can( 'manage_options' ) ) {
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="draftly_forget_copy" />';
			wp_nonce_field( 'draftly_forget_copy' );
			submit_button( __( 'Connect this site separately', 'draftly' ), 'secondary', 'submit', false );
			echo '</form>';
		}
		echo '</div>';
		return true;
	}

	/**
	 * Draftly > Connection.
	 */
	public static function render_connection() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		// Coming back from Draftly's approval page: collect the secret now rather than waiting for the poll.
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only flag; the exchange itself is authenticated by the PKCE verifier.
		$returned = isset( $_GET['draftly_connect'] ) ? sanitize_key( wp_unslash( $_GET['draftly_connect'] ) ) : '';
		if ( 'approved' === $returned && Draftly_Connection::pending() ) {
			Draftly_Connection::exchange();
		}
		$conn    = Draftly_Connection::get();
		$pending = $conn ? null : Draftly_Connection::pending();
		$status  = null;
		$copy    = '' !== Draftly_Connection::copy_of();
		if ( $conn && ! $copy ) {
			$status = Draftly_Connection::refresh_status();
			$conn   = Draftly_Connection::get();
		}
		?>
		<div class="wrap draftly-wrap">
			<h1><?php esc_html_e( 'Draftly connection', 'draftly' ); ?></h1>
			<?php self::render_copy_notice(); ?>
			<?php
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- display-only flag.
			if ( isset( $_GET['draftly_disconnected'] ) ) {
				echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Disconnected. Draftly no longer has access to this site.', 'draftly' ) . '</p></div>';
			}
			if ( 'denied' === $returned ) {
				echo '<div class="notice notice-warning is-dismissible"><p>' . esc_html__( 'The connection was cancelled in Draftly.', 'draftly' ) . '</p></div>';
			}
			if ( $conn && is_wp_error( $status ) && 'revoked' !== $status->get_error_code() ) {
				echo '<div class="notice notice-error"><p>' . esc_html( $status->get_error_message() ) . '</p></div>';
			}
			?>

			<?php if ( $conn && ! $copy ) : ?>
				<?php self::render_connected( $conn, is_wp_error( $status ) ? null : $status ); ?>
			<?php elseif ( ! $conn ) : ?>
				<div class="draftly-card">
					<h2><?php esc_html_e( 'Connect this site to Draftly', 'draftly' ); ?></h2>
					<p><?php esc_html_e( 'Draftly checks your posts for readability and AI-sounding writing, suggests edits in your brand voice, and saves the ones you approve as WordPress revisions you can undo.', 'draftly' ); ?></p>
					<p><?php esc_html_e( 'Connecting opens Draftly in a new tab. Sign in or create a free account there and approve this site. No WordPress password or application password is shared.', 'draftly' ); ?></p>
					<p class="description">
						<?php esc_html_e( 'When you click Connect, this site sends Draftly its address, its REST API address, the address of this page and the plugin and WordPress versions. Nothing is sent before you click.', 'draftly' ); ?>
						<a href="https://www.draftly.blog/privacy-policy" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Privacy policy', 'draftly' ); ?></a>
					</p>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" target="_blank" id="draftly-connect-form">
						<input type="hidden" name="action" value="draftly_connect" />
						<?php wp_nonce_field( 'draftly_connect' ); ?>
						<?php submit_button( __( 'Connect to Draftly', 'draftly' ), 'primary', 'submit', false ); ?>
					</form>
					<div id="draftly-connect-status" class="draftly-status" aria-live="polite" <?php echo $pending ? 'data-pending="1"' : ''; ?>>
						<?php
						if ( $pending ) {
							esc_html_e( 'Waiting for you to approve in the Draftly tab...', 'draftly' );
						}
						?>
					</div>
					<p><a href="<?php echo esc_url( self::PLANS_URL ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'What Draftly includes, and plans', 'draftly' ); ?></a></p>
				</div>
			<?php endif; ?>
			<?php self::render_activity(); ?>
		</div>
		<?php
	}

	/**
	 * Why Draftly couldn't verify the site, from Draftly's last attempt (H5).
	 *
	 * @param mixed $error verify_error from connection_status.
	 */
	private static function render_verify_error( $error ) {
		if ( ! is_array( $error ) || empty( $error['message'] ) ) {
			return;
		}
		echo '<div class="notice notice-error inline draftly-verify-error"><p><strong>' . esc_html__( 'Why Draftly could not verify this site:', 'draftly' ) . '</strong> ' . esc_html( sanitize_text_field( (string) $error['message'] ) ) . '</p>';
		if ( ! empty( $error['hint'] ) ) {
			echo '<p>' . esc_html__( 'How to fix it:', 'draftly' ) . ' ' . esc_html( sanitize_text_field( (string) $error['hint'] ) ) . '</p>';
		}
		echo '</div>';
	}

	/**
	 * Recent activity (last 50 Draftly actions on this site) and Copy diagnostics (H12).
	 */
	private static function render_activity() {
		$log = Draftly_Activity::all();
		?>
		<div class="draftly-card draftly-activity">
			<h2><?php esc_html_e( 'Recent activity', 'draftly' ); ?></h2>
			<p class="description"><?php esc_html_e( 'The last 50 things Draftly did on this site, kept on this site only. Quote the reference when you contact support.', 'draftly' ); ?></p>
			<?php if ( ! $log ) : ?>
				<p class="draftly-muted"><?php esc_html_e( 'Nothing yet.', 'draftly' ); ?></p>
			<?php else : ?>
				<table class="widefat striped">
					<thead><tr>
						<th scope="col"><?php esc_html_e( 'When', 'draftly' ); ?></th>
						<th scope="col"><?php esc_html_e( 'What', 'draftly' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Post', 'draftly' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Result', 'draftly' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Reference', 'draftly' ); ?></th>
					</tr></thead>
					<tbody>
					<?php foreach ( $log as $entry ) : ?>
						<tr>
							<td><?php echo esc_html( wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), (int) $entry['t'] ) ); ?></td>
							<td><?php echo esc_html( ( 'draftly' === $entry['source'] ? __( 'Draftly:', 'draftly' ) . ' ' : '' ) . $entry['action'] ); ?></td>
							<td>
							<?php
							if ( ! empty( $entry['post_id'] ) && get_post( (int) $entry['post_id'] ) ) {
								echo '<a href="' . esc_url( (string) get_edit_post_link( (int) $entry['post_id'] ) ) . '">' . esc_html( get_the_title( (int) $entry['post_id'] ) ) . '</a>';
							} elseif ( ! empty( $entry['post_id'] ) ) {
								echo esc_html( '#' . (int) $entry['post_id'] );
							}
							?>
							</td>
							<td><?php echo esc_html( $entry['ok'] ? __( 'OK', 'draftly' ) : trim( $entry['code'] . ' ' . $entry['message'] ) ); ?></td>
							<td><code><?php echo esc_html( $entry['request_id'] ); ?></code></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			<?php endif; ?>
			<?php if ( current_user_can( 'manage_options' ) ) : ?>
				<p>
					<button type="button" class="button" id="draftly-diagnostics"><?php esc_html_e( 'Copy diagnostics', 'draftly' ); ?></button>
					<span id="draftly-diagnostics-status" class="draftly-status" aria-live="polite"></span>
				</p>
				<p class="description"><?php esc_html_e( 'Plugin, WordPress and PHP versions, whether Draftly can reach this site, the connection status and the last errors. No passwords or keys.', 'draftly' ); ?></p>
				<textarea id="draftly-diagnostics-text" class="large-text code" rows="10" readonly hidden></textarea>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * The connected state.
	 *
	 * @param array      $conn   Connection.
	 * @param array|null $status Status from Draftly.
	 */
	private static function render_connected( array $conn, $status ) {
		$active    = 'active' === ( $conn['status'] ?? '' );
		$account   = is_array( $status['account'] ?? null ) ? $status['account'] : array();
		$seo       = Draftly_Seo_Meta::provider();
		$seo_names = array(
			'yoast'    => 'Yoast SEO',
			'rankmath' => 'Rank Math',
			'aioseo'   => 'All in One SEO',
			'none'     => __( 'none (the post excerpt is used as the description)', 'draftly' ),
		);
		?>
		<div class="draftly-card">
			<h2>
				<?php
				if ( $active ) {
					esc_html_e( 'Connected to Draftly', 'draftly' );
				} else {
					esc_html_e( 'Connected, waiting for Draftly to verify this site', 'draftly' );
				}
				?>
			</h2>
			<?php if ( ! $active ) : ?>
				<p><?php esc_html_e( 'Draftly needs to reach this site once to confirm the connection. This usually takes a few seconds.', 'draftly' ); ?></p>
				<?php self::render_verify_error( $status['verify_error'] ?? null ); ?>
				<p><button type="button" class="button" id="draftly-verify"><?php esc_html_e( 'Retry verification', 'draftly' ); ?></button> <span id="draftly-verify-status" class="draftly-status" aria-live="polite"></span></p>
			<?php endif; ?>
			<table class="form-table" role="presentation">
				<tr><th scope="row"><?php esc_html_e( 'Draftly account', 'draftly' ); ?></th><td><?php echo esc_html( $account['email'] ?? ( $conn['account_email'] ?? '' ) ); ?></td></tr>
				<?php if ( ! empty( $status['website_name'] ) ) : ?>
					<tr><th scope="row"><?php esc_html_e( 'Draftly website', 'draftly' ); ?></th><td><?php echo esc_html( $status['website_name'] ); ?></td></tr>
				<?php endif; ?>
				<?php if ( isset( $account['plan'] ) ) : ?>
					<tr><th scope="row"><?php esc_html_e( 'Plan', 'draftly' ); ?></th><td><?php echo esc_html( ucfirst( (string) $account['plan'] ) ); ?></td></tr>
				<?php endif; ?>
				<?php if ( isset( $account['credits'] ) && null !== $account['credits'] ) : ?>
					<tr><th scope="row"><?php esc_html_e( 'Credits left', 'draftly' ); ?></th><td><?php echo esc_html( number_format_i18n( (int) $account['credits'] ) ); ?></td></tr>
				<?php endif; ?>
				<tr><th scope="row"><?php esc_html_e( 'SEO titles and descriptions', 'draftly' ); ?></th><td><?php echo esc_html( $seo_names[ $seo ] ); ?></td></tr>
			</table>
			<p>
				<a class="button button-primary" href="<?php echo esc_url( admin_url( 'admin.php?page=' . self::PAGE_POSTS ) ); ?>"><?php esc_html_e( 'Optimize posts', 'draftly' ); ?></a>
				<a class="button" href="https://app.draftly.blog" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Open Draftly', 'draftly' ); ?></a>
				<a href="<?php echo esc_url( self::PLANS_URL ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Plans', 'draftly' ); ?></a>
			</p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="draftly-confirm" data-confirm="<?php echo esc_attr__( 'Disconnect this site from Draftly? Draftly will no longer be able to read or update your posts.', 'draftly' ); ?>">
				<input type="hidden" name="action" value="draftly_disconnect" />
				<?php wp_nonce_field( 'draftly_disconnect' ); ?>
				<?php submit_button( __( 'Disconnect', 'draftly' ), 'delete', 'submit', false ); ?>
			</form>
		</div>
		<?php
	}

	// ---- Posts screen ---------------------------------------------------------------

	/**
	 * Draftly > Optimize posts.
	 */
	public static function render_posts() {
		if ( ! current_user_can( 'edit_posts' ) ) {
			return;
		}
		$conn = Draftly_Connection::get();
		self::maybe_refresh_status();
		?>
		<div class="wrap draftly-wrap">
			<h1><?php esc_html_e( 'Optimize posts with Draftly', 'draftly' ); ?></h1>
			<?php if ( self::render_copy_notice() ) : ?>
				<?php $conn = null; ?>
			<?php elseif ( ! $conn ) : ?>
				<div class="notice notice-info">
					<p>
						<?php
						if ( current_user_can( 'manage_options' ) ) {
							printf(
								/* translators: %s: link to the Connection screen */
								esc_html__( 'Connect this site to Draftly first: %s.', 'draftly' ),
								'<a href="' . esc_url( admin_url( 'admin.php?page=' . self::PAGE_CONNECTION ) ) . '">' . esc_html__( 'Draftly > Connection', 'draftly' ) . '</a>'
							);
						} else {
							esc_html_e( 'Ask a site administrator to connect this site to Draftly.', 'draftly' );
						}
						?>
					</p>
				</div>
			<?php elseif ( ! Draftly_Connection::is_active() ) : ?>
				<div class="notice notice-warning"><p>
					<?php
					printf(
						/* translators: %s: link to the Connection screen */
						esc_html__( 'Draftly has not verified this site yet. See %s.', 'draftly' ),
						'<a href="' . esc_url( admin_url( 'admin.php?page=' . self::PAGE_CONNECTION ) ) . '">' . esc_html__( 'Draftly > Connection', 'draftly' ) . '</a>'
					);
					?>
				</p></div>
			<?php endif; ?>
			<p class="description"><?php esc_html_e( 'Check scores each post for Human voice and Readability. Optimize suggests edits you can review one by one; approved edits are saved as a new revision, and Revert restores the version from before Draftly changed it. A post with its edits applied, or with nothing to fix, is marked Optimized.', 'draftly' ); ?></p>
			<?php self::render_progress(); ?>
			<?php self::render_auto_mode_line(); ?>
			<?php self::render_run_banner(); ?>
			<?php
			$free_posts = Draftly_Connection::free_posts();
			?>
			<p id="draftly-free-posts" class="draftly-free-posts draftly-muted"<?php echo $free_posts ? '' : ' hidden'; ?>>
				<?php
				if ( $free_posts ) {
					printf(
						/* translators: 1: posts used, 2: posts included on the free plan */
						esc_html__( 'Free: %1$s of %2$s posts used', 'draftly' ),
						esc_html( number_format_i18n( min( (int) $free_posts['used'], (int) $free_posts['limit'] ) ) ),
						esc_html( number_format_i18n( (int) $free_posts['limit'] ) )
					);
				}
				?>
			</p>
			<div id="draftly-notice" class="draftly-status" aria-live="polite"></div>
			<form method="get">
				<input type="hidden" name="page" value="<?php echo esc_attr( self::PAGE_POSTS ); ?>" />
				<?php
				// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only list filter.
				$draftly_tab = isset( $_GET['draftly_tab'] ) ? sanitize_key( wp_unslash( $_GET['draftly_tab'] ) ) : '';
				if ( '' !== $draftly_tab ) {
					echo '<input type="hidden" name="draftly_tab" value="' . esc_attr( $draftly_tab ) . '" />';
				}
				?>
				<?php
				$table = new Draftly_Posts_Table( (bool) $conn && Draftly_Connection::is_active() );
				$table->prepare_items();
				$table->views();
				$table->search_box( __( 'Search posts', 'draftly' ), 'draftly-search' );
				$table->display();
				?>
			</form>
			<div id="draftly-review" class="draftly-review" hidden></div>
		</div>
		<?php
	}

	/**
	 * Refreshes Draftly's account state (plan, auto mode, post statuses) when
	 * the posts screen opens, at most every STATUS_MAX_AGE seconds, so a plan
	 * change shows without visiting another screen, and posts Draftly knows
	 * as optimized but this site doesn't are filled in before the counter is
	 * drawn.
	 */
	private static function maybe_refresh_status() {
		if ( ! Draftly_Connection::get() || ! Draftly_Connection::is_active() || '' !== Draftly_Connection::copy_of() ) {
			return;
		}
		$last = (int) get_option( Draftly_Connection::STATUS_CHECKED_OPTION, 0 );
		if ( $last > time() - self::STATUS_MAX_AGE && is_array( Draftly_Connection::auto_mode() ) ) {
			return;
		}
		Draftly_Connection::refresh_status( 8 );
	}

	/**
	 * Optimized and published counts, for the counter and the browser.
	 *
	 * @return array { optimized: int, total: int }
	 */
	public static function progress() {
		return Draftly_Posts::progress();
	}

	/**
	 * "Optimized N of M posts" above the list. Counted by Draftly_Posts::progress()
	 * with the badges' own rule, and redrawn by admin.js after every action.
	 */
	private static function render_progress() {
		$progress = self::progress();
		echo '<p id="draftly-progress" class="draftly-progress"' . ( $progress['total'] ? '' : ' hidden' ) . ' data-optimized="' . esc_attr( (string) $progress['optimized'] ) . '" data-total="' . esc_attr( (string) $progress['total'] ) . '"><strong>';
		printf(
			/* translators: 1: optimized posts, 2: published posts */
			esc_html__( 'Optimized %1$s of %2$s posts', 'draftly' ),
			esc_html( number_format_i18n( $progress['optimized'] ) ),
			esc_html( number_format_i18n( $progress['total'] ) )
		);
		echo '</strong></p>';
	}

	/**
	 * One line about auto mode, linking to Draftly > Settings.
	 */
	private static function render_auto_mode_line() {
		if ( ! Draftly_Connection::is_active() ) {
			return;
		}
		$state = Draftly_Auto_Mode::state();
		$link  = current_user_can( 'manage_options' ) ? admin_url( 'admin.php?page=' . Draftly_Auto_Mode::PAGE ) : '';
		echo '<p class="draftly-auto-line draftly-muted">';
		if ( empty( $state['eligible'] ) ) {
			$why = Draftly_Auto_Mode::ineligible( $state );
			echo esc_html( $why['text'] );
			if ( $why['plans'] ) {
				echo ' <a href="' . esc_url( self::PLANS_URL ) . '" target="_blank" rel="noopener noreferrer">' . esc_html__( 'See plans', 'draftly' ) . '<span class="screen-reader-text"> ' . esc_html__( '(opens in a new tab)', 'draftly' ) . '</span></a>';
			}
		} else {
			if ( ! empty( $state['enabled'] ) ) {
				echo esc_html( 'full' === $state['level'] ? __( 'Auto mode: Full (on).', 'draftly' ) : __( 'Auto mode: Safe (on).', 'draftly' ) );
			} else {
				esc_html_e( 'Auto mode is off. You review every edit.', 'draftly' );
			}
			if ( is_array( $state['last_run'] ?? null ) ) {
				echo ' ' . esc_html__( 'Last run:', 'draftly' ) . ' ' . esc_html( Draftly_Auto_Mode::run_summary( $state['last_run'] ) );
			}
			if ( $link ) {
				echo ' <a href="' . esc_url( $link ) . '">' . esc_html__( 'Auto mode settings', 'draftly' ) . '</a>';
			}
		}
		echo '</p>';
	}

	/**
	 * Arriving from the weekly email or Settings with ?draftly_run=: the run's posts and Revert this run.
	 */
	private static function render_run_banner() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only filter; reverting needs the AJAX nonce.
		$run_id = isset( $_GET['draftly_run'] ) ? preg_replace( '/[^A-Za-z0-9-]/', '', sanitize_text_field( wp_unslash( $_GET['draftly_run'] ) ) ) : '';
		if ( '' === $run_id ) {
			return;
		}
		$count = count( Draftly_Posts::posts_in_run( $run_id ) );
		echo '<div class="notice notice-info draftly-run-banner"><p>';
		if ( $count ) {
			printf(
				/* translators: %s: number of posts */
				esc_html( _n( 'Showing the %s post this auto mode run changed.', 'Showing the %s posts this auto mode run changed.', $count, 'draftly' ) ),
				esc_html( number_format_i18n( $count ) )
			);
			echo ' <button type="button" class="button draftly-revert-run" data-run="' . esc_attr( $run_id ) . '">' . esc_html__( 'Revert this run', 'draftly' ) . '</button>';
		} else {
			esc_html_e( 'No posts still carry changes from this auto mode run (they were reverted or changed again since).', 'draftly' );
		}
		echo '</p></div>';
	}

	/**
	 * Draftly > Support. The address is never printed and there is no mailto
	 * link: the button copies it to the clipboard (admin.js). If the browser
	 * can't copy, admin.js shows it in a read-only field to copy by hand.
	 */
	public static function render_support() {
		if ( ! current_user_can( 'edit_posts' ) ) {
			return;
		}
		?>
		<div class="wrap draftly-wrap">
			<h1><?php esc_html_e( 'Draftly support', 'draftly' ); ?></h1>
			<div class="draftly-card draftly-support">
				<h2><?php esc_html_e( 'Questions, bugs or ideas?', 'draftly' ); ?></h2>
				<p><?php esc_html_e( 'We read every message and reply personally. Feature requests are welcome.', 'draftly' ); ?></p>
				<p>
					<button type="button" class="button button-primary" id="draftly-support-copy" data-copy="<?php echo esc_attr( self::SUPPORT_EMAIL ); ?>"><?php esc_html_e( 'Email support', 'draftly' ); ?></button>
					<span id="draftly-support-status" class="draftly-status" aria-live="polite"></span>
				</p>
				<p id="draftly-support-manual" hidden>
					<label for="draftly-support-field" class="screen-reader-text"><?php esc_html_e( 'Support email address', 'draftly' ); ?></label>
					<input type="text" id="draftly-support-field" class="regular-text" readonly value="" />
				</p>
				<p class="description"><?php esc_html_e( 'Include your Copy diagnostics output from Draftly > Connection so we can help faster.', 'draftly' ); ?></p>
			</div>
		</div>
		<?php
	}

	// ---- AJAX ---------------------------------------------------------------------

	/**
	 * Checks the AJAX nonce and that the user may edit the post. Returns the post.
	 *
	 * @return WP_Post
	 */
	private static function ajax_post() {
		check_ajax_referer( self::NONCE_AJAX, 'nonce' );
		$post_id = isset( $_POST['post_id'] ) ? absint( wp_unslash( $_POST['post_id'] ) ) : 0;
		$post    = $post_id ? get_post( $post_id ) : null;
		if ( ! $post || ! in_array( $post->post_type, Draftly_Posts::POST_TYPES, true ) || ! current_user_can( 'edit_post', $post_id ) ) {
			wp_send_json_error( array( 'message' => __( 'You cannot edit this post.', 'draftly' ) ), 403 );
		}
		if ( ! Draftly_Connection::is_active() ) {
			wp_send_json_error( array( 'message' => __( 'Connect this site to Draftly first.', 'draftly' ) ), 400 );
		}
		$original = Draftly_Connection::copy_of();
		if ( '' !== $original ) {
			wp_send_json_error(
				array(
					'message' => Draftly_Connection::copy_message( $original ),
					'code'    => 'site_copy',
				),
				409
			);
		}
		return $post;
	}

	/**
	 * Sends a Draftly error to the browser.
	 *
	 * @param WP_Error $error Error.
	 */
	private static function send_error( WP_Error $error ) {
		$data   = $error->get_error_data();
		$data   = is_array( $data ) ? $data : array();
		$status = isset( $data['http_status'] ) ? (int) $data['http_status'] : 502;
		$out    = array(
			'message' => $error->get_error_message(),
			'code'    => sanitize_key( (string) $error->get_error_code() ),
		);
		// Only these fields from Draftly reach the browser, each cleaned for its type.
		if ( isset( $data['request_id'] ) && is_string( $data['request_id'] ) ) {
			$out['request_id'] = substr( preg_replace( '/[^A-Za-z0-9_-]/', '', $data['request_id'] ), 0, 40 );
		}
		foreach ( array( 'credits_needed', 'credits_available', 'words', 'max_words', 'charged' ) as $key ) {
			if ( isset( $data[ $key ] ) && is_numeric( $data[ $key ] ) ) {
				$out[ $key ] = absint( $data[ $key ] );
			}
		}
		if ( isset( $data['retryable'] ) ) {
			$out['retryable'] = (bool) $data['retryable'];
		}
		Draftly_Connection::remember_free_posts( $data );
		$out = array_merge( $out, self::free_posts_fields( $data ) );
		if ( in_array( $out['code'], array( 'insufficient_credits', 'allowance_exhausted', 'free_limit_reached' ), true ) ) {
			$out['top_up_url']  = self::draftly_link( $data['top_up_url'] ?? '', self::TOP_UP_URL );
			$out['upgrade_url'] = self::draftly_link( $data['upgrade_url'] ?? '', self::PLANS_URL );
		}
		wp_send_json_error( $out, $status >= 400 && $status < 600 ? $status : 502 );
	}

	/**
	 * A link from Draftly's response, used only if it is https on a Draftly host.
	 *
	 * @param mixed  $url      URL from the response.
	 * @param string $fallback Default link.
	 * @return string
	 */
	private static function draftly_link( $url, $fallback ) {
		if ( ! is_string( $url ) || '' === $url ) {
			return $fallback;
		}
		$clean = esc_url_raw( $url, array( 'https' ) );
		$host  = wp_parse_url( $clean, PHP_URL_HOST );
		return ( $clean && in_array( $host, self::LINK_HOSTS, true ) ) ? $clean : $fallback;
	}

	/**
	 * What is left after a run, for the success notice.
	 *
	 * @param array $result Draftly's response.
	 * @return array
	 */
	private static function usage( array $result ) {
		$out = array(
			'charged'           => (int) ( $result['charged'] ?? 0 ),
			'credits_remaining' => isset( $result['credits_remaining'] ) && is_numeric( $result['credits_remaining'] ) ? absint( $result['credits_remaining'] ) : null,
			'allowance_left'    => '',
		);
		if ( is_array( $result['allowance'] ?? null ) && isset( $result['allowance']['label'] ) && is_string( $result['allowance']['label'] ) ) {
			$out['allowance_left'] = sanitize_text_field( $result['allowance']['label'] );
		}
		Draftly_Connection::remember_free_posts( $result );
		return array_merge( $out, self::free_posts_fields( $result ) );
	}

	/**
	 * The free-posts counter for the browser (nulls when the account has none).
	 *
	 * @param array $data Draftly's response or error data.
	 * @return array
	 */
	private static function free_posts_fields( array $data ) {
		$has = isset( $data['free_posts_used'], $data['free_posts_limit'] ) && is_numeric( $data['free_posts_used'] ) && is_numeric( $data['free_posts_limit'] );
		return array(
			'free_posts_used'  => $has ? absint( $data['free_posts_used'] ) : null,
			'free_posts_limit' => $has ? absint( $data['free_posts_limit'] ) : null,
		);
	}

	/**
	 * The post as Draftly needs it.
	 *
	 * @param WP_Post $post Post.
	 * @return array
	 */
	private static function post_payload( WP_Post $post ) {
		return array(
			'id'      => $post->ID,
			'title'   => get_the_title( $post ),
			'url'     => get_permalink( $post ),
			'content' => $post->post_content,
		);
	}

	/**
	 * AJAX: score a post.
	 */
	public static function ajax_check() {
		$post   = self::ajax_post();
		$result = Draftly_Connection::signed( 'check', array( 'post' => self::post_payload( $post ) ), 120 );
		if ( is_wp_error( $result ) ) {
			self::send_error( $result );
		}
		Draftly_Posts::save_scores( $post->ID, $result['scores'] ?? null, $result['breakdown'] ?? null );
		Draftly_Posts::set_status( $post->ID, ! empty( $result['nothing_to_fix'] ) ? 'optimized' : 'checked', array( 'nothing_to_fix' => true ) );
		wp_send_json_success(
			array_merge(
				array(
					'scores'   => Draftly_Posts::scores( $post->ID ),
					'status'   => Draftly_Posts::status( $post->ID ),
					'progress' => self::progress(),
					'issues'   => $result['document_issues'] ?? array(),
					'flags'    => (int) ( $result['flags'] ?? 0 ),
				),
				self::usage( $result )
			)
		);
	}

	/**
	 * AJAX: get suggested edits for a post (nothing is saved yet).
	 */
	public static function ajax_optimize() {
		$post   = self::ajax_post();
		$result = Draftly_Connection::signed( 'optimize', array( 'post' => self::post_payload( $post ) ), 180 );
		if ( is_wp_error( $result ) ) {
			self::send_error( $result );
		}
		Draftly_Posts::save_scores( $post->ID, $result['scores'] ?? null, $result['breakdown'] ?? null );
		Draftly_Posts::set_status( $post->ID, ! empty( $result['nothing_to_fix'] ) ? 'optimized' : 'checked', array( 'nothing_to_fix' => true ) );
		if ( ! empty( $result['document_id'] ) && is_array( $result['scores_after'] ?? null ) ) {
			// Shown as the post's score once the edits are approved.
			set_transient(
				'draftly_after_' . md5( $result['document_id'] ),
				array(
					'scores'    => $result['scores_after'],
					'breakdown' => $result['breakdown_after'] ?? null,
				),
				DAY_IN_SECONDS
			);
		}
		$changes = array();
		foreach ( (array) ( $result['changes'] ?? array() ) as $change ) {
			$changes[] = array(
				'id'     => sanitize_key( $change['id'] ?? '' ),
				'before' => sanitize_textarea_field( $change['before'] ?? '' ),
				'after'  => sanitize_textarea_field( $change['after'] ?? '' ),
				'rule'   => sanitize_text_field( $change['rule'] ?? '' ),
				'reason' => sanitize_text_field( $change['reason'] ?? '' ),
			);
		}
		wp_send_json_success(
			array_merge(
				array(
					'document_id'  => sanitize_text_field( $result['document_id'] ?? '' ),
					'post_title'   => get_the_title( $post ),
					'scores'       => $result['scores'] ?? null,
					'scores_after' => $result['scores_after'] ?? null,
					'changes'      => $changes,
					'status'       => Draftly_Posts::status( $post->ID ),
					'progress'     => self::progress(),
				),
				self::usage( $result )
			)
		);
	}

	/**
	 * AJAX: apply the approved edits as a new revision.
	 */
	public static function ajax_apply() {
		check_ajax_referer( self::NONCE_AJAX, 'nonce' );
		$post        = self::ajax_post();
		$document_id = isset( $_POST['document_id'] ) ? sanitize_text_field( wp_unslash( $_POST['document_id'] ) ) : '';
		$accepted    = isset( $_POST['accepted'] ) ? array_map( 'sanitize_key', (array) wp_unslash( $_POST['accepted'] ) ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- each item is sanitized by sanitize_key.
		if ( '' === $document_id || ! $accepted ) {
			wp_send_json_error( array( 'message' => __( 'Pick at least one change to approve.', 'draftly' ) ), 400 );
		}
		// What Draftly is given to patch; the save is refused if the post changes meanwhile (H2).
		$read_modified = $post->post_modified_gmt;
		$read_hash     = Draftly_Posts::content_hash( $post );
		// Draftly places the stored suggestions into the current body; only Draftly's own suggestions can be applied.
		$result = Draftly_Connection::signed(
			'apply',
			array(
				'document_id'         => $document_id,
				'post_id'             => $post->ID,
				'accepted_change_ids' => array_values( $accepted ),
				'content'             => $post->post_content,
			),
			60
		);
		if ( is_wp_error( $result ) ) {
			self::send_error( $result );
		}
		if ( ! isset( $result['content'] ) || ! is_string( $result['content'] ) ) {
			wp_send_json_error( array( 'message' => __( 'Draftly did not return the updated post.', 'draftly' ) ), 502 );
		}
		$saved = Draftly_Posts::update(
			$post,
			array(
				'content'               => $result['content'],
				'expected_modified_gmt' => $read_modified,
				'expected_hash'         => $read_hash,
				'draftly'               => array(
					'state'  => 'optimized',
					'source' => 'manual',
				),
			)
		);
		Draftly_Activity::add(
			'save',
			! is_wp_error( $saved ),
			array(
				'post_id' => $post->ID,
				'code'    => is_wp_error( $saved ) ? $saved->get_error_code() : '',
				'message' => is_wp_error( $saved ) ? $saved->get_error_message() : '',
			)
		);
		if ( is_wp_error( $saved ) ) {
			self::send_local_error( $saved );
		}
		$after = get_transient( 'draftly_after_' . md5( $document_id ) );
		if ( is_array( $after ) && isset( $after['scores'] ) ) {
			Draftly_Posts::save_scores( $post->ID, $after['scores'], $after['breakdown'] ?? null );
		}
		wp_send_json_success(
			array(
				'applied'    => count( (array) ( $result['applied'] ?? array() ) ),
				'skipped'    => count( (array) ( $result['skipped'] ?? array() ) ),
				'scores'     => Draftly_Posts::scores( $post->ID ),
				'status'     => Draftly_Posts::status( $post->ID ),
				'can_revert' => Draftly_Posts::can_revert( $post->ID ),
				'progress'   => self::progress(),
			)
		);
	}

	/**
	 * AJAX: undo Draftly's last change to a post. The revert happens here on the
	 * site; Draftly is then told the post needs work again.
	 */
	public static function ajax_revert() {
		check_ajax_referer( self::NONCE_AJAX, 'nonce' );
		$post_id = isset( $_POST['post_id'] ) ? absint( wp_unslash( $_POST['post_id'] ) ) : 0;
		$post    = $post_id ? get_post( $post_id ) : null;
		if ( ! $post || ! current_user_can( 'edit_post', $post_id ) ) {
			wp_send_json_error( array( 'message' => __( 'You cannot edit this post.', 'draftly' ) ), 403 );
		}
		$force    = ! empty( $_POST['force'] );
		$restored = Draftly_Posts::revert( $post, $force );
		Draftly_Activity::add(
			'revert',
			! is_wp_error( $restored ),
			array(
				'post_id' => $post->ID,
				'code'    => is_wp_error( $restored ) ? $restored->get_error_code() : '',
				'message' => is_wp_error( $restored ) ? $restored->get_error_message() : '',
			)
		);
		if ( is_wp_error( $restored ) ) {
			self::send_local_error( $restored );
		}
		if ( Draftly_Connection::is_active() ) {
			// Tell Draftly the post needs work again (its status record and the weekly email).
			Draftly_Connection::signed( 'post_status', array( 'reverted_post_ids' => array( $post->ID ) ), 10 );
		}
		wp_send_json_success(
			array(
				'reverted' => true,
				'status'   => Draftly_Posts::status( $post->ID ),
				'progress' => self::progress(),
			)
		);
	}

	/**
	 * AJAX: the Connection screen polls this while the admin approves in the Draftly tab.
	 */
	public static function ajax_poll() {
		check_ajax_referer( self::NONCE_AJAX, 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Not allowed.', 'draftly' ) ), 403 );
		}
		$status = Draftly_Connection::exchange();
		if ( 'approved' === $status && Draftly_Connection::get() && ! Draftly_Connection::is_active() ) {
			Draftly_Connection::refresh_status();
		}
		wp_send_json_success(
			array(
				'status' => $status,
				'active' => Draftly_Connection::is_active(),
			)
		);
	}

	/**
	 * AJAX: retry site verification.
	 */
	public static function ajax_verify() {
		check_ajax_referer( self::NONCE_AJAX, 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Not allowed.', 'draftly' ) ), 403 );
		}
		$error = null;
		if ( ! Draftly_Connection::is_active() ) {
			Draftly_Connection::request_verification();
			$status = Draftly_Connection::refresh_status();
			if ( is_wp_error( $status ) ) {
				$error = array( 'message' => $status->get_error_message() );
			} elseif ( is_array( $status['verify_error'] ?? null ) ) {
				$error = array(
					'message' => sanitize_text_field( (string) ( $status['verify_error']['message'] ?? '' ) ),
					'hint'    => sanitize_text_field( (string) ( $status['verify_error']['hint'] ?? '' ) ),
				);
			}
		}
		wp_send_json_success(
			array(
				'active' => Draftly_Connection::is_active(),
				'error'  => $error,
			)
		);
	}

	/**
	 * AJAX: the diagnostics text for "Copy diagnostics" (manage_options). Runs the REST self-check.
	 */
	public static function ajax_diagnostics() {
		check_ajax_referer( self::NONCE_AJAX, 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Not allowed.', 'draftly' ) ), 403 );
		}
		wp_send_json_success( array( 'text' => Draftly_Activity::diagnostics() ) );
	}

	/**
	 * Sends an error from this site (a refused save or revert) to the browser.
	 *
	 * @param WP_Error $error Error.
	 */
	private static function send_local_error( WP_Error $error ) {
		$data   = $error->get_error_data();
		$status = is_array( $data ) && isset( $data['status'] ) ? (int) $data['status'] : 409;
		wp_send_json_error(
			array(
				'message' => $error->get_error_message(),
				'code'    => sanitize_key( (string) $error->get_error_code() ),
			),
			$status >= 400 && $status < 600 ? $status : 409
		);
	}
}

<?php
/**
 * A small local log of Draftly actions on this site (the last 50), and the
 * "Copy diagnostics" text for support. Both stay on the site: nothing here is
 * sent anywhere, and no secret is ever written to the log or the diagnostics.
 *
 * @package Draftly
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Activity log and diagnostics.
 */
class Draftly_Activity {

	/** Option holding the log (never autoloaded). */
	const OPTION = 'draftly_activity';

	/** Entries kept. */
	const MAX = 50;

	/**
	 * Adds an entry.
	 *
	 * @param string $action  What happened (check, optimize, apply, revert, update, verify...).
	 * @param bool   $ok      Whether it worked.
	 * @param array  $details { post_id, source (wp-admin|draftly), code, message, request_id }.
	 */
	public static function add( $action, $ok, array $details = array() ) {
		$entry = array(
			't'          => time(),
			'action'     => sanitize_key( (string) $action ),
			'ok'         => (bool) $ok,
			'post_id'    => isset( $details['post_id'] ) ? absint( $details['post_id'] ) : 0,
			'source'     => isset( $details['source'] ) && 'draftly' === $details['source'] ? 'draftly' : 'wp-admin',
			'user_id'    => get_current_user_id(),
			'code'       => isset( $details['code'] ) ? substr( sanitize_key( (string) $details['code'] ), 0, 60 ) : '',
			'message'    => isset( $details['message'] ) ? substr( sanitize_text_field( (string) $details['message'] ), 0, 300 ) : '',
			'request_id' => isset( $details['request_id'] ) ? substr( (string) preg_replace( '/[^A-Za-z0-9_-]/', '', (string) $details['request_id'] ), 0, 40 ) : '',
		);
		$log   = self::all();
		array_unshift( $log, $entry );
		update_option( self::OPTION, array_slice( $log, 0, self::MAX ), false );
	}

	/**
	 * Logs the outcome of a signed call to Draftly.
	 *
	 * @param string         $action  Draftly action.
	 * @param array|WP_Error $result  Draftly's answer.
	 * @param array          $payload What was sent (only the post id is read).
	 */
	public static function log_result( $action, $result, array $payload ) {
		$post_id = 0;
		if ( isset( $payload['post']['id'] ) ) {
			$post_id = (int) $payload['post']['id'];
		} elseif ( isset( $payload['post_id'] ) ) {
			$post_id = (int) $payload['post_id'];
		}
		if ( is_wp_error( $result ) ) {
			$data = $result->get_error_data();
			self::add(
				$action,
				false,
				array(
					'post_id'    => $post_id,
					'code'       => (string) $result->get_error_code(),
					'message'    => $result->get_error_message(),
					'request_id' => is_array( $data ) && isset( $data['request_id'] ) && is_string( $data['request_id'] ) ? $data['request_id'] : '',
				)
			);
			return;
		}
		self::add(
			$action,
			true,
			array(
				'post_id'    => $post_id,
				'request_id' => is_array( $result ) && isset( $result['request_id'] ) && is_string( $result['request_id'] ) ? $result['request_id'] : '',
			)
		);
	}

	/**
	 * Logs a request Draftly made to this site's REST routes.
	 *
	 * @param string                 $action  Route action (update, create, revert, disconnect).
	 * @param int                    $post_id Post id.
	 * @param WP_Error|WP_Post|mixed $result  Result.
	 */
	public static function log_incoming( $action, $post_id, $result ) {
		self::add(
			$action,
			! is_wp_error( $result ),
			array(
				'post_id' => $post_id,
				'source'  => 'draftly',
				'code'    => is_wp_error( $result ) ? (string) $result->get_error_code() : '',
				'message' => is_wp_error( $result ) ? $result->get_error_message() : '',
			)
		);
	}

	/**
	 * The log, newest first.
	 *
	 * @return array
	 */
	public static function all() {
		$log = get_option( self::OPTION );
		return is_array( $log ) ? array_values( array_filter( $log, 'is_array' ) ) : array();
	}

	/**
	 * Whether Draftly's REST routes answer from this server, the way Draftly
	 * sees them (an unsigned request must get Draftly's own 401).
	 *
	 * @return array { ok: bool, detail: string }
	 */
	public static function rest_check() {
		$response = wp_remote_get(
			rest_url( Draftly_Rest::NAMESPACE_V1 . '/status' ),
			array(
				'timeout'     => 8,
				'redirection' => 0,
				'headers'     => array(
					'Accept'     => 'application/json',
					'User-Agent' => 'Draftly/1.0 (+https://www.draftly.blog) self-check',
				),
			)
		);
		if ( is_wp_error( $response ) ) {
			return array(
				'ok'     => false,
				'detail' => 'loopback failed: ' . $response->get_error_message() . ' (the host may block requests from the site to itself; this does not always mean Draftly is blocked)',
			);
		}
		$code = (int) wp_remote_retrieve_response_code( $response );
		$body = json_decode( wp_remote_retrieve_body( $response ), true );
		$err  = is_array( $body ) && isset( $body['code'] ) ? (string) $body['code'] : '';
		if ( 401 === $code && in_array( $err, array( 'draftly_bad_signature', 'draftly_not_connected' ), true ) ) {
			return array(
				'ok'     => true,
				'detail' => 'reachable (HTTP 401 ' . $err . ', as expected without a signature)',
			);
		}
		return array(
			'ok'     => false,
			'detail' => 'HTTP ' . $code . ( '' !== $err ? ' ' . $err : ' (not a JSON answer from WordPress: a firewall or security plugin answered)' ),
		);
	}

	/**
	 * What support needs, as plain text. No secrets: the connection key is
	 * never included, and the connection id is shortened.
	 *
	 * @return string
	 */
	public static function diagnostics() {
		global $wp_version;
		$conn    = Draftly_Connection::get();
		$rest    = self::rest_check();
		$user    = $conn ? get_userdata( (int) ( $conn['user_id'] ?? 0 ) ) : false;
		$copy    = Draftly_Connection::copy_of();
		$lines   = array(
			'Draftly plugin diagnostics (' . gmdate( 'Y-m-d H:i:s' ) . ' UTC)',
			'Site: ' . home_url() . ( is_multisite() ? ' (multisite, blog ' . get_current_blog_id() . ')' : '' ),
			'Plugin: ' . DRAFTLY_VERSION . ' | WordPress: ' . $wp_version . ' | PHP: ' . PHP_VERSION,
			'Permalinks: ' . ( get_option( 'permalink_structure' ) ? 'pretty' : 'plain' ) . ' | REST: ' . rest_url(),
			'REST reachability: ' . $rest['detail'],
			'SEO plugin: ' . Draftly_Seo_Meta::provider(),
			'Revisions: WP_POST_REVISIONS=' . ( defined( 'WP_POST_REVISIONS' ) ? var_export( WP_POST_REVISIONS, true ) : 'default' ) . ' | DISALLOW_UNFILTERED_HTML=' . ( defined( 'DISALLOW_UNFILTERED_HTML' ) && DISALLOW_UNFILTERED_HTML ? 'true' : 'false' ), // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_var_export -- shows a constant's value.
			'Connection: ' . ( $conn ? ( ( $conn['status'] ?? 'unknown' ) . ', id ' . substr( (string) $conn['connection_id'], 0, 8 ) . '…, connected ' . gmdate( 'Y-m-d', (int) ( $conn['connected_at'] ?? 0 ) ) ) : 'not connected' ),
			'Copy of another site: ' . ( '' !== $copy ? 'yes (connected to ' . $copy . ')' : 'no' ),
			'Connected user can post unfiltered HTML: ' . ( $user ? ( user_can( $user, 'unfiltered_html' ) ? 'yes' : 'no (posts with embeds or scripts are refused)' ) : 'n/a' ),
		);
		$errors  = array_slice(
			array_filter(
				self::all(),
				static function ( $e ) {
					return empty( $e['ok'] );
				}
			),
			0,
			10
		);
		$lines[] = 'Last errors:';
		if ( ! $errors ) {
			$lines[] = '  none';
		}
		foreach ( $errors as $e ) {
			$lines[] = '  ' . gmdate( 'Y-m-d H:i', (int) $e['t'] ) . ' ' . $e['source'] . ' ' . $e['action'] . ( $e['post_id'] ? ' post ' . $e['post_id'] : '' ) . ' ' . $e['code'] . ( $e['request_id'] ? ' ref ' . $e['request_id'] : '' ) . ': ' . $e['message'];
		}
		return implode( "\n", $lines );
	}
}

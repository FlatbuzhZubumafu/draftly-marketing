<?php
/**
 * The post list on Draftly > Optimize posts: filter tabs (All, Needs work,
 * Optimized, Excluded), each post's Draftly status, scores with what is
 * holding them back, and the row actions.
 *
 * @package Draftly
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WP_List_Table' ) ) {
	require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

/**
 * Posts with their Draftly scores and actions.
 */
class Draftly_Posts_Table extends WP_List_Table {

	/**
	 * Whether Draftly actions are available.
	 *
	 * @var bool
	 */
	private $connected;

	/**
	 * Auto-mode state from Draftly (for exclusions).
	 *
	 * @var array
	 */
	private $auto;

	/**
	 * Constructor.
	 *
	 * @param bool $connected Connected and verified.
	 */
	public function __construct( $connected ) {
		$this->connected = $connected;
		$this->auto      = Draftly_Auto_Mode::state();
		parent::__construct(
			array(
				'singular' => 'draftly-post',
				'plural'   => 'draftly-posts',
				'ajax'     => false,
			)
		);
	}

	/**
	 * Columns.
	 *
	 * @return array
	 */
	public function get_columns() {
		return array(
			'title'    => __( 'Post', 'draftly' ),
			'status'   => __( 'Status', 'draftly' ),
			'draftly'  => __( 'Draftly', 'draftly' ),
			'modified' => __( 'Last modified', 'draftly' ),
			'score'    => __( 'Draftly score', 'draftly' ),
			'actions'  => __( 'Actions', 'draftly' ),
		);
	}

	/**
	 * The current filter tab.
	 *
	 * @return string all | needs_work | optimized | excluded
	 */
	private function tab() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only list filter.
		$tab = isset( $_GET['draftly_tab'] ) ? sanitize_key( wp_unslash( $_GET['draftly_tab'] ) ) : 'all';
		return in_array( $tab, array( 'needs_work', 'optimized', 'excluded' ), true ) ? $tab : 'all';
	}

	/**
	 * Query args for a tab, merged into the list query (and used for the counts).
	 *
	 * @param string $tab Tab.
	 * @return array
	 */
	private function tab_args( $tab ) {
		switch ( $tab ) {
			case 'optimized':
				return array(
					// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- admin list filter on the plugin's own key.
					'meta_query' => array(
						'relation' => 'AND',
						array(
							'key'   => Draftly_Posts::META_STATE,
							'value' => 'optimized',
						),
						array(
							'key'     => Draftly_Posts::META_CHANGED,
							'compare' => 'NOT EXISTS',
						),
					),
				);
			case 'needs_work':
				return array(
					// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- admin list filter on the plugin's own key.
					'meta_query' => array(
						'relation' => 'OR',
						array(
							'key'     => Draftly_Posts::META_STATE,
							'value'   => array( 'checked', 'needs_work' ),
							'compare' => 'IN',
						),
						array(
							'key'     => Draftly_Posts::META_CHANGED,
							'compare' => 'EXISTS',
						),
					),
				);
			case 'excluded':
				$ids = self::excluded_ids( $this->auto );
				return array( 'post__in' => $ids ? $ids : array( 0 ) );
		}
		return array();
	}

	/**
	 * Ids of excluded posts: the excluded ids plus the posts in excluded categories.
	 *
	 * @param array $auto Auto-mode state.
	 * @return int[]
	 */
	public static function excluded_ids( array $auto ) {
		$ids  = array_map( 'intval', (array) ( $auto['excluded_post_ids'] ?? array() ) );
		$cats = array_map( 'intval', (array) ( $auto['excluded_category_ids'] ?? array() ) );
		if ( $cats ) {
			$in  = new WP_Query(
				array(
					'post_type'      => Draftly_Posts::POST_TYPES,
					'post_status'    => 'any',
					'fields'         => 'ids',
					'posts_per_page' => 1000, // phpcs:ignore WordPress.WP.PostsPerPage.posts_per_page_posts_per_page -- ids only, for the Excluded tab.
					'no_found_rows'  => true,
					'category__in'   => $cats,
				)
			);
			$ids = array_merge( $ids, array_map( 'intval', $in->posts ) );
		}
		return array_values( array_unique( array_filter( $ids ) ) );
	}

	/**
	 * Published posts in a Draftly state (for "Optimized N of M posts").
	 *
	 * @param string $state optimized.
	 * @return int
	 */
	public static function count_state( $state ) {
		$query = new WP_Query(
			array(
				'post_type'      => Draftly_Posts::POST_TYPES,
				'post_status'    => 'publish',
				'fields'         => 'ids',
				'posts_per_page' => 1,
				// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- one count on the plugin's own key.
				'meta_query'     => array(
					'relation' => 'AND',
					array(
						'key'   => Draftly_Posts::META_STATE,
						'value' => $state,
					),
					array(
						'key'     => Draftly_Posts::META_CHANGED,
						'compare' => 'NOT EXISTS',
					),
				),
			)
		);
		return (int) $query->found_posts;
	}

	/**
	 * Filter tabs: All · Needs work · Optimized · Excluded.
	 *
	 * @return array
	 */
	protected function get_views() {
		$current = $this->tab();
		$labels  = array(
			'all'        => __( 'All', 'draftly' ),
			'needs_work' => __( 'Needs work', 'draftly' ),
			'optimized'  => __( 'Optimized', 'draftly' ),
			'excluded'   => __( 'Excluded', 'draftly' ),
		);
		$views   = array();
		foreach ( $labels as $tab => $label ) {
			$url           = 'all' === $tab ? admin_url( 'admin.php?page=' . Draftly_Admin::PAGE_POSTS ) : admin_url( 'admin.php?page=' . Draftly_Admin::PAGE_POSTS . '&draftly_tab=' . $tab );
			$views[ $tab ] = '<a href="' . esc_url( $url ) . '"' . ( $current === $tab ? ' class="current" aria-current="page"' : '' ) . '>' . esc_html( $label ) . '</a>';
		}
		return $views;
	}

	/**
	 * Loads the current page of posts.
	 */
	public function prepare_items() {
		$per_page = 20;
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- read-only list filters.
		$search = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';
		$run_id = isset( $_GET['draftly_run'] ) ? preg_replace( '/[^A-Za-z0-9-]/', '', sanitize_text_field( wp_unslash( $_GET['draftly_run'] ) ) ) : '';
		// phpcs:enable
		$args = array(
			'post_type'      => Draftly_Posts::POST_TYPES,
			'post_status'    => array( 'publish', 'draft', 'pending', 'future', 'private' ),
			'posts_per_page' => $per_page,
			'paged'          => $this->get_pagenum(),
			's'              => $search,
			'orderby'        => 'modified',
			'order'          => 'DESC',
			'perm'           => 'editable',
		);
		if ( '' !== $run_id ) {
			$in               = Draftly_Posts::posts_in_run( $run_id );
			$args['post__in'] = $in ? $in : array( 0 );
		} else {
			$args = array_merge( $args, $this->tab_args( $this->tab() ) );
		}
		$query                 = new WP_Query( $args );
		$this->items           = $query->posts;
		$this->_column_headers = array( $this->get_columns(), array(), array() );
		$this->set_pagination_args(
			array(
				'total_items' => (int) $query->found_posts,
				'per_page'    => $per_page,
			)
		);
	}

	/**
	 * Empty list message.
	 */
	public function no_items() {
		esc_html_e( 'No posts found.', 'draftly' );
	}

	/**
	 * Title column.
	 *
	 * @param WP_Post $post Post.
	 * @return string
	 */
	public function column_title( $post ) {
		$title = get_the_title( $post );
		$edit  = get_edit_post_link( $post->ID );
		return '<strong>' . ( $edit ? '<a href="' . esc_url( $edit ) . '">' . esc_html( '' !== $title ? $title : __( '(no title)', 'draftly' ) ) . '</a>' : esc_html( $title ) ) . '</strong>';
	}

	/**
	 * Status column.
	 *
	 * @param WP_Post $post Post.
	 * @return string
	 */
	public function column_status( $post ) {
		$object = get_post_status_object( $post->post_status );
		return esc_html( $object ? $object->label : $post->post_status );
	}

	/**
	 * Draftly status column: Not checked, Needs work, Optimized (date), Changed since optimized, Excluded.
	 *
	 * @param WP_Post $post Post.
	 * @return string
	 */
	public function column_draftly( $post ) {
		return self::status_html( $post->ID, Draftly_Auto_Mode::is_excluded( $post->ID, $this->auto ) );
	}

	/**
	 * The status badge for a post.
	 *
	 * @param int  $post_id  Post id.
	 * @param bool $excluded Excluded from auto mode.
	 * @return string
	 */
	public static function status_html( $post_id, $excluded = false ) {
		$status = Draftly_Posts::status( $post_id );
		$out    = '<div class="draftly-status-cell" data-post="' . esc_attr( $post_id ) . '">';
		if ( 'optimized' === $status['state'] && $status['changed_since'] ) {
			$out .= '<span class="draftly-badge draftly-badge-changed">' . esc_html__( 'Changed since optimized', 'draftly' ) . '</span>';
		} elseif ( 'optimized' === $status['state'] ) {
			$date  = $status['optimized_at'] ? wp_date( get_option( 'date_format' ), $status['optimized_at'] ) : '';
			$label = $status['nothing_to_fix'] ? __( 'Optimized (nothing to fix)', 'draftly' ) : __( 'Optimized', 'draftly' );
			$out  .= '<span class="draftly-badge draftly-badge-optimized"><span aria-hidden="true">&#10003;</span> ' . esc_html( $label ) . '</span>';
			if ( $date ) {
				$out .= ' <span class="draftly-muted">' . esc_html( $date ) . '</span>';
			}
			if ( 'auto' === $status['source'] ) {
				$out .= ' <span class="draftly-muted">' . esc_html__( '(auto mode)', 'draftly' ) . '</span>';
			}
		} elseif ( 'not_checked' === $status['state'] ) {
			$out .= '<span class="draftly-muted">' . esc_html__( 'Not checked', 'draftly' ) . '</span>';
		} else {
			$out .= '<span class="draftly-badge draftly-badge-work">' . esc_html__( 'Needs work', 'draftly' ) . '</span>';
		}
		if ( $excluded ) {
			$out .= ' <span class="draftly-badge draftly-badge-excluded">' . esc_html__( 'Excluded', 'draftly' ) . '</span>';
		}
		return $out . '</div>';
	}

	/**
	 * Modified column.
	 *
	 * @param WP_Post $post Post.
	 * @return string
	 */
	public function column_modified( $post ) {
		return esc_html( get_the_modified_date( '', $post ) );
	}

	/**
	 * Score column.
	 *
	 * @param WP_Post $post Post.
	 * @return string
	 */
	public function column_score( $post ) {
		$scores = Draftly_Posts::scores( $post->ID );
		$out    = '<div class="draftly-scores" data-post="' . esc_attr( $post->ID ) . '">';
		if ( ! $scores ) {
			$out .= '<span class="draftly-muted">' . esc_html__( 'Not checked', 'draftly' ) . '</span>';
		} else {
			$labels    = array(
				'humanVoice'  => __( 'Human voice', 'draftly' ),
				'readability' => __( 'Readability', 'draftly' ),
			);
			$breakdown = is_array( $scores['breakdown'] ?? null ) ? $scores['breakdown'] : array();
			foreach ( $labels as $key => $label ) {
				if ( isset( $scores[ $key ] ) && null !== $scores[ $key ] ) {
					$value = (int) $scores[ $key ];
					$tone  = $value >= 80 ? 'good' : ( $value >= 60 ? 'ok' : 'low' );
					$items = isset( $breakdown[ $key ] ) && is_array( $breakdown[ $key ] ) ? $breakdown[ $key ] : array();
					$out  .= self::score_html( $label, $value, $tone, $items );
				}
			}
		}
		return $out . '</div>';
	}

	/**
	 * One score badge; with a breakdown, a "What is holding this back" disclosure.
	 *
	 * @param string $label Label.
	 * @param int    $value Score.
	 * @param string $tone  good | ok | low.
	 * @param array  $items Breakdown items { label, points, count }.
	 * @return string
	 */
	private static function score_html( $label, $value, $tone, array $items ) {
		$badge = '<span class="draftly-score draftly-score-' . esc_attr( $tone ) . '">' . esc_html( $label ) . ' ' . esc_html( (string) $value ) . '</span>';
		if ( ! $items || $value >= 100 ) {
			return $badge . ' ';
		}
		$list = '';
		foreach ( $items as $item ) {
			$points = (int) $item['points'];
			$count  = (int) $item['count'];
			$text   = $item['label'];
			if ( $count > 1 ) {
				/* translators: 1: issue, 2: number of places */
				$text = sprintf( __( '%1$s (%2$s places)', 'draftly' ), $item['label'], number_format_i18n( $count ) );
			}
			$list .= '<li>' . esc_html( $text ) . ( $points < 0 ? ' <strong>' . esc_html( (string) $points ) . '</strong>' : '' ) . '</li>';
		}
		return '<details class="draftly-breakdown"><summary>' . $badge . ' <span class="screen-reader-text">' . esc_html__( 'What is holding this back', 'draftly' ) . '</span></summary><ul>' . $list . '</ul></details> ';
	}

	/**
	 * Actions column.
	 *
	 * @param WP_Post $post Post.
	 * @return string
	 */
	public function column_actions( $post ) {
		if ( ! $this->connected || ! current_user_can( 'edit_post', $post->ID ) ) {
			return '';
		}
		$id   = esc_attr( $post->ID );
		$out  = '<button type="button" class="button draftly-action" data-action="check" data-post="' . $id . '">' . esc_html__( 'Check', 'draftly' ) . '</button> ';
		$out .= '<button type="button" class="button button-primary draftly-action" data-action="optimize" data-post="' . $id . '">' . esc_html__( 'Optimize', 'draftly' ) . '</button> ';
		if ( Draftly_Posts::can_revert( $post->ID ) ) {
			$out .= '<button type="button" class="button-link draftly-action" data-action="revert" data-post="' . $id . '">' . esc_html__( 'Revert', 'draftly' ) . '</button> ';
		}
		if ( ! empty( $this->auto['eligible'] ) && 'publish' === $post->post_status ) {
			$excluded = in_array( (int) $post->ID, array_map( 'intval', (array) $this->auto['excluded_post_ids'] ), true );
			$out     .= '<button type="button" class="button-link draftly-exclude" data-post="' . $id . '" data-exclude="' . ( $excluded ? '0' : '1' ) . '">' . esc_html( $excluded ? __( 'Include in auto mode', 'draftly' ) : __( 'Exclude from auto mode', 'draftly' ) ) . '</button>';
		}
		return $out;
	}

	/**
	 * Fallback for other columns.
	 *
	 * @param WP_Post $item        Post.
	 * @param string  $column_name Column.
	 * @return string
	 */
	public function column_default( $item, $column_name ) {
		return '';
	}
}

=== Draftly – AI Post Optimizer ===
Contributors: draftlyseodev
Tags: ai, seo, content, readability, meta description
Requires at least: 6.2
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.1.3
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Improve your existing posts: readability and writing that sounds like you. Approve each edit or use auto mode; every change can be reverted.

== Description ==

Draftly is available to businesses in the United States only. New Draftly accounts and plugin connections can only be set up from the US.

Draftly looks at the posts you already have and tells you what to fix: hard-to-read sentences and phrasing that sounds machine-written. When you ask it to, it suggests edits in your own brand voice. You review every suggested change side by side, keep the ones you like, and Draftly saves them to the post (WordPress keeps a revision as usual). If you change your mind, Revert puts back the content, title, excerpt and SEO title and description exactly as they were before Draftly's last change.

**What you can do from wp-admin**

* **Check** a post to get Human voice and Readability scores.
* **Optimize** a post to get suggested edits. Nothing changes until you approve.
* **Approve** only the edits you want. They are saved as a new revision.
* **Revert** restores the version from before Draftly's last change: content, title, excerpt and SEO fields, byte for byte. It works even when revisions are limited or turned off. If someone edited the post after Draftly, you are asked before those edits are undone.
* **See what is done.** Each post shows Not checked, Needs work or Optimized (with the date), and "Changed since optimized" when someone edits it afterwards. Tabs filter All, Needs work, Optimized and Excluded, and a progress line shows how many posts are optimized.
* **Auto mode (optional, paid plans).** Off until an administrator turns it on in Draftly > Settings. When it is on, Draftly works through your published posts a few at a time and applies edits right away at the level you pick: **Safe** (sentence-level fixes such as overused AI words, Title Case headings and a missing SEO title or description) or **Full** (everything Optimize suggests). Each change is a WordPress revision; Revert undoes a post and Revert this run undoes a whole batch. You can exclude posts and categories, run one batch with Run auto mode now, and turn it off any time. A weekly email lists every change.
* **SEO titles and meta descriptions** are read and written where your SEO plugin keeps them: Yoast SEO, Rank Math or All in One SEO. Without an SEO plugin, the post excerpt is used as the description.

**No passwords to copy.** Click Connect to Draftly, approve the site in your Draftly account, and you're done. The plugin never needs your WordPress password or an application password.

**Light on your site.** The plugin adds two admin screens and a few REST routes. It loads nothing on the front end of your site.

Draftly is a hosted service: the analysis and suggested edits are produced on Draftly's servers. You need a Draftly account. If you don't have one, you can create a free one in the Draftly tab that opens when you click Connect. Usage limits depend on your Draftly plan and are applied by Draftly. See [what's included](https://draftly.blog/wordpress-ai-plugin).

== External services ==

This plugin connects to Draftly (https://draftly.blog), a hosted writing and SEO service run by Draftly, to analyze and improve your posts. The plugin does not contact Draftly until an administrator clicks **Connect to Draftly** on the Draftly > Connection screen.

What is sent, and when:

* **When you click Connect to Draftly:** your site address, your site's REST API address, the address of the Connection screen (so Draftly can send you back), the plugin version and the WordPress version are sent to Draftly at https://app.draftly.blog/api/wordpress-plugin, and your browser opens https://app.draftly.blog in a new tab where you sign in (or create a free account) and approve the connection. While you approve, the plugin asks Draftly every few seconds whether the connection was approved, and then collects this site's connection key.
* **While connected, when a user clicks Check or Optimize:** that post's title, address and content are sent to Draftly, which returns scores and suggested edits.
* **When a user approves suggested edits:** the post's current content and the list of approved edits are sent to Draftly, which returns the updated content for the plugin to save.
* **When an administrator opens Draftly > Connection or Draftly > Settings, saves Draftly > Settings, clicks Run auto mode now, Retry verification or Exclude on a post:** the plugin asks Draftly for the connected account's email, plan, remaining credits, verification status and auto mode state, or sends the auto-mode settings (on or off, Safe or Full, excluded post and category ids) or the run request. When a user reverts a post or a run (Revert, Revert this run), the ids of the reverted posts are sent so Draftly can mark them as needing work.
* **Every request to Draftly** includes the plugin version and this site's address (so Draftly can tell a copy of the site, such as a staging clone, from the connected site).
* **When you disconnect or delete the plugin:** the plugin tells Draftly to revoke this site's connection. On a copy of a connected site it only forgets the connection locally.
* **Requests from Draftly to your site:** while connected, Draftly can call this plugin's REST routes (under /wp-json/draftly/v1/) to list and read posts, save edits and SEO titles/descriptions you approve in the Draftly app, create posts you send from Draftly (with the status, date and featured image you choose there), and revert Draftly's changes. On an existing post Draftly can only change the content, title, excerpt and SEO title, description and focus keyword; it cannot change a post's status, date, author, slug or featured image, and it never deletes posts. Every request is signed with this site's connection key and acts as the administrator who connected the site, with that user's permissions. Posts Draftly creates are attributed to that user. Content, titles and excerpts from Draftly are always filtered with WordPress's post HTML rules (the rules for users who can't post unfiltered HTML), even when the connected user is an administrator, so Draftly can't add scripts, iframes, forms or similar markup to your site. If a post already contains such markup and Draftly's version would change it, the change is refused and nothing is saved.
* **Which posts Draftly can read:** Draftly can list and read posts in any status except trash: published, scheduled, draft, pending and private. Posts are read when you or auto mode select them, or when you pick a post in the Draftly app.
* **AI processing:** post content you check or optimize, and posts auto mode works on, are processed by Draftly's AI providers (currently OpenAI, through the Vercel AI Gateway) to produce scores and suggested edits. See the [Draftly Privacy Policy](https://www.draftly.blog/privacy-policy).
* **Auto mode, only after an administrator turns it on (or clicks Run auto mode now):** Draftly lists your published posts (titles, addresses, modified dates, categories, word counts), reads the posts it picks, and saves its edits and missing SEO titles/descriptions to them through the same signed REST routes. Each change can be reverted. Auto mode never touches pages, drafts, private or password-protected posts, slugs, featured images or links.

**What Draftly keeps, and how to delete it.** Draftly keeps a copy of each post you check or optimize (the text it analyzed, its scores and suggested edits) and a record of the changes auto mode made, in your Draftly account. Deleting the plugin removes everything the plugin stored on your site (connection key, Draftly status, scores, revert snapshots and the activity log) and revokes the connection, but it does not delete your Draftly account or the copies kept there. To delete them, email support@draftly.blog from your account's address and ask for your Draftly account and its data to be deleted (deleting only the website in the Draftly app keeps the copies in your account).

The plugin keeps a short activity log (the last 50 Draftly actions on this site) in your WordPress database so you can see what Draftly did; it is never sent anywhere. No analytics or tracking data is collected by the plugin.

Draftly's [Terms and Conditions](https://www.draftly.blog/terms-and-conditions) and [Privacy Policy](https://www.draftly.blog/privacy-policy) apply to the data sent to Draftly.

== Installation ==

1. Install and activate the plugin from Plugins > Add New, or upload the `draftly` folder to `/wp-content/plugins/`.
2. Go to **Draftly > Connection** and click **Connect to Draftly**.
3. In the Draftly tab that opens, sign in or create a free account, pick the website, and click **Approve**.
4. Go to **Draftly > Optimize posts** and check or optimize a post.

== Frequently Asked Questions ==

= Is Draftly available outside the United States? =

Draftly is available to businesses in the United States only. New Draftly accounts and plugin connections can only be set up from the US.

= Does Draftly change my posts without asking? =

Not unless you turn on auto mode. By default Optimize only suggests edits, nothing is saved until you approve, and each approval is saved as a WordPress revision.

If an administrator turns on auto mode in Draftly > Settings (paid plans), Draftly applies edits automatically at the level you chose, without asking each time. Every change is still a revision you can revert, a weekly email lists them, and you can turn auto mode off at any time.

= What is the difference between Safe and Full? =

Safe applies only sentence-level fixes: overused AI words and stock phrases, hedging, em dashes and stray exclamation points, Title Case headings, and a missing SEO title or description (filled from the post title and opening). Full applies everything Optimize suggests, including rewrites of vague or unclear sentences. De-AI rewrites and new links are never applied automatically.

= How much of my plan does auto mode use? =

Each post auto mode works on uses one post optimization from your plan's monthly allowance (on main Draftly plans, one of the month's included auto mode posts). Auto mode never spends credits: when the allowance runs out it waits for the next month. It works on at most a few posts every 15 minutes, so your site is not loaded.

= How do I undo auto mode? =

Revert on a post restores the version from before Draftly's last change. Revert this run (in Draftly > Settings, or from the weekly email) does that for every post a run changed, except posts someone edited after the run, which are left as they are. Turning auto mode off stops further changes.

= How do I undo a change? =

Click Revert next to the post on Draftly > Optimize posts. It restores the content, title, excerpt and SEO title and description exactly as they were just before Draftly's last change (Draftly keeps that copy itself, so it works even with revisions limited or turned off). If the post was edited after Draftly's change, you are asked first, because reverting also removes those edits.

= Does the plugin need my WordPress password? =

No. The connection uses a per-site key that only this site and Draftly know. You can disconnect at any time from Draftly > Connection or from your Draftly account.

= Which SEO plugins are supported? =

Yoast SEO, Rank Math and All in One SEO (version 4 or later). Without one of them, the post excerpt is used as the meta description.

= Who can use it? =

Administrators connect and disconnect the site and change auto mode settings. Anyone who can edit a post can check, optimize, approve, revert and exclude that post.

= Draftly says "This looks like a copy of ..." =

The site was copied (for example to staging) together with its Draftly connection. The copy can't use or disconnect the original site's connection. Click Connect this site separately on Draftly > Connection to connect the copy as its own website.

= Draftly is stuck at "waiting for Draftly to verify this site" =

Draftly > Connection shows why Draftly can't reach the site and what to change. Usually a security plugin, firewall or "disable REST API" setting blocks logged-out requests to /wp-json/draftly/v1/. Allow that path (User-Agent Draftly/1.0), then click Retry verification. Copy diagnostics on the same screen collects the details support needs.

= Why was my change refused because of HTML Draftly does not save? =

Draftly only saves HTML that WordPress allows in posts for users without the unfiltered_html capability, whoever connected the site. If a post contains embeds, scripts, iframes or forms that those rules would remove, Draftly refuses to change it rather than strip them. Edit those posts by hand.

= Who can use Draftly on my site? =

Check, Optimize, Approve and Revert use your Draftly credits, so by default only users who can edit other people's posts (Editors and Administrators) see Draftly. Connecting, Settings and auto mode are for Administrators. A developer can change the role with the draftly_required_capability filter, for example add_filter( 'draftly_required_capability', fn() => 'publish_posts' );

= How do I contact support? =

Open Draftly > Support and click Email support: it copies our address so you can paste it into your email app. Include the Copy diagnostics output from Draftly > Connection so we can help faster.

= What does it cost? =

You need a Draftly account; the free account is enough to start. On the free account you can check and optimize up to 5 different posts (checking and optimizing the same post counts once, and you can keep working on those posts). To use Draftly on more posts, pick a plan or top up credits. Paid plans are described at https://draftly.blog/wordpress-ai-plugin. Auto mode is on paid plans. Plans set how much you can use; Draftly applies these limits on its side.

== Screenshots ==

1. Draftly > Optimize posts: status, scores and actions for each post.
2. Reviewing suggested edits before approving them.
3. Draftly > Connection.
4. Draftly > Settings: auto mode.

== Changelog ==

= 1.1.3 =
* Security: content, titles and excerpts sent by Draftly are filtered with WordPress's post HTML rules even when the connected user is an administrator, so Draftly can never add scripts or other unsafe markup. Posts that already contain such markup are refused instead of stripped.
* Security: posts created from Draftly are always attributed to the connected user.
* Security: Check, Optimize, Approve, Revert and auto-mode exclusions need a role that can edit others' posts (Editors and Administrators) by default, since they use your Draftly credits. Change it with the draftly_required_capability filter.
* Security: requests to the Draftly REST routes that aren't validly signed get the same "Unauthorized" answer whatever the reason; the reason is kept in Recent activity.

= 1.1.2 =
* Fixed: "Optimized N of M posts" could stay at 0 while posts showed the Optimized badge. The counter now uses the same rule as the badges, updates right after each Approve, Check or Revert without reloading, and counts posts Draftly recorded as optimized that this site had no status for.
* Fixed: the posts screen could say "Auto mode is on paid plans" on a paid plan, from an out-of-date copy of the account. It now refreshes the account from Draftly when it opens (at most every 5 minutes), and only says "paid plans" when the plan is the reason (an old plugin version or an unverified site now say so instead).
* Fixed: Draftly > Connection shows the plan Draftly actually applies.
* New: Draftly > Support, with an Email support button that copies our address. The support box is no longer on the other Draftly screens.
* After Approve, the post's Revert button appears without reloading.
* Readme: Draftly is available to businesses in the United States only.

= 1.1.1 =
* Fixed: Revert now restores the exact content, title, excerpt and SEO title, description and focus keyword from before Draftly's last change, from a copy Draftly keeps on the post. It no longer depends on revisions, so it works with revisions limited (WP_POST_REVISIONS=1) or off, and it can never restore someone's unsaved autosave. Revert shows only when there is something to revert.
* Fixed: SEO titles and descriptions keep backslashes and Yoast variables such as %%category%%, and excerpts keep their HTML, on save and on revert.
* Fixed: on multisite and with DISALLOW_UNFILTERED_HTML, a change that WordPress would strip embeds, scripts or forms from is refused with a clear message instead of saved, and Revert restores such posts without losing anything.
* Fixed: Approve and Revert check that the post hasn't changed since Draftly read it. Approve refuses with "Post changed since"; Revert asks before undoing later edits, and Revert this run skips posts edited after the run.
* Fixed: a staging copy of a connected site no longer acts on the original's connection: it shows "This looks like a copy of ..." with a button to connect it separately, and deleting the plugin on the copy no longer disconnects the original site.
* Changed: on existing posts Draftly can only change content, title, excerpt and SEO fields; status, date, featured image and other fields are refused.
* New: when Draftly can't verify the site, Draftly > Connection shows why (REST blocked, firewall, redirect...) and how to fix it.
* New: Recent activity (the last 50 Draftly actions on this site, with results and references) and a Copy diagnostics button on Draftly > Connection.
* Readme: the External services section now lists every post status Draftly can read, the AI processing, what Draftly keeps and how to delete it.
* Posts reverted with 1.1.0 or earlier keep their history in WordPress revisions; Revert in the plugin applies to changes made with 1.1.1 or later.

= 1.1.0 =
* New: auto mode (paid plans, off by default). Turn it on in Draftly > Settings and pick Auto mode: Safe or Full. Draftly applies edits to published posts a few at a time, each as a revision. Run auto mode now processes one batch without switching it on. Revert this run undoes a whole batch, and a weekly email lists every change.
* New: each post shows its Draftly status: Not checked, Needs work, Optimized (with the date; "nothing to fix" counts) or Changed since optimized. Filter tabs All, Needs work, Optimized and Excluded, and an "Optimized N of M posts" progress line.
* New: Exclude a post from auto mode from the list, or skip whole categories in Settings.
* New: click a score to see what is holding it back, with the points each issue costs.
* Optimize now also fixes exclamation points, em dash overuse and back-to-back "You" sentences, so a post with nothing else wrong can reach 100, and Readability is scored again after edits.

= 1.0.3 =
* Added a support box on the Draftly screens with the support email address, so you can send questions, bugs and feature ideas.

= 1.0.2 =
* Scores now show Human voice and Readability. The SEO score is no longer shown in the plugin.
* Free accounts: the posts screen shows how many of the 5 free posts you've used. When they're used up, the notice says so and offers See plans and Top up credits.

= 1.0.1 =
* Fixed: Check could fail with "Something went wrong" on longer posts. It now works on posts of any supported length.
* Clearer messages when something stops a Check or Optimize: what happened, whether you were charged (you never are for a run that fails), and what to do next, with Top up credits, See plans and Try again buttons.
* Each failed request shows a short reference code you can quote to Draftly support.
* After a Check or Optimize, the notice shows the credits used and what is left on your plan.
* Image captions and other shortcodes are no longer read as part of your text.

= 1.0.0 =
* First release: one-click connect, Check, Optimize with review and approval, Revert, and SEO meta for Yoast SEO, Rank Math and All in One SEO.

== Upgrade Notice ==

= 1.1.3 =
Security hardening: Draftly's changes are always HTML-filtered, and only Editors and Administrators can spend Draftly credits by default.

= 1.1.2 =
Fixes the "Optimized N of M posts" counter and the auto mode plan message; adds Draftly > Support.

= 1.1.1 =
Revert is now exact and works with limited revisions; safer saves on multisite and for staging copies; shows why verification fails, plus an activity log and diagnostics.

= 1.1.0 =
Adds optional auto mode (off until you turn it on), post status with filter tabs, and score breakdowns.

= 1.0.3 =
Adds an easy way to contact Draftly support.

= 1.0.2 =
Shows Human voice and Readability scores only, and shows free accounts how many of their 5 free posts they've used.

= 1.0.1 =
Fixes Check failing on longer posts and explains every error with a next step.

= 1.0.0 =
First release.

<?php
/**
 * Reading and changing posts for Draftly. Before every Draftly write the
 * post's exact content, title, excerpt and raw SEO meta are copied into post
 * meta (the snapshot); Revert puts those bytes back, so it works with
 * revisions limited or off and never picks up an autosave. Saves go through
 * wp_update_post as the connecting user (WordPress keeps a revision when
 * revisions are on). Whatever Draftly sends is filtered with WordPress's post
 * HTML rules (kses, as for an author without unfiltered_html) even when the
 * connecting user is an administrator, so Draftly can never add scripts,
 * iframes, forms or event handlers to a site. A post that already holds such
 * markup is refused instead of being stripped.
 *
 * Each post also carries its Draftly status (mirrored from Draftly for the
 * list on Draftly > Optimize posts): no meta = Not checked, then checked,
 * optimized (edits applied, or nothing to fix) or needs_work (reverted). An
 * optimized post that is saved in WordPress afterwards is flagged "changed
 * since optimized".
 *
 * @package Draftly
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Post helpers.
 */
class Draftly_Posts {

	/**
	 * Exact copy of the post from just before Draftly's last change: content,
	 * title, excerpt, raw SEO meta, and the post's hash right after Draftly's
	 * save. Revert restores from this (1.1.1+), never from revisions.
	 */
	const META_SNAPSHOT = '_draftly_snapshot';

	/** Revision id from just before Draftly's last change (display and Compare links only). */
	const META_REVERT = '_draftly_revert_revision';

	/** 1.1.0 and earlier: copy of the previous content. Only deleted now. */
	const META_PREVIOUS = '_draftly_previous_content';

	/** Latest Draftly scores: humanVoice, readability, checked_at. */
	const META_SCORES = '_draftly_scores';

	/** 1.1.0 and earlier: SEO meta from before Draftly's last meta change. Only deleted now. */
	const META_PREVIOUS_SEO = '_draftly_previous_seo';

	/** Draftly status: checked, optimized or needs_work. No meta = Not checked. */
	const META_STATE = '_draftly_state';

	/** Details of the last optimization: at (time), run_id, source (manual|auto), nothing_to_fix. */
	const META_OPTIMIZED = '_draftly_optimized';

	/** Set when an optimized post is saved in WordPress afterwards. */
	const META_CHANGED = '_draftly_changed_since';

	/** Auto-mode run that last changed the post (for "Revert this run"). */
	const META_RUN = '_draftly_run';

	/** Post types Draftly works with. Auto mode and the list are posts only. */
	const POST_TYPES = array( 'post' );

	/**
	 * True while Draftly itself saves a post, so the save isn't taken for an edit in WordPress.
	 *
	 * @var bool
	 */
	private static $saving = false;

	/**
	 * Hooks (front end and admin: posts can be saved from anywhere).
	 */
	public static function init() {
		add_action( 'save_post_post', array( __CLASS__, 'mark_changed' ), 10, 3 );
	}

	/**
	 * An optimized post saved in WordPress (not by Draftly) is "changed since optimized".
	 *
	 * @param int     $post_id Post id.
	 * @param WP_Post $post    Post.
	 * @param bool    $update  Existing post.
	 */
	public static function mark_changed( $post_id, $post, $update ) {
		if ( self::$saving || ! $update || wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
			return;
		}
		if ( 'optimized' === get_post_meta( $post_id, self::META_STATE, true ) ) {
			update_post_meta( $post_id, self::META_CHANGED, 1 );
		}
	}

	/**
	 * The post's Draftly status for display and filtering.
	 *
	 * @param int $post_id Post id.
	 * @return array { state: string ('not_checked'|'checked'|'optimized'|'needs_work'), changed_since: bool, optimized_at: int|null, run_id: string, source: string, nothing_to_fix: bool }
	 */
	public static function status( $post_id ) {
		$state = (string) get_post_meta( $post_id, self::META_STATE, true );
		$info  = get_post_meta( $post_id, self::META_OPTIMIZED, true );
		$info  = is_array( $info ) ? $info : array();
		return array(
			'state'          => in_array( $state, array( 'checked', 'optimized', 'needs_work' ), true ) ? $state : 'not_checked',
			'changed_since'  => 'optimized' === $state && (bool) get_post_meta( $post_id, self::META_CHANGED, true ),
			'optimized_at'   => isset( $info['at'] ) ? (int) $info['at'] : null,
			'run_id'         => (string) get_post_meta( $post_id, self::META_RUN, true ),
			'source'         => isset( $info['source'] ) ? (string) $info['source'] : '',
			'nothing_to_fix' => ! empty( $info['nothing_to_fix'] ),
		);
	}

	/**
	 * Whether a status (from status()) is "Optimized": the one rule behind the
	 * badge, the Optimized tab and the "Optimized N of M posts" counter.
	 *
	 * @param array $status status() result.
	 * @return bool
	 */
	public static function is_optimized( array $status ) {
		return 'optimized' === $status['state'] && ! $status['changed_since'];
	}

	/**
	 * WP_Query meta_query for posts is_optimized() accepts. The changed flag
	 * counts only when truthy, as in status() ('' or '0' is not changed).
	 *
	 * @return array
	 */
	public static function optimized_meta_query() {
		return array(
			'relation' => 'AND',
			array(
				'key'   => self::META_STATE,
				'value' => 'optimized',
			),
			array(
				'relation' => 'OR',
				array(
					'key'     => self::META_CHANGED,
					'compare' => 'NOT EXISTS',
				),
				array(
					'key'     => self::META_CHANGED,
					'value'   => array( '', '0' ),
					'compare' => 'IN',
				),
			),
		);
	}

	/**
	 * "Optimized N of M posts": published posts of POST_TYPES, and how many of
	 * them are Optimized by is_optimized(). Read fresh each time (no cache), so
	 * it matches the badges after every Approve, Check or Revert.
	 *
	 * @return array { optimized: int, total: int }
	 */
	public static function progress() {
		$total = 0;
		foreach ( self::POST_TYPES as $type ) {
			$counts = wp_count_posts( $type );
			$total += isset( $counts->publish ) ? (int) $counts->publish : 0;
		}
		$query     = new WP_Query(
			array(
				'post_type'              => self::POST_TYPES,
				'post_status'            => 'publish',
				'fields'                 => 'ids',
				'posts_per_page'         => -1, // phpcs:ignore WordPress.WP.PostsPerPage.posts_per_page_posts_per_page -- ids only, checked one by one below.
				'no_found_rows'          => true,
				'update_post_term_cache' => false,
				'cache_results'          => false,
				// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- one count on the plugin's own keys.
				'meta_query'             => self::optimized_meta_query(),
			)
		);
		$optimized = 0;
		update_meta_cache( 'post', $query->posts );
		foreach ( $query->posts as $post_id ) {
			// Same check as the badge, post by post.
			if ( self::is_optimized( self::status( (int) $post_id ) ) ) {
				++$optimized;
			}
		}
		return array(
			'optimized' => min( $optimized, $total ),
			'total'     => $total,
		);
	}

	/**
	 * Fills in the Draftly status of posts this site has no status for, from
	 * Draftly's own record (connection_status → post_statuses). A post that
	 * already has a status here keeps it: this site's meta is newer than
	 * anything Draftly heard (edits, reverts). Covers posts optimized before
	 * the plugin kept the status, or whose meta was lost.
	 *
	 * @param mixed $rows [{ id, state, nothing_to_fix, changed_since, optimized_at, source, run_id }].
	 * @return int Posts filled in.
	 */
	public static function reconcile( $rows ) {
		if ( ! is_array( $rows ) ) {
			return 0;
		}
		$filled = 0;
		foreach ( array_slice( $rows, 0, 5000 ) as $row ) {
			if ( ! is_array( $row ) || empty( $row['id'] ) || ! isset( $row['state'] ) ) {
				continue;
			}
			$post_id = absint( $row['id'] );
			$state   = sanitize_key( (string) $row['state'] );
			if ( ! $post_id || ! in_array( $state, array( 'checked', 'optimized', 'needs_work' ), true ) ) {
				continue;
			}
			$post = get_post( $post_id );
			if ( ! $post || ! in_array( $post->post_type, self::POST_TYPES, true ) || '' !== (string) get_post_meta( $post_id, self::META_STATE, true ) ) {
				continue;
			}
			update_post_meta( $post_id, self::META_STATE, $state );
			if ( 'optimized' === $state ) {
				update_post_meta(
					$post_id,
					self::META_OPTIMIZED,
					array(
						'at'             => isset( $row['optimized_at'] ) && is_numeric( $row['optimized_at'] ) ? (int) $row['optimized_at'] : time(),
						'source'         => isset( $row['source'] ) && 'auto' === $row['source'] ? 'auto' : 'manual',
						'nothing_to_fix' => ! empty( $row['nothing_to_fix'] ),
					)
				);
				if ( ! empty( $row['changed_since'] ) ) {
					update_post_meta( $post_id, self::META_CHANGED, 1 );
				}
				$run_id = isset( $row['run_id'] ) ? preg_replace( '/[^A-Za-z0-9-]/', '', (string) $row['run_id'] ) : '';
				if ( '' !== $run_id ) {
					update_post_meta( $post_id, self::META_RUN, $run_id );
				}
			}
			++$filled;
		}
		return $filled;
	}

	/**
	 * Sets the post's Draftly status.
	 *
	 * @param int    $post_id Post id.
	 * @param string $state   checked | optimized | needs_work.
	 * @param array  $args    For optimized: run_id, source (manual|auto), nothing_to_fix.
	 */
	public static function set_status( $post_id, $state, array $args = array() ) {
		if ( ! in_array( $state, array( 'checked', 'optimized', 'needs_work' ), true ) ) {
			return;
		}
		update_post_meta( $post_id, self::META_STATE, $state );
		delete_post_meta( $post_id, self::META_CHANGED );
		if ( 'optimized' === $state ) {
			$run_id = isset( $args['run_id'] ) ? preg_replace( '/[^A-Za-z0-9-]/', '', (string) $args['run_id'] ) : '';
			update_post_meta(
				$post_id,
				self::META_OPTIMIZED,
				array(
					'at'             => time(),
					'source'         => isset( $args['source'] ) && 'auto' === $args['source'] ? 'auto' : 'manual',
					'nothing_to_fix' => ! empty( $args['nothing_to_fix'] ),
				)
			);
			if ( '' !== $run_id ) {
				update_post_meta( $post_id, self::META_RUN, $run_id );
			} else {
				delete_post_meta( $post_id, self::META_RUN );
			}
		} else {
			delete_post_meta( $post_id, self::META_OPTIMIZED );
			delete_post_meta( $post_id, self::META_RUN );
		}
	}

	/**
	 * Summary of a post for lists.
	 *
	 * @param WP_Post $post            Post.
	 * @param bool    $include_content Include the rendered body.
	 * @return array
	 */
	public static function summary( WP_Post $post, $include_content = false ) {
		$out = array(
			'id'           => $post->ID,
			'type'         => $post->post_type,
			'title'        => get_the_title( $post ),
			'link'         => get_permalink( $post ),
			'status'       => $post->post_status,
			'date_gmt'     => $post->post_date_gmt,
			'modified_gmt' => $post->post_modified_gmt,
			'word_count'   => self::word_count( $post->post_content ),
			'has_password' => '' !== (string) $post->post_password,
			'categories'   => array_map( 'intval', wp_get_post_categories( $post->ID ) ),
			'draftly'      => array_merge(
				array(
					'scores'     => self::scores( $post->ID ),
					'can_revert' => self::can_revert( $post->ID ),
				),
				self::status( $post->ID )
			),
		);
		if ( $include_content ) {
			$out['content_rendered'] = self::rendered( $post );
		}
		return $out;
	}

	/** Scripts written without spaces between words (as UNSPACED_SCRIPT in Draftly's editor-text.ts). */
	const UNSPACED = '\\p{Han}\\p{Hiragana}\\p{Katakana}\\p{Thai}\\p{Lao}\\p{Khmer}\\p{Myanmar}\\p{Tibetan}';

	/**
	 * Words in a post body, for every language. str_word_count counts only
	 * ASCII letters, so Chinese, Japanese, Thai (and Arabic, Cyrillic...) posts
	 * came out as 0 words and auto mode skipped them as empty. Uses ICU word
	 * boundaries when the intl extension is there (like Draftly's server);
	 * otherwise each character of an unspaced script counts as a word.
	 *
	 * @param string $html Post content.
	 * @return int
	 */
	public static function word_count( $html ) {
		$text = html_entity_decode( wp_strip_all_tags( strip_shortcodes( (string) $html ) ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
		if ( '' === trim( $text ) ) {
			return 0;
		}
		$unspaced = (bool) preg_match( '/[' . self::UNSPACED . ']/u', $text );
		if ( $unspaced && class_exists( 'IntlBreakIterator' ) ) {
			$it = IntlBreakIterator::createWordInstance( get_locale() );
			if ( $it ) {
				$it->setText( $text );
				$count = 0;
				$prev  = 0;
				foreach ( $it as $boundary ) {
					if ( $boundary > $prev && $it->getRuleStatus() >= IntlBreakIterator::WORD_NONE_LIMIT && preg_match( '/[\\p{L}\\p{N}]/u', substr( $text, $prev, $boundary - $prev ) ) ) {
						++$count;
					}
					$prev = $boundary;
				}
				return $count;
			}
		}
		$count = 0;
		foreach ( preg_split( '/\\s+/u', $text, -1, PREG_SPLIT_NO_EMPTY ) as $word ) {
			$chars  = $unspaced ? preg_match_all( '/[' . self::UNSPACED . ']/u', $word ) : 0;
			$count += $chars ? $chars : ( preg_match( '/[\\p{L}\\p{N}]/u', $word ) ? 1 : 0 );
		}
		return $count;
	}

	/**
	 * Full post for editing.
	 *
	 * @param WP_Post $post Post.
	 * @return array
	 */
	public static function detail( WP_Post $post ) {
		return array_merge(
			self::summary( $post ),
			array(
				'content_raw'      => $post->post_content,
				// What Draftly read: sent back as expected_hash so a save never overwrites a newer version.
				'content_hash'     => self::content_hash( $post ),
				'content_rendered' => self::rendered( $post ),
				'excerpt'          => $post->post_excerpt,
				'meta'             => Draftly_Seo_Meta::get( $post->ID ),
			)
		);
	}

	/**
	 * The body as visitors see it.
	 *
	 * @param WP_Post $post Post.
	 * @return string
	 */
	private static function rendered( WP_Post $post ) {
		// Core filter, so the body renders exactly as on the site.
		return apply_filters( 'the_content', $post->post_content ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound
	}

	/**
	 * Stored scores, or null.
	 *
	 * @param int $post_id Post id.
	 * @return array|null
	 */
	public static function scores( $post_id ) {
		$scores = get_post_meta( $post_id, self::META_SCORES, true );
		return is_array( $scores ) ? $scores : null;
	}

	/**
	 * Saves scores from a Draftly check or optimization.
	 *
	 * @param int   $post_id   Post id.
	 * @param array $scores    Scores.
	 * @param array $breakdown Score breakdown from Draftly (optional).
	 */
	public static function save_scores( $post_id, $scores, $breakdown = null ) {
		if ( ! is_array( $scores ) ) {
			return;
		}
		$clean = array( 'checked_at' => time() );
		foreach ( array( 'humanVoice', 'readability' ) as $key ) {
			$clean[ $key ] = isset( $scores[ $key ] ) && is_numeric( $scores[ $key ] ) ? (int) round( $scores[ $key ] ) : null;
		}
		$clean['breakdown'] = self::clean_breakdown( $breakdown );
		update_post_meta( $post_id, self::META_SCORES, $clean );
	}

	/**
	 * "What's holding this score back" from Draftly, reduced to labels and numbers.
	 *
	 * @param mixed $breakdown { humanVoice: [{label, points, count}], readability: [...] }.
	 * @return array
	 */
	public static function clean_breakdown( $breakdown ) {
		$out = array();
		foreach ( array( 'humanVoice', 'readability' ) as $key ) {
			$out[ $key ] = array();
			if ( ! is_array( $breakdown ) || ! isset( $breakdown[ $key ] ) || ! is_array( $breakdown[ $key ] ) ) {
				continue;
			}
			foreach ( array_slice( $breakdown[ $key ], 0, 12 ) as $item ) {
				if ( ! is_array( $item ) || ! isset( $item['label'] ) ) {
					continue;
				}
				$out[ $key ][] = array(
					'label'  => sanitize_text_field( (string) $item['label'] ),
					'points' => isset( $item['points'] ) ? (int) $item['points'] : 0,
					'count'  => isset( $item['count'] ) ? absint( $item['count'] ) : 0,
				);
			}
		}
		return $out;
	}

	/**
	 * The WordPress revision holding the version from before Draftly's last
	 * change, or 0. For display and Compare links only: Revert restores from
	 * the snapshot, never from a revision.
	 *
	 * @param int $post_id Post id.
	 * @return int
	 */
	public static function revert_revision( $post_id ) {
		$revision_id = (int) get_post_meta( $post_id, self::META_REVERT, true );
		if ( ! $revision_id ) {
			return 0;
		}
		$revision = wp_get_post_revision( $revision_id );
		return $revision && (int) $revision->post_parent === (int) $post_id && ! wp_is_post_autosave( $revision ) ? $revision_id : 0;
	}

	/**
	 * Ids of posts whose last Draftly change came from this auto-mode run.
	 *
	 * @param string $run_id Run id.
	 * @return int[]
	 */
	public static function posts_in_run( $run_id ) {
		$run_id = preg_replace( '/[^A-Za-z0-9-]/', '', (string) $run_id );
		if ( '' === $run_id ) {
			return array();
		}
		$query = new WP_Query(
			array(
				'post_type'      => self::POST_TYPES,
				'post_status'    => 'any',
				'fields'         => 'ids',
				'posts_per_page' => 200, // phpcs:ignore WordPress.WP.PostsPerPage.posts_per_page_posts_per_page -- ids only; a run changes a handful of posts.
				'no_found_rows'  => true,
				'meta_key'       => self::META_RUN, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- one admin lookup, on demand.
				'meta_value'     => $run_id, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value -- one admin lookup, on demand.
			)
		);
		return array_map( 'intval', $query->posts );
	}

	/**
	 * The snapshot taken before Draftly's last change, or null.
	 *
	 * @param int $post_id Post id.
	 * @return array|null
	 */
	public static function snapshot( $post_id ) {
		$snapshot = get_post_meta( $post_id, self::META_SNAPSHOT, true );
		return is_array( $snapshot ) && isset( $snapshot['content'], $snapshot['title'], $snapshot['excerpt'] ) ? $snapshot : null;
	}

	/**
	 * Whether there is a Draftly change to revert (a snapshot exists).
	 *
	 * @param int $post_id Post id.
	 * @return bool
	 */
	public static function can_revert( $post_id ) {
		return null !== self::snapshot( $post_id );
	}

	/**
	 * Fingerprint of what a reader or editor would call "the post": body, title
	 * and excerpt. Used to tell whether the post changed between Draftly
	 * reading it and saving, and since Draftly's last save.
	 *
	 * @param WP_Post $post Post.
	 * @return string
	 */
	public static function content_hash( WP_Post $post ) {
		return hash( 'sha256', $post->post_content . "\0" . $post->post_title . "\0" . $post->post_excerpt );
	}

	/**
	 * The post as it is in the database now (no stale object cache).
	 *
	 * @param int $post_id Post id.
	 * @return WP_Post|null
	 */
	private static function fresh( $post_id ) {
		clean_post_cache( $post_id );
		$post = get_post( $post_id );
		return $post instanceof WP_Post ? $post : null;
	}

	/**
	 * Saves the exact current content, title, excerpt and raw SEO meta before
	 * Draftly changes the post (B3). Stored in post meta, slashed so WordPress
	 * keeps every backslash, and independent of revisions, autosaves and
	 * WP_POST_REVISIONS.
	 *
	 * @param WP_Post $post Post (fresh from the database).
	 */
	private static function take_snapshot( WP_Post $post ) {
		$snapshot = array(
			'version'  => 1,
			'content'  => (string) $post->post_content,
			'title'    => (string) $post->post_title,
			'excerpt'  => (string) $post->post_excerpt,
			'seo'      => Draftly_Seo_Meta::raw( $post->ID ),
			'taken_at' => time(),
			'after'    => null,
		);
		update_post_meta( $post->ID, self::META_SNAPSHOT, wp_slash( $snapshot ) );

		// A revision of the pre-Draftly version, for the post's history and the
		// weekly email's Compare link. Never an autosave; may be pruned later.
		delete_post_meta( $post->ID, self::META_REVERT );
		if ( wp_revisions_enabled( $post ) ) {
			$revision_id = wp_save_post_revision( $post->ID );
			if ( $revision_id && ! is_wp_error( $revision_id ) ) {
				update_post_meta( $post->ID, self::META_REVERT, (int) $revision_id );
			}
		}
	}

	/**
	 * Records the state right after Draftly's save, so Revert can tell whether
	 * someone changed the post since (H2).
	 *
	 * @param int $post_id Post id.
	 */
	private static function seal_snapshot( $post_id ) {
		$snapshot = self::snapshot( $post_id );
		$post     = self::fresh( $post_id );
		if ( ! $snapshot || ! $post ) {
			return;
		}
		$snapshot['after'] = array(
			'modified_gmt' => $post->post_modified_gmt,
			'hash'         => self::content_hash( $post ),
		);
		update_post_meta( $post_id, self::META_SNAPSHOT, wp_slash( $snapshot ) );
	}

	/**
	 * Why WordPress's HTML filtering (kses) would change these fields when the
	 * current user saves them, or ''. kses runs for users without the
	 * unfiltered_html capability: every user on a multisite sub-site except
	 * super admins, and everyone when DISALLOW_UNFILTERED_HTML is set. Saving
	 * would then strip scripts, iframes, forms and embeds from the whole post,
	 * so Draftly refuses instead (B4).
	 *
	 * @param array $fields wp_update_post fields (unslashed).
	 * @return string Field name that would change, or ''.
	 */
	public static function kses_would_alter( array $fields ) {
		if ( current_user_can( 'unfiltered_html' ) ) {
			return '';
		}
		$checks = array(
			'post_content' => 'wp_filter_post_kses',
			'post_excerpt' => 'wp_filter_post_kses',
			'post_title'   => 'wp_filter_kses',
		);
		foreach ( $checks as $field => $filter ) {
			if ( ! isset( $fields[ $field ] ) || '' === $fields[ $field ] ) {
				continue;
			}
			$value = (string) $fields[ $field ];
			if ( wp_unslash( call_user_func( $filter, wp_slash( $value ) ) ) !== $value ) {
				return $field;
			}
		}
		return '';
	}

	/** The kses filter per field: the post HTML rules for the body and excerpt, the stricter title rules. */
	const KSES_FILTERS = array(
		'post_content' => 'wp_filter_post_kses',
		'post_excerpt' => 'wp_filter_post_kses',
		'post_title'   => 'wp_filter_kses',
	);

	/**
	 * A field's value after kses, whatever the current user's capabilities.
	 *
	 * @param string $field post_content, post_excerpt or post_title.
	 * @param string $value Value (unslashed).
	 * @return string
	 */
	public static function kses_value( $field, $value ) {
		return wp_unslash( call_user_func( self::KSES_FILTERS[ $field ], wp_slash( (string) $value ) ) );
	}

	/**
	 * Whether kses would remove markup from the value: tags, attributes or
	 * URL schemes. Entity normalisation alone ("&" to "&amp;") doesn't count.
	 *
	 * @param string $field post_content, post_excerpt or post_title.
	 * @param string $value Value (unslashed).
	 * @return bool
	 */
	public static function kses_strips_markup( $field, $value ) {
		$value = (string) $value;
		if ( '' === $value ) {
			return false;
		}
		return self::kses_value( $field, $value ) !== wp_kses_normalize_entities( wp_kses_no_null( $value ) );
	}

	/**
	 * Draftly's fields as they may be saved (P-1). Everything Draftly sends is
	 * run through kses, as for a user without unfiltered_html, even though the
	 * request acts as the connecting administrator: a compromised Draftly
	 * server can't push scripts into the site. When the post already holds
	 * markup kses would remove (the site's own embeds, scripts or forms) and
	 * Draftly's version still holds markup kses would remove, the save is
	 * refused, so the site's own markup is never stripped and nothing new
	 * slips through with it.
	 *
	 * @param array        $fields  wp_insert_post / wp_update_post fields (unslashed).
	 * @param WP_Post|null $current The post before the save (null when creating).
	 * @return array|WP_Error
	 */
	public static function filter_from_draftly( array $fields, $current = null ) {
		foreach ( array_keys( self::KSES_FILTERS ) as $field ) {
			if ( ! isset( $fields[ $field ] ) || '' === $fields[ $field ] ) {
				continue;
			}
			$value = (string) $fields[ $field ];
			if ( ! self::kses_strips_markup( $field, $value ) ) {
				$fields[ $field ] = self::kses_value( $field, $value );
				continue;
			}
			if ( $current instanceof WP_Post && self::kses_strips_markup( $field, (string) $current->$field ) ) {
				return self::unfiltered_html_error();
			}
			$fields[ $field ] = self::kses_value( $field, $value );
		}
		return $fields;
	}

	/**
	 * The error for a save kses would change.
	 *
	 * @return WP_Error
	 */
	private static function unfiltered_html_error() {
		return new WP_Error(
			'draftly_unfiltered_html',
			__( 'This post contains HTML (such as embeds, scripts, iframes or forms) that Draftly does not save, and Draftly\'s version would remove or change it. Nothing was saved. Edit this post by hand.', 'draftly' ),
			array( 'status' => 403 )
		);
	}

	/**
	 * The error when the post changed since Draftly read it.
	 *
	 * @return WP_Error
	 */
	private static function changed_error() {
		return new WP_Error(
			'draftly_post_changed',
			__( 'Post changed since Draftly read it. Nothing was saved. Re-check the post and try again.', 'draftly' ),
			array( 'status' => 409 )
		);
	}

	/**
	 * Applies an update from Draftly: content, title, excerpt and SEO meta,
	 * nothing else (H6). Only fields present are changed.
	 *
	 * Guards (H2): expected_modified_gmt and expected_hash (content_hash of
	 * what Draftly read) refuse the save with 409 when the post changed since.
	 *
	 * @param WP_Post $post  Post.
	 * @param array   $input Fields.
	 * @return WP_Post|WP_Error
	 */
	public static function update( WP_Post $post, array $input ) {
		$fields = self::update_fields_from( $input );
		if ( is_wp_error( $fields ) ) {
			return $fields;
		}
		$current = self::fresh( $post->ID );
		if ( ! $current ) {
			return new WP_Error( 'draftly_not_found', 'Post not found.', array( 'status' => 404 ) );
		}
		if ( isset( $input['expected_modified_gmt'] ) && null !== $input['expected_modified_gmt'] ) {
			if ( ! is_string( $input['expected_modified_gmt'] ) ) {
				return new WP_Error( 'draftly_bad_request', 'expected_modified_gmt must be a string', array( 'status' => 400 ) );
			}
			if ( '' !== $input['expected_modified_gmt'] && $input['expected_modified_gmt'] !== $current->post_modified_gmt ) {
				return self::changed_error();
			}
		}
		if ( isset( $input['expected_hash'] ) && null !== $input['expected_hash'] ) {
			if ( ! is_string( $input['expected_hash'] ) || ! hash_equals( self::content_hash( $current ), $input['expected_hash'] ) ) {
				return self::changed_error();
			}
		}
		$fields = self::filter_from_draftly( $fields, $current );
		if ( is_wp_error( $fields ) ) {
			return $fields;
		}
		self::$saving = true;
		$result       = self::update_fields( $current, $input, $fields );
		self::$saving = false;
		if ( ! is_wp_error( $result ) && isset( $input['draftly'] ) && is_array( $input['draftly'] ) && 'optimized' === ( $input['draftly']['state'] ?? '' ) ) {
			self::set_status( $post->ID, 'optimized', $input['draftly'] );
			if ( isset( $input['draftly']['scores'] ) && is_array( $input['draftly']['scores'] ) ) {
				self::save_scores( $post->ID, $input['draftly']['scores'], $input['draftly']['breakdown'] ?? null );
			}
		}
		return $result;
	}

	/**
	 * Fields POST /posts/{id} may change: content, title and excerpt. Anything
	 * that changes how or when the post is published is refused.
	 *
	 * @param array $input Input.
	 * @return array|WP_Error wp_update_post fields (unslashed).
	 */
	private static function update_fields_from( array $input ) {
		foreach ( array( 'status', 'date_gmt', 'featured_image', 'slug', 'categories', 'author', 'password' ) as $key ) {
			if ( array_key_exists( $key, $input ) ) {
				return new WP_Error(
					'draftly_field_not_allowed',
					/* translators: %s: field name */
					sprintf( __( 'Draftly can only change a post\'s content, title, excerpt and SEO title and description. "%s" was refused.', 'draftly' ), $key ),
					array( 'status' => 400 )
				);
			}
		}
		$fields = array();
		foreach ( array(
			'content' => 'post_content',
			'title'   => 'post_title',
			'excerpt' => 'post_excerpt',
		) as $key => $field ) {
			if ( ! isset( $input[ $key ] ) ) {
				continue;
			}
			if ( ! is_string( $input[ $key ] ) ) {
				return new WP_Error( 'draftly_bad_' . $key, $key . ' must be a string', array( 'status' => 400 ) );
			}
			// Saved as the connecting user after filter_from_draftly().
			$fields[ $field ] = 'post_title' === $field ? self::clean_title( $input[ $key ] ) : $input[ $key ];
		}
		return $fields;
	}

	/**
	 * A title as WordPress stores it: one line, no control characters. HTML and
	 * percent signs are kept (sanitize_text_field would strip "%ab").
	 *
	 * @param string $title Title.
	 * @return string
	 */
	private static function clean_title( $title ) {
		$title = wp_check_invalid_utf8( $title );
		return trim( (string) preg_replace( '/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]+|[\r\n\t]+/', ' ', $title ) );
	}

	/**
	 * The write itself, for update().
	 *
	 * @param WP_Post $post   Post (fresh).
	 * @param array   $input  Input.
	 * @param array   $fields wp_update_post fields (unslashed).
	 * @return WP_Post|WP_Error
	 */
	private static function update_fields( WP_Post $post, array $input, array $fields ) {
		$meta = isset( $input['meta'] ) && is_array( $input['meta'] ) ? $input['meta'] : null;
		if ( ! $fields && null === $meta ) {
			return $post;
		}
		// Revert always means "undo Draftly's last change": a new snapshot replaces the old one.
		delete_post_meta( $post->ID, self::META_PREVIOUS );
		delete_post_meta( $post->ID, self::META_PREVIOUS_SEO );
		self::take_snapshot( $post );
		if ( $fields ) {
			$fields['ID'] = $post->ID;
			$saved        = wp_update_post( wp_slash( $fields ), true );
			if ( is_wp_error( $saved ) ) {
				self::drop_snapshot( $post->ID );
				return $saved;
			}
		}
		if ( null !== $meta ) {
			$extra = self::apply_meta( $post->ID, $meta );
			if ( is_wp_error( $extra ) ) {
				return $extra;
			}
		}
		self::seal_snapshot( $post->ID );
		return self::fresh( $post->ID );
	}

	/**
	 * A save that failed changed nothing: drop the snapshot taken for it.
	 *
	 * @param int $post_id Post id.
	 */
	private static function drop_snapshot( $post_id ) {
		delete_post_meta( $post_id, self::META_SNAPSHOT );
		delete_post_meta( $post_id, self::META_REVERT );
	}

	/**
	 * Creates a post from Draftly (publishing a Draftly draft).
	 *
	 * @param array $input Fields.
	 * @return WP_Post|WP_Error
	 */
	public static function create( array $input ) {
		$fields = self::create_fields( $input );
		if ( is_wp_error( $fields ) ) {
			return $fields;
		}
		$fields['post_type'] = 'post';
		if ( empty( $fields['post_status'] ) ) {
			$fields['post_status'] = 'draft';
		}
		// Always the connected user: Draftly can't attribute posts to anyone else (P-1).
		$fields['post_author'] = get_current_user_id();
		$fields                = self::filter_from_draftly( $fields );
		if ( is_wp_error( $fields ) ) {
			return $fields;
		}
		$id = wp_insert_post( wp_slash( $fields ), true );
		if ( is_wp_error( $id ) ) {
			return $id;
		}
		if ( isset( $input['meta'] ) && is_array( $input['meta'] ) ) {
			$extra = self::apply_meta( $id, $input['meta'] );
			if ( is_wp_error( $extra ) ) {
				return $extra;
			}
		}
		if ( isset( $input['featured_image'] ) && is_array( $input['featured_image'] ) ) {
			$attachment = self::sideload_image( $id, $input['featured_image'] );
			if ( ! is_wp_error( $attachment ) ) {
				set_post_thumbnail( $id, $attachment );
			}
		}
		return get_post( $id );
	}

	/**
	 * Restores the post to the snapshot from just before Draftly's last change.
	 *
	 * @param WP_Post $post  Post.
	 * @param bool    $force Revert even if the post was edited after Draftly's change (the caller confirmed).
	 * @return WP_Post|WP_Error
	 */
	public static function revert( WP_Post $post, $force = false ) {
		self::$saving = true;
		$result       = self::restore( $post, $force );
		self::$saving = false;
		if ( ! is_wp_error( $result ) ) {
			self::set_status( $post->ID, 'needs_work' );
		}
		return $result;
	}

	/**
	 * Whether the post was edited after Draftly's last save (H2).
	 *
	 * @param WP_Post $post     Post (fresh).
	 * @param array   $snapshot Snapshot.
	 * @return bool
	 */
	public static function changed_since_snapshot( WP_Post $post, array $snapshot ) {
		$after = isset( $snapshot['after'] ) && is_array( $snapshot['after'] ) ? $snapshot['after'] : null;
		if ( ! $after || empty( $after['hash'] ) ) {
			// No record of the save (it failed half-way): only the changed flag can tell.
			return (bool) get_post_meta( $post->ID, self::META_CHANGED, true );
		}
		return ! hash_equals( (string) $after['hash'], self::content_hash( $post ) );
	}

	/**
	 * The restore itself, for revert(). Writes the snapshot back byte for byte:
	 * kses is bypassed (the snapshot is the site's own content, which was
	 * already stored), and if any other save filter still changes it, the
	 * three fields are written to the posts table directly.
	 *
	 * @param WP_Post $post  Post.
	 * @param bool    $force Ignore later edits.
	 * @return WP_Post|WP_Error
	 */
	private static function restore( WP_Post $post, $force ) {
		$snapshot = self::snapshot( $post->ID );
		if ( ! $snapshot ) {
			return new WP_Error( 'draftly_nothing_to_revert', __( 'There is no Draftly change to revert on this post.', 'draftly' ), array( 'status' => 409 ) );
		}
		$current = self::fresh( $post->ID );
		if ( ! $current ) {
			return new WP_Error( 'draftly_not_found', 'Post not found.', array( 'status' => 404 ) );
		}
		if ( ! $force && self::changed_since_snapshot( $current, $snapshot ) ) {
			return new WP_Error(
				'draftly_post_changed',
				__( 'Post changed since Draftly\'s change. Reverting would also undo those later edits. Re-check the post first, or confirm to revert anyway.', 'draftly' ),
				array( 'status' => 409 )
			);
		}
		$wanted = array(
			'post_content' => (string) $snapshot['content'],
			'post_title'   => (string) $snapshot['title'],
			'post_excerpt' => (string) $snapshot['excerpt'],
		);
		$kses   = false !== has_filter( 'content_save_pre', 'wp_filter_post_kses' );
		if ( $kses ) {
			kses_remove_filters();
		}
		$saved = wp_update_post( wp_slash( array_merge( array( 'ID' => $post->ID ), $wanted ) ), true );
		if ( $kses ) {
			kses_init_filters();
		}
		if ( is_wp_error( $saved ) ) {
			return $saved;
		}
		$after = self::fresh( $post->ID );
		if ( $after && ( $after->post_content !== $wanted['post_content'] || $after->post_title !== $wanted['post_title'] || $after->post_excerpt !== $wanted['post_excerpt'] ) ) {
			global $wpdb;
			// A save filter changed the snapshot; put the exact bytes back. This is the site's own earlier content.
			$wpdb->update( $wpdb->posts, $wanted, array( 'ID' => $post->ID ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- one row, cache cleared next line.
			clean_post_cache( $post->ID );
		}
		if ( isset( $snapshot['seo'] ) && is_array( $snapshot['seo'] ) ) {
			Draftly_Seo_Meta::restore_raw( $post->ID, $snapshot['seo'] );
		}
		delete_post_meta( $post->ID, self::META_SNAPSHOT );
		delete_post_meta( $post->ID, self::META_REVERT );
		delete_post_meta( $post->ID, self::META_PREVIOUS );
		delete_post_meta( $post->ID, self::META_PREVIOUS_SEO );
		delete_post_meta( $post->ID, self::META_SCORES );
		return self::fresh( $post->ID );
	}

	/**
	 * Maps Draftly's fields to wp_insert_post fields for a new post, validating each.
	 *
	 * @param array $input Input.
	 * @return array|WP_Error
	 */
	private static function create_fields( array $input ) {
		$fields = array();
		foreach ( array(
			'content' => 'post_content',
			'title'   => 'post_title',
			'excerpt' => 'post_excerpt',
		) as $key => $field ) {
			if ( ! isset( $input[ $key ] ) ) {
				continue;
			}
			if ( ! is_string( $input[ $key ] ) ) {
				return new WP_Error( 'draftly_bad_' . $key, $key . ' must be a string', array( 'status' => 400 ) );
			}
			$fields[ $field ] = 'post_title' === $field ? self::clean_title( $input[ $key ] ) : $input[ $key ];
		}
		if ( isset( $input['status'] ) ) {
			$status = sanitize_key( $input['status'] );
			if ( ! in_array( $status, array( 'draft', 'publish', 'pending', 'private', 'future' ), true ) ) {
				return new WP_Error( 'draftly_bad_status', 'Unsupported status', array( 'status' => 400 ) );
			}
			if ( in_array( $status, array( 'publish', 'future', 'private' ), true ) && ! current_user_can( 'publish_posts' ) ) {
				return new WP_Error( 'draftly_cannot_publish', __( 'The connected WordPress user cannot publish posts.', 'draftly' ), array( 'status' => 403 ) );
			}
			$fields['post_status'] = $status;
		}
		if ( ! empty( $input['date_gmt'] ) && is_string( $input['date_gmt'] ) ) {
			$time = strtotime( $input['date_gmt'] );
			if ( false === $time ) {
				return new WP_Error( 'draftly_bad_date', 'Invalid date_gmt', array( 'status' => 400 ) );
			}
			$fields['post_date_gmt'] = gmdate( 'Y-m-d H:i:s', $time );
			$fields['post_date']     = get_date_from_gmt( $fields['post_date_gmt'] );
			$fields['edit_date']     = true;
		}
		if ( ! empty( $input['slug'] ) && is_string( $input['slug'] ) ) {
			$fields['post_name'] = sanitize_title( $input['slug'] );
		}
		if ( ! empty( $input['categories'] ) && is_array( $input['categories'] ) ) {
			$fields['post_category'] = array_values( array_filter( array_map( 'absint', $input['categories'] ) ) );
		}
		// 'author' (sent by Draftly before 1.1.3) is ignored: posts are always the connected user's.
		return $fields;
	}

	/**
	 * SEO title, description and focus keyword, wherever the site's SEO plugin keeps them.
	 *
	 * @param int   $post_id Post id.
	 * @param array $meta    { title, description, focus_keyword }.
	 * @return true|WP_Error
	 */
	private static function apply_meta( $post_id, array $meta ) {
		$description = isset( $meta['description'] ) && is_string( $meta['description'] ) ? $meta['description'] : null;
		// Without an SEO plugin the description is the excerpt: same filtering rule as the body.
		if ( null !== $description && 'none' === Draftly_Seo_Meta::provider() && '' !== self::kses_would_alter( array( 'post_excerpt' => $description ) ) ) {
			return self::unfiltered_html_error();
		}
		$saved = Draftly_Seo_Meta::set(
			$post_id,
			isset( $meta['title'] ) && is_string( $meta['title'] ) ? $meta['title'] : null,
			$description,
			isset( $meta['focus_keyword'] ) && is_string( $meta['focus_keyword'] ) ? $meta['focus_keyword'] : null
		);
		return is_wp_error( $saved ) ? $saved : true;
	}

	/**
	 * Saves a base64 image from Draftly to the media library.
	 *
	 * @param int   $post_id Post id.
	 * @param array $image   { mime, data_base64, filename }.
	 * @return int|WP_Error Attachment id.
	 */
	private static function sideload_image( $post_id, array $image ) {
		$allowed = array(
			'image/png'  => 'png',
			'image/jpeg' => 'jpg',
			'image/webp' => 'webp',
			'image/gif'  => 'gif',
		);
		$mime    = isset( $image['mime'] ) ? (string) $image['mime'] : '';
		if ( ! isset( $allowed[ $mime ] ) || empty( $image['data_base64'] ) || ! is_string( $image['data_base64'] ) ) {
			return new WP_Error( 'draftly_bad_image', 'Unsupported image' );
		}
		if ( strlen( $image['data_base64'] ) > 14 * 1024 * 1024 ) {
			return new WP_Error( 'draftly_image_too_large', 'Image too large' );
		}
		// base64 is how the image travels in JSON; decoding it is not obfuscation.
		$bytes = base64_decode( $image['data_base64'], true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode
		if ( false === $bytes || false === @getimagesizefromstring( $bytes ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			return new WP_Error( 'draftly_bad_image', 'Not an image' );
		}
		$name   = sanitize_file_name( 'draftly-' . $post_id . '-' . time() . '.' . $allowed[ $mime ] );
		$upload = wp_upload_bits( $name, null, $bytes );
		if ( ! empty( $upload['error'] ) ) {
			return new WP_Error( 'draftly_upload_failed', $upload['error'] );
		}
		$attachment_id = wp_insert_attachment(
			array(
				'post_mime_type' => $mime,
				'post_title'     => sanitize_text_field( get_the_title( $post_id ) ),
				'post_status'    => 'inherit',
			),
			$upload['file'],
			$post_id,
			true
		);
		if ( is_wp_error( $attachment_id ) ) {
			return $attachment_id;
		}
		require_once ABSPATH . 'wp-admin/includes/image.php';
		wp_update_attachment_metadata( $attachment_id, wp_generate_attachment_metadata( $attachment_id, $upload['file'] ) );
		return $attachment_id;
	}
}

<?php
/**
 * Removes everything the plugin stored when it is deleted from the Plugins screen.
 *
 * Draftly is asked to revoke the connection, then the connection secret and
 * any pending connect request are deleted, along with Draftly's post meta
 * (scores, status and revert pointers) and the cached auto-mode settings. Post content and WordPress revisions are left
 * alone: they are the site's own content.
 *
 * @package Draftly
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

require_once __DIR__ . '/includes/class-draftly-signature.php';
require_once __DIR__ . '/includes/class-draftly-connection.php';

/**
 * Deletes the plugin's data for the current site.
 */
function draftly_uninstall_site() {
	// Tell Draftly to revoke this site's connection (one signed request), then forget it.
	if ( get_option( 'draftly_connection' ) ) {
		Draftly_Connection::disconnect();
	}
	delete_option( 'draftly_connection' );
	delete_option( 'draftly_pending_connect' );
	delete_option( 'draftly_free_posts' );
	delete_option( 'draftly_auto_mode' );
	foreach ( array( '_draftly_scores', '_draftly_revert_revision', '_draftly_previous_content', '_draftly_previous_seo', '_draftly_state', '_draftly_optimized', '_draftly_changed_since', '_draftly_run' ) as $draftly_meta_key ) {
		delete_post_meta_by_key( $draftly_meta_key );
	}
}

if ( is_multisite() ) {
	foreach ( get_sites( array( 'fields' => 'ids' ) ) as $draftly_site_id ) {
		switch_to_blog( $draftly_site_id );
		draftly_uninstall_site();
		restore_current_blog();
	}
} else {
	draftly_uninstall_site();
}

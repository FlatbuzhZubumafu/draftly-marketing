<?php
/**
 * Reading and changing posts for Draftly. Every content change is saved with
 * wp_update_post, so WordPress keeps a revision, and the revision from just
 * before Draftly's change is remembered so it can be restored with one click.
 *
 * Each post also carries its Draftly status (mirrored from Draftly for the
 * list on Draftly > Optimize posts): no meta = Not checked, then checked,
 * optimized (edits applied, or nothing to fix) or needs_work (reverted). An
 * optimized post that is saved in WordPress afterwards is flagged "changed
 * since optimized".
 *
 * @package Draftly
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Post helpers.
 */
class Draftly_Posts {

	/** Revision id from just before Draftly's last change. */
	const META_REVERT = '_draftly_revert_revision';

	/** Fallback copy of the previous content when revisions are turned off. */
	const META_PREVIOUS = '_draftly_previous_content';

	/** Latest Draftly scores: humanVoice, readability, checked_at. */
	const META_SCORES = '_draftly_scores';

	/** SEO meta from before Draftly's last meta change. */
	const META_PREVIOUS_SEO = '_draftly_previous_seo';

	/** Draftly status: checked, optimized or needs_work. No meta = Not checked. */
	const META_STATE = '_draftly_state';

	/** Details of the last optimization: at (time), run_id, source (manual|auto), nothing_to_fix. */
	const META_OPTIMIZED = '_draftly_optimized';

	/** Set when an optimized post is saved in WordPress afterwards. */
	const META_CHANGED = '_draftly_changed_since';

	/** Auto-mode run that last changed the post (for "Revert this run"). */
	const META_RUN = '_draftly_run';

	/** Post types Draftly works with. Auto mode and the list are posts only. */
	const POST_TYPES = array( 'post' );

	/**
	 * True while Draftly itself saves a post, so the save isn't taken for an edit in WordPress.
	 *
	 * @var bool
	 */
	private static $saving = false;

	/**
	 * Hooks (front end and admin: posts can be saved from anywhere).
	 */
	public static function init() {
		add_action( 'save_post_post', array( __CLASS__, 'mark_changed' ), 10, 3 );
	}

	/**
	 * An optimized post saved in WordPress (not by Draftly) is "changed since optimized".
	 *
	 * @param int     $post_id Post id.
	 * @param WP_Post $post    Post.
	 * @param bool    $update  Existing post.
	 */
	public static function mark_changed( $post_id, $post, $update ) {
		if ( self::$saving || ! $update || wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
			return;
		}
		if ( 'optimized' === get_post_meta( $post_id, self::META_STATE, true ) ) {
			update_post_meta( $post_id, self::META_CHANGED, 1 );
		}
	}

	/**
	 * The post's Draftly status for display and filtering.
	 *
	 * @param int $post_id Post id.
	 * @return array { state: string ('not_checked'|'checked'|'optimized'|'needs_work'), changed_since: bool, optimized_at: int|null, run_id: string, source: string, nothing_to_fix: bool }
	 */
	public static function status( $post_id ) {
		$state = (string) get_post_meta( $post_id, self::META_STATE, true );
		$info  = get_post_meta( $post_id, self::META_OPTIMIZED, true );
		$info  = is_array( $info ) ? $info : array();
		return array(
			'state'          => in_array( $state, array( 'checked', 'optimized', 'needs_work' ), true ) ? $state : 'not_checked',
			'changed_since'  => 'optimized' === $state && (bool) get_post_meta( $post_id, self::META_CHANGED, true ),
			'optimized_at'   => isset( $info['at'] ) ? (int) $info['at'] : null,
			'run_id'         => (string) get_post_meta( $post_id, self::META_RUN, true ),
			'source'         => isset( $info['source'] ) ? (string) $info['source'] : '',
			'nothing_to_fix' => ! empty( $info['nothing_to_fix'] ),
		);
	}

	/**
	 * Sets the post's Draftly status.
	 *
	 * @param int    $post_id Post id.
	 * @param string $state   checked | optimized | needs_work.
	 * @param array  $args    For optimized: run_id, source (manual|auto), nothing_to_fix.
	 */
	public static function set_status( $post_id, $state, array $args = array() ) {
		if ( ! in_array( $state, array( 'checked', 'optimized', 'needs_work' ), true ) ) {
			return;
		}
		update_post_meta( $post_id, self::META_STATE, $state );
		delete_post_meta( $post_id, self::META_CHANGED );
		if ( 'optimized' === $state ) {
			$run_id = isset( $args['run_id'] ) ? preg_replace( '/[^A-Za-z0-9-]/', '', (string) $args['run_id'] ) : '';
			update_post_meta(
				$post_id,
				self::META_OPTIMIZED,
				array(
					'at'             => time(),
					'source'         => isset( $args['source'] ) && 'auto' === $args['source'] ? 'auto' : 'manual',
					'nothing_to_fix' => ! empty( $args['nothing_to_fix'] ),
				)
			);
			if ( '' !== $run_id ) {
				update_post_meta( $post_id, self::META_RUN, $run_id );
			} else {
				delete_post_meta( $post_id, self::META_RUN );
			}
		} else {
			delete_post_meta( $post_id, self::META_OPTIMIZED );
			delete_post_meta( $post_id, self::META_RUN );
		}
	}

	/**
	 * Summary of a post for lists.
	 *
	 * @param WP_Post $post            Post.
	 * @param bool    $include_content Include the rendered body.
	 * @return array
	 */
	public static function summary( WP_Post $post, $include_content = false ) {
		$out = array(
			'id'           => $post->ID,
			'type'         => $post->post_type,
			'title'        => get_the_title( $post ),
			'link'         => get_permalink( $post ),
			'status'       => $post->post_status,
			'date_gmt'     => $post->post_date_gmt,
			'modified_gmt' => $post->post_modified_gmt,
			'word_count'   => str_word_count( wp_strip_all_tags( $post->post_content ) ),
			'has_password' => '' !== (string) $post->post_password,
			'categories'   => array_map( 'intval', wp_get_post_categories( $post->ID ) ),
			'draftly'      => array_merge(
				array(
					'scores'     => self::scores( $post->ID ),
					'can_revert' => self::can_revert( $post->ID ),
				),
				self::status( $post->ID )
			),
		);
		if ( $include_content ) {
			$out['content_rendered'] = self::rendered( $post );
		}
		return $out;
	}

	/**
	 * Full post for editing.
	 *
	 * @param WP_Post $post Post.
	 * @return array
	 */
	public static function detail( WP_Post $post ) {
		return array_merge(
			self::summary( $post ),
			array(
				'content_raw'      => $post->post_content,
				'content_rendered' => self::rendered( $post ),
				'excerpt'          => $post->post_excerpt,
				'meta'             => Draftly_Seo_Meta::get( $post->ID ),
			)
		);
	}

	/**
	 * The body as visitors see it.
	 *
	 * @param WP_Post $post Post.
	 * @return string
	 */
	private static function rendered( WP_Post $post ) {
		// Core filter, so the body renders exactly as on the site.
		return apply_filters( 'the_content', $post->post_content ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound
	}

	/**
	 * Stored scores, or null.
	 *
	 * @param int $post_id Post id.
	 * @return array|null
	 */
	public static function scores( $post_id ) {
		$scores = get_post_meta( $post_id, self::META_SCORES, true );
		return is_array( $scores ) ? $scores : null;
	}

	/**
	 * Saves scores from a Draftly check or optimization.
	 *
	 * @param int   $post_id   Post id.
	 * @param array $scores    Scores.
	 * @param array $breakdown Score breakdown from Draftly (optional).
	 */
	public static function save_scores( $post_id, $scores, $breakdown = null ) {
		if ( ! is_array( $scores ) ) {
			return;
		}
		$clean = array( 'checked_at' => time() );
		foreach ( array( 'humanVoice', 'readability' ) as $key ) {
			$clean[ $key ] = isset( $scores[ $key ] ) && is_numeric( $scores[ $key ] ) ? (int) round( $scores[ $key ] ) : null;
		}
		$clean['breakdown'] = self::clean_breakdown( $breakdown );
		update_post_meta( $post_id, self::META_SCORES, $clean );
	}

	/**
	 * "What's holding this score back" from Draftly, reduced to labels and numbers.
	 *
	 * @param mixed $breakdown { humanVoice: [{label, points, count}], readability: [...] }.
	 * @return array
	 */
	public static function clean_breakdown( $breakdown ) {
		$out = array();
		foreach ( array( 'humanVoice', 'readability' ) as $key ) {
			$out[ $key ] = array();
			if ( ! is_array( $breakdown ) || ! isset( $breakdown[ $key ] ) || ! is_array( $breakdown[ $key ] ) ) {
				continue;
			}
			foreach ( array_slice( $breakdown[ $key ], 0, 12 ) as $item ) {
				if ( ! is_array( $item ) || ! isset( $item['label'] ) ) {
					continue;
				}
				$out[ $key ][] = array(
					'label'  => sanitize_text_field( (string) $item['label'] ),
					'points' => isset( $item['points'] ) ? (int) $item['points'] : 0,
					'count'  => isset( $item['count'] ) ? absint( $item['count'] ) : 0,
				);
			}
		}
		return $out;
	}

	/**
	 * The revision to revert to (the version from before Draftly's last change), or 0.
	 *
	 * @param int $post_id Post id.
	 * @return int
	 */
	public static function revert_revision( $post_id ) {
		return (int) get_post_meta( $post_id, self::META_REVERT, true );
	}

	/**
	 * Ids of posts whose last Draftly change came from this auto-mode run.
	 *
	 * @param string $run_id Run id.
	 * @return int[]
	 */
	public static function posts_in_run( $run_id ) {
		$run_id = preg_replace( '/[^A-Za-z0-9-]/', '', (string) $run_id );
		if ( '' === $run_id ) {
			return array();
		}
		$query = new WP_Query(
			array(
				'post_type'      => self::POST_TYPES,
				'post_status'    => 'any',
				'fields'         => 'ids',
				'posts_per_page' => 200, // phpcs:ignore WordPress.WP.PostsPerPage.posts_per_page_posts_per_page -- ids only; a run changes a handful of posts.
				'no_found_rows'  => true,
				'meta_key'       => self::META_RUN, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- one admin lookup, on demand.
				'meta_value'     => $run_id, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value -- one admin lookup, on demand.
			)
		);
		return array_map( 'intval', $query->posts );
	}

	/**
	 * Whether there is a Draftly change to revert.
	 *
	 * @param int $post_id Post id.
	 * @return bool
	 */
	public static function can_revert( $post_id ) {
		return (bool) get_post_meta( $post_id, self::META_REVERT, true )
			|| '' !== (string) get_post_meta( $post_id, self::META_PREVIOUS, true )
			|| is_array( get_post_meta( $post_id, self::META_PREVIOUS_SEO, true ) );
	}

	/**
	 * Remembers the current state as the point to revert to, before Draftly changes the post.
	 *
	 * @param WP_Post $post Post.
	 */
	private static function remember_before( WP_Post $post ) {
		if ( wp_revisions_enabled( $post ) ) {
			// Make sure the current content exists as a revision (it may predate revisions).
			$revision_id = wp_save_post_revision( $post->ID );
			if ( ! $revision_id ) {
				$latest      = wp_get_post_revisions(
					$post->ID,
					array(
						'numberposts' => 1,
						'orderby'     => 'ID',
						'order'       => 'DESC',
					)
				);
				$revision_id = $latest ? (int) key( $latest ) : 0;
			}
			if ( $revision_id ) {
				update_post_meta( $post->ID, self::META_REVERT, (int) $revision_id );
				return;
			}
		}
		// Revisions off: keep a copy of the body instead.
		update_post_meta( $post->ID, self::META_PREVIOUS, wp_slash( $post->post_content ) );
	}

	/**
	 * Applies an update from Draftly: any of content, title, excerpt, status,
	 * date_gmt, meta, featured_image. Only fields present are changed.
	 *
	 * @param WP_Post $post  Post.
	 * @param array   $input Fields.
	 * @return WP_Post|WP_Error
	 */
	public static function update( WP_Post $post, array $input ) {
		$fields = self::post_fields( $input, true );
		if ( is_wp_error( $fields ) ) {
			return $fields;
		}
		// Auto mode sends the modified time it read: if someone saved the post since, their version wins.
		if ( ! empty( $input['expected_modified_gmt'] ) && is_string( $input['expected_modified_gmt'] ) && $input['expected_modified_gmt'] !== $post->post_modified_gmt ) {
			return new WP_Error( 'draftly_post_changed', __( 'The post was changed while Draftly worked on it. Nothing was saved.', 'draftly' ), array( 'status' => 409 ) );
		}
		self::$saving = true;
		$result       = self::update_fields( $post, $input, $fields );
		self::$saving = false;
		if ( ! is_wp_error( $result ) && isset( $input['draftly'] ) && is_array( $input['draftly'] ) && 'optimized' === ( $input['draftly']['state'] ?? '' ) ) {
			self::set_status( $post->ID, 'optimized', $input['draftly'] );
			if ( isset( $input['draftly']['scores'] ) && is_array( $input['draftly']['scores'] ) ) {
				self::save_scores( $post->ID, $input['draftly']['scores'], $input['draftly']['breakdown'] ?? null );
			}
		}
		return $result;
	}

	/**
	 * The write itself, for update().
	 *
	 * @param WP_Post $post   Post.
	 * @param array   $input  Input.
	 * @param array   $fields wp_update_post fields.
	 * @return WP_Post|WP_Error
	 */
	private static function update_fields( WP_Post $post, array $input, array $fields ) {
		// Revert always means "undo Draftly's last change", so forget older restore points.
		delete_post_meta( $post->ID, self::META_REVERT );
		delete_post_meta( $post->ID, self::META_PREVIOUS );
		delete_post_meta( $post->ID, self::META_PREVIOUS_SEO );
		if ( isset( $fields['post_content'] ) || isset( $fields['post_title'] ) ) {
			self::remember_before( $post );
		}
		if ( $fields ) {
			$fields['ID'] = $post->ID;
			$saved        = wp_update_post( wp_slash( $fields ), true );
			if ( is_wp_error( $saved ) ) {
				return $saved;
			}
		}
		$extra = self::apply_extras( $post->ID, $input, true );
		if ( is_wp_error( $extra ) ) {
			return $extra;
		}
		return get_post( $post->ID );
	}

	/**
	 * Creates a post from Draftly (publishing a Draftly draft).
	 *
	 * @param array $input Fields.
	 * @return WP_Post|WP_Error
	 */
	public static function create( array $input ) {
		$fields = self::post_fields( $input, false );
		if ( is_wp_error( $fields ) ) {
			return $fields;
		}
		$fields['post_type'] = 'post';
		if ( empty( $fields['post_status'] ) ) {
			$fields['post_status'] = 'draft';
		}
		if ( empty( $fields['post_author'] ) ) {
			$fields['post_author'] = get_current_user_id();
		}
		$id = wp_insert_post( wp_slash( $fields ), true );
		if ( is_wp_error( $id ) ) {
			return $id;
		}
		$extra = self::apply_extras( $id, $input, false );
		if ( is_wp_error( $extra ) ) {
			return $extra;
		}
		return get_post( $id );
	}

	/**
	 * Restores the post to just before Draftly's last change.
	 *
	 * @param WP_Post $post Post.
	 * @return WP_Post|WP_Error
	 */
	public static function revert( WP_Post $post ) {
		self::$saving = true;
		$result       = self::restore( $post );
		self::$saving = false;
		if ( ! is_wp_error( $result ) ) {
			self::set_status( $post->ID, 'needs_work' );
		}
		return $result;
	}

	/**
	 * The restore itself, for revert().
	 *
	 * @param WP_Post $post Post.
	 * @return WP_Post|WP_Error
	 */
	private static function restore( WP_Post $post ) {
		$revision_id = (int) get_post_meta( $post->ID, self::META_REVERT, true );
		$previous    = get_post_meta( $post->ID, self::META_PREVIOUS, true );
		if ( $revision_id ) {
			$revision = wp_get_post_revision( $revision_id );
			if ( ! $revision || (int) $revision->post_parent !== (int) $post->ID ) {
				return new WP_Error( 'draftly_revision_missing', __( 'The earlier version is no longer available.', 'draftly' ), array( 'status' => 410 ) );
			}
			$restored = wp_restore_post_revision( $revision_id );
			if ( ! $restored || is_wp_error( $restored ) ) {
				return new WP_Error( 'draftly_revert_failed', __( 'WordPress could not restore the earlier version.', 'draftly' ), array( 'status' => 500 ) );
			}
		} elseif ( '' !== (string) $previous ) {
			$saved = wp_update_post(
				array(
					'ID'           => $post->ID,
					'post_content' => wp_slash( $previous ),
				),
				true
			);
			if ( is_wp_error( $saved ) ) {
				return $saved;
			}
		} elseif ( ! is_array( get_post_meta( $post->ID, self::META_PREVIOUS_SEO, true ) ) ) {
			return new WP_Error( 'draftly_nothing_to_revert', __( 'There is no Draftly change to revert on this post.', 'draftly' ), array( 'status' => 409 ) );
		}
		$seo = get_post_meta( $post->ID, self::META_PREVIOUS_SEO, true );
		if ( is_array( $seo ) ) {
			Draftly_Seo_Meta::set( $post->ID, $seo['title'] ?? '', $seo['description'] ?? '' );
		}
		delete_post_meta( $post->ID, self::META_REVERT );
		delete_post_meta( $post->ID, self::META_PREVIOUS );
		delete_post_meta( $post->ID, self::META_PREVIOUS_SEO );
		delete_post_meta( $post->ID, self::META_SCORES );
		return get_post( $post->ID );
	}

	/**
	 * Maps Draftly's fields to wp_insert_post fields, validating each.
	 *
	 * @param array $input     Input.
	 * @param bool  $is_update Update or create.
	 * @return array|WP_Error
	 */
	private static function post_fields( array $input, $is_update ) {
		$fields = array();
		if ( isset( $input['content'] ) ) {
			if ( ! is_string( $input['content'] ) ) {
				return new WP_Error( 'draftly_bad_content', 'content must be a string', array( 'status' => 400 ) );
			}
			// Saved as the connecting user; WordPress applies its usual filtering for that user's role.
			$fields['post_content'] = $input['content'];
		}
		if ( isset( $input['title'] ) && is_string( $input['title'] ) ) {
			$fields['post_title'] = sanitize_text_field( $input['title'] );
		}
		if ( isset( $input['excerpt'] ) && is_string( $input['excerpt'] ) ) {
			$fields['post_excerpt'] = sanitize_textarea_field( $input['excerpt'] );
		}
		if ( isset( $input['status'] ) ) {
			$status = sanitize_key( $input['status'] );
			if ( ! in_array( $status, array( 'draft', 'publish', 'pending', 'private', 'future' ), true ) ) {
				return new WP_Error( 'draftly_bad_status', 'Unsupported status', array( 'status' => 400 ) );
			}
			if ( in_array( $status, array( 'publish', 'future', 'private' ), true ) && ! current_user_can( 'publish_posts' ) ) {
				return new WP_Error( 'draftly_cannot_publish', __( 'The connected WordPress user cannot publish posts.', 'draftly' ), array( 'status' => 403 ) );
			}
			$fields['post_status'] = $status;
		}
		if ( ! empty( $input['date_gmt'] ) && is_string( $input['date_gmt'] ) ) {
			$time = strtotime( $input['date_gmt'] );
			if ( false === $time ) {
				return new WP_Error( 'draftly_bad_date', 'Invalid date_gmt', array( 'status' => 400 ) );
			}
			$fields['post_date_gmt'] = gmdate( 'Y-m-d H:i:s', $time );
			$fields['post_date']     = get_date_from_gmt( $fields['post_date_gmt'] );
			$fields['edit_date']     = true;
		}
		if ( ! $is_update ) {
			if ( ! empty( $input['slug'] ) && is_string( $input['slug'] ) ) {
				$fields['post_name'] = sanitize_title( $input['slug'] );
			}
			if ( ! empty( $input['categories'] ) && is_array( $input['categories'] ) ) {
				$fields['post_category'] = array_values( array_filter( array_map( 'absint', $input['categories'] ) ) );
			}
			if ( ! empty( $input['author'] ) ) {
				$author = absint( $input['author'] );
				if ( $author && user_can( $author, 'edit_posts' ) ) {
					$fields['post_author'] = $author;
				}
			}
		}
		return $fields;
	}

	/**
	 * SEO meta and featured image.
	 *
	 * @param int   $post_id  Post id.
	 * @param array $input    Input.
	 * @param bool  $revertable Remember the previous SEO meta for revert.
	 * @return true|WP_Error
	 */
	private static function apply_extras( $post_id, array $input, $revertable ) {
		if ( isset( $input['meta'] ) && is_array( $input['meta'] ) ) {
			$meta = $input['meta'];
			if ( $revertable ) {
				update_post_meta( $post_id, self::META_PREVIOUS_SEO, Draftly_Seo_Meta::get( $post_id ) );
			}
			$saved = Draftly_Seo_Meta::set(
				$post_id,
				isset( $meta['title'] ) && is_string( $meta['title'] ) ? $meta['title'] : null,
				isset( $meta['description'] ) && is_string( $meta['description'] ) ? $meta['description'] : null,
				isset( $meta['focus_keyword'] ) && is_string( $meta['focus_keyword'] ) ? $meta['focus_keyword'] : null
			);
			if ( is_wp_error( $saved ) ) {
				return $saved;
			}
		}
		if ( isset( $input['featured_image'] ) && is_array( $input['featured_image'] ) ) {
			$attachment = self::sideload_image( $post_id, $input['featured_image'] );
			if ( ! is_wp_error( $attachment ) ) {
				set_post_thumbnail( $post_id, $attachment );
			}
		}
		return true;
	}

	/**
	 * Saves a base64 image from Draftly to the media library.
	 *
	 * @param int   $post_id Post id.
	 * @param array $image   { mime, data_base64, filename }.
	 * @return int|WP_Error Attachment id.
	 */
	private static function sideload_image( $post_id, array $image ) {
		$allowed = array(
			'image/png'  => 'png',
			'image/jpeg' => 'jpg',
			'image/webp' => 'webp',
			'image/gif'  => 'gif',
		);
		$mime    = isset( $image['mime'] ) ? (string) $image['mime'] : '';
		if ( ! isset( $allowed[ $mime ] ) || empty( $image['data_base64'] ) || ! is_string( $image['data_base64'] ) ) {
			return new WP_Error( 'draftly_bad_image', 'Unsupported image' );
		}
		if ( strlen( $image['data_base64'] ) > 14 * 1024 * 1024 ) {
			return new WP_Error( 'draftly_image_too_large', 'Image too large' );
		}
		// base64 is how the image travels in JSON; decoding it is not obfuscation.
		$bytes = base64_decode( $image['data_base64'], true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode
		if ( false === $bytes || false === @getimagesizefromstring( $bytes ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			return new WP_Error( 'draftly_bad_image', 'Not an image' );
		}
		$name   = sanitize_file_name( 'draftly-' . $post_id . '-' . time() . '.' . $allowed[ $mime ] );
		$upload = wp_upload_bits( $name, null, $bytes );
		if ( ! empty( $upload['error'] ) ) {
			return new WP_Error( 'draftly_upload_failed', $upload['error'] );
		}
		$attachment_id = wp_insert_attachment(
			array(
				'post_mime_type' => $mime,
				'post_title'     => sanitize_text_field( get_the_title( $post_id ) ),
				'post_status'    => 'inherit',
			),
			$upload['file'],
			$post_id,
			true
		);
		if ( is_wp_error( $attachment_id ) ) {
			return $attachment_id;
		}
		require_once ABSPATH . 'wp-admin/includes/image.php';
		wp_update_attachment_metadata( $attachment_id, wp_generate_attachment_metadata( $attachment_id, $upload['file'] ) );
		return $attachment_id;
	}
}

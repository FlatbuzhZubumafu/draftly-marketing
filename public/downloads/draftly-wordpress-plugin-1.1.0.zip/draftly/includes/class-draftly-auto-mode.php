<?php
/**
 * Draftly > Settings: auto mode.
 *
 * Auto mode is off until an administrator turns it on here. When it is on,
 * Draftly works through the site's published posts a few at a time and
 * applies edits right away, at the level picked here (Safe or Full). Each
 * change is saved as a WordPress revision and can be reverted per post or per
 * run. "Run auto mode now" processes one batch without switching it on.
 *
 * The settings live on Draftly's side (Draftly enforces plans and allowances);
 * this screen sends changes with a signed request and shows the state Draftly
 * returns. Nothing here is locked in the plugin: a Free account just sees that
 * auto mode is on paid plans, because Draftly says so.
 *
 * @package Draftly
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The Settings screen and the auto-mode AJAX actions.
 */
class Draftly_Auto_Mode {

	const PAGE = 'draftly-settings';

	/**
	 * Hooks.
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 20 );
		add_action( 'admin_post_draftly_auto_mode_save', array( __CLASS__, 'handle_save' ) );
		add_action( 'wp_ajax_draftly_auto_run', array( __CLASS__, 'ajax_run' ) );
		add_action( 'wp_ajax_draftly_revert_run', array( __CLASS__, 'ajax_revert_run' ) );
		add_action( 'wp_ajax_draftly_exclude', array( __CLASS__, 'ajax_exclude' ) );
	}

	/**
	 * Draftly > Settings (manage_options).
	 */
	public static function menu() {
		add_submenu_page( Draftly_Admin::PAGE_POSTS, __( 'Draftly settings', 'draftly' ), __( 'Settings', 'draftly' ), 'manage_options', self::PAGE, array( __CLASS__, 'render' ) );
	}

	/**
	 * The state Draftly last reported, with safe defaults.
	 *
	 * @return array
	 */
	public static function state() {
		$state = Draftly_Connection::auto_mode();
		return is_array( $state ) ? $state : array(
			'eligible'              => false,
			'reason'                => '',
			'message'               => '',
			'enabled'               => false,
			'level'                 => 'safe',
			'excluded_post_ids'     => array(),
			'excluded_category_ids' => array(),
			'paused_reason'         => '',
			'disabled_globally'     => false,
			'allowance'             => '',
			'last_run'              => null,
		);
	}

	/**
	 * Whether a post is excluded from auto mode (by id or category).
	 *
	 * @param int        $post_id Post id.
	 * @param array|null $state   State (loaded when null).
	 * @return bool
	 */
	public static function is_excluded( $post_id, $state = null ) {
		$state = $state ? $state : self::state();
		if ( in_array( (int) $post_id, array_map( 'intval', (array) $state['excluded_post_ids'] ), true ) ) {
			return true;
		}
		$cats = (array) $state['excluded_category_ids'];
		return $cats && array_intersect( array_map( 'intval', wp_get_post_categories( $post_id ) ), array_map( 'intval', $cats ) );
	}

	/**
	 * Admin-post: save the auto-mode settings on Draftly's side.
	 */
	public static function handle_save() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to change Draftly settings.', 'draftly' ), 403 );
		}
		check_admin_referer( 'draftly_auto_mode_save' );
		$level   = isset( $_POST['draftly_level'] ) && 'full' === sanitize_key( wp_unslash( $_POST['draftly_level'] ) ) ? 'full' : 'safe';
		$cats    = isset( $_POST['draftly_excluded_categories'] ) ? array_values( array_filter( array_map( 'absint', (array) wp_unslash( $_POST['draftly_excluded_categories'] ) ) ) ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- each item is cast with absint.
		$payload = array(
			'enabled'               => ! empty( $_POST['draftly_enabled'] ),
			'level'                 => $level,
			'excluded_category_ids' => $cats,
		);
		$result  = Draftly_Connection::signed( 'auto_mode_settings', $payload, 20 );
		$notice  = 'saved';
		if ( is_wp_error( $result ) ) {
			$data = $result->get_error_data();
			if ( is_array( $data ) && isset( $data['auto_mode'] ) ) {
				Draftly_Connection::remember_auto_mode( $data['auto_mode'] );
			}
			$notice = 'error';
			set_transient( 'draftly_settings_error_' . get_current_user_id(), $result->get_error_message(), 60 );
		} else {
			Draftly_Connection::remember_auto_mode( $result['auto_mode'] ?? null );
		}
		wp_safe_redirect( admin_url( 'admin.php?page=' . self::PAGE . '&draftly_notice=' . $notice ) );
		exit;
	}

	/**
	 * Draftly > Settings.
	 */
	public static function render() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$conn = Draftly_Connection::get();
		if ( $conn && Draftly_Connection::is_active() ) {
			// Fresh state from Draftly each time the screen opens.
			Draftly_Connection::refresh_status();
		}
		$state = self::state();
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- display-only flag set by our own redirect.
		$notice = isset( $_GET['draftly_notice'] ) ? sanitize_key( wp_unslash( $_GET['draftly_notice'] ) ) : '';
		?>
		<div class="wrap draftly-wrap">
			<h1><?php esc_html_e( 'Draftly settings', 'draftly' ); ?></h1>
			<?php
			if ( 'saved' === $notice ) {
				echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Settings saved.', 'draftly' ) . '</p></div>';
			} elseif ( 'error' === $notice ) {
				$message = get_transient( 'draftly_settings_error_' . get_current_user_id() );
				delete_transient( 'draftly_settings_error_' . get_current_user_id() );
				echo '<div class="notice notice-error"><p>' . esc_html( $message ? $message : __( 'Draftly could not save the settings. Try again in a minute.', 'draftly' ) ) . '</p></div>';
			}
			?>
			<div id="draftly-notice" class="draftly-status" aria-live="polite"></div>
			<div class="draftly-card">
				<h2><?php esc_html_e( 'Auto mode', 'draftly' ); ?></h2>
				<?php if ( ! $conn || ! Draftly_Connection::is_active() ) : ?>
					<p>
						<?php
						printf(
							/* translators: %s: link to the Connection screen */
							esc_html__( 'Connect this site to Draftly first: %s.', 'draftly' ),
							'<a href="' . esc_url( admin_url( 'admin.php?page=' . Draftly_Admin::PAGE_CONNECTION ) ) . '">' . esc_html__( 'Draftly > Connection', 'draftly' ) . '</a>'
						);
						?>
					</p>
				<?php elseif ( empty( $state['eligible'] ) ) : ?>
					<p><?php echo esc_html( 'free_plan' === $state['reason'] || '' === $state['message'] ? __( 'Auto mode is on paid plans.', 'draftly' ) : $state['message'] ); ?></p>
					<p class="description"><?php esc_html_e( 'With auto mode, Draftly works through your posts on its own and saves each edit as a revision you can revert. Until then, Check and Optimize work post by post.', 'draftly' ); ?></p>
					<p><a class="button" href="<?php echo esc_url( Draftly_Admin::PLANS_URL ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'See plans', 'draftly' ); ?><span class="screen-reader-text"> <?php esc_html_e( '(opens in a new tab)', 'draftly' ); ?></span></a></p>
				<?php else : ?>
					<?php self::render_form( $state ); ?>
				<?php endif; ?>
			</div>
			<?php if ( $conn && Draftly_Connection::is_active() && ! empty( $state['eligible'] ) ) : ?>
				<?php self::render_last_run( $state ); ?>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * The switch, the level, category exclusions and Run auto mode now.
	 *
	 * @param array $state State.
	 */
	private static function render_form( array $state ) {
		$excluded_cats = array_map( 'intval', (array) $state['excluded_category_ids'] );
		$categories    = get_categories(
			array(
				'hide_empty' => false,
				'number'     => 200,
			)
		);
		?>
		<p><?php esc_html_e( 'When auto mode is on, Draftly checks your published posts a few at a time and applies its edits right away. Every change is saved as a WordPress revision: Revert undoes a post, and Revert this run undoes a whole batch. Manual review stays available on Optimize posts.', 'draftly' ); ?></p>
		<?php if ( 'failures' === $state['paused_reason'] ) : ?>
			<div class="notice notice-warning inline"><p><?php esc_html_e( 'Auto mode is paused: Draftly could not finish several runs in a row. Check that the site is online, then save with auto mode on to resume.', 'draftly' ); ?></p></div>
		<?php elseif ( 'allowance_used' === $state['paused_reason'] ) : ?>
			<div class="notice notice-info inline"><p><?php esc_html_e( 'This month\'s allowance is used up. Auto mode starts again with the next allowance.', 'draftly' ); ?></p></div>
		<?php endif; ?>
		<?php if ( ! empty( $state['disabled_globally'] ) ) : ?>
			<div class="notice notice-info inline"><p><?php esc_html_e( 'Draftly has paused auto mode for maintenance. Your settings are kept.', 'draftly' ); ?></p></div>
		<?php endif; ?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="draftly_auto_mode_save" />
			<?php wp_nonce_field( 'draftly_auto_mode_save' ); ?>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><?php esc_html_e( 'Auto mode', 'draftly' ); ?></th>
					<td>
						<label class="draftly-switch">
							<input type="checkbox" name="draftly_enabled" value="1" <?php checked( ! empty( $state['enabled'] ) ); ?> />
							<?php esc_html_e( 'On: apply edits to my posts automatically', 'draftly' ); ?>
						</label>
						<p class="description"><?php esc_html_e( 'Off by default. Turn it off any time; nothing changes after that.', 'draftly' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Level', 'draftly' ); ?></th>
					<td>
						<fieldset>
							<legend class="screen-reader-text"><?php esc_html_e( 'Auto mode level', 'draftly' ); ?></legend>
							<label><input type="radio" name="draftly_level" value="safe" <?php checked( 'full' !== $state['level'] ); ?> /> <strong><?php esc_html_e( 'Auto mode: Safe', 'draftly' ); ?></strong></label>
							<p class="description draftly-option-help"><?php esc_html_e( 'Sentence-level fixes only: overused AI words, stock phrasing, Title Case headings, stray exclamation points, and a missing SEO title or description.', 'draftly' ); ?></p>
							<label><input type="radio" name="draftly_level" value="full" <?php checked( 'full' === $state['level'] ); ?> /> <strong><?php esc_html_e( 'Auto mode: Full', 'draftly' ); ?></strong></label>
							<p class="description draftly-option-help"><?php esc_html_e( 'Everything Optimize suggests, including rewrites of vague or unclear sentences.', 'draftly' ); ?></p>
							<p class="description"><?php esc_html_e( 'De-AI rewrites and new links are never applied automatically.', 'draftly' ); ?></p>
						</fieldset>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Skip these categories', 'draftly' ); ?></th>
					<td>
						<fieldset class="draftly-categories">
							<legend class="screen-reader-text"><?php esc_html_e( 'Categories auto mode skips', 'draftly' ); ?></legend>
							<?php foreach ( $categories as $category ) : ?>
								<label><input type="checkbox" name="draftly_excluded_categories[]" value="<?php echo esc_attr( $category->term_id ); ?>" <?php checked( in_array( (int) $category->term_id, $excluded_cats, true ) ); ?> /> <?php echo esc_html( $category->name ); ?></label><br />
							<?php endforeach; ?>
						</fieldset>
						<p class="description"><?php esc_html_e( 'To skip a single post, use Exclude next to it on Optimize posts. Only published posts are changed; pages, drafts and password-protected posts are never touched.', 'draftly' ); ?></p>
					</td>
				</tr>
				<?php if ( '' !== (string) $state['allowance'] ) : ?>
					<tr>
						<th scope="row"><?php esc_html_e( 'Allowance left', 'draftly' ); ?></th>
						<td><?php echo esc_html( $state['allowance'] ); ?></td>
					</tr>
				<?php endif; ?>
			</table>
			<?php submit_button( __( 'Save settings', 'draftly' ) ); ?>
		</form>
		<p>
			<button type="button" class="button" id="draftly-auto-run"><?php esc_html_e( 'Run auto mode now', 'draftly' ); ?></button>
			<span class="description"><?php esc_html_e( 'Processes the next few posts once, at the level above, without switching auto mode on.', 'draftly' ); ?></span>
		</p>
		<?php
	}

	/**
	 * The last run, with Revert this run.
	 *
	 * @param array $state State.
	 */
	private static function render_last_run( array $state ) {
		$run = is_array( $state['last_run'] ?? null ) ? $state['last_run'] : null;
		?>
		<div class="draftly-card">
			<h2><?php esc_html_e( 'Last run', 'draftly' ); ?></h2>
			<?php if ( ! $run ) : ?>
				<p class="draftly-muted"><?php esc_html_e( 'Auto mode has not run on this site yet.', 'draftly' ); ?></p>
			<?php else : ?>
				<p><?php echo esc_html( self::run_summary( $run ) ); ?></p>
				<?php if ( $run['changes_applied'] > 0 && empty( $run['reverted'] ) ) : ?>
					<p><button type="button" class="button draftly-revert-run" data-run="<?php echo esc_attr( $run['id'] ); ?>"><?php esc_html_e( 'Revert this run', 'draftly' ); ?></button>
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=' . Draftly_Admin::PAGE_POSTS . '&draftly_run=' . rawurlencode( $run['id'] ) ) ); ?>"><?php esc_html_e( 'See the posts', 'draftly' ); ?></a></p>
				<?php elseif ( ! empty( $run['reverted'] ) ) : ?>
					<p class="draftly-muted"><?php esc_html_e( 'This run was reverted.', 'draftly' ); ?></p>
				<?php endif; ?>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * One line about a run, e.g. "Oct 9, 2026 3:07 pm (Safe): 3 posts checked, 5 changes applied."
	 *
	 * @param array $run Run.
	 * @return string
	 */
	public static function run_summary( array $run ) {
		$time  = strtotime( (string) ( $run['finished_at'] ? $run['finished_at'] : $run['started_at'] ) );
		$when  = $time ? wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $time ) : '';
		$level = 'full' === $run['level'] ? __( 'Full', 'draftly' ) : __( 'Safe', 'draftly' );
		$text  = sprintf(
			/* translators: 1: date and time, 2: Safe or Full, 3: posts processed, 4: changes applied */
			_n( '%1$s (%2$s): %3$s post checked, %4$s changes applied.', '%1$s (%2$s): %3$s posts checked, %4$s changes applied.', (int) $run['posts_processed'], 'draftly' ),
			$when,
			$level,
			number_format_i18n( (int) $run['posts_processed'] ),
			number_format_i18n( (int) $run['changes_applied'] )
		);
		if ( 'running' === $run['status'] ) {
			$text .= ' ' . __( 'Still running.', 'draftly' );
		}
		if ( $run['error_count'] > 0 ) {
			/* translators: %s: number of posts that failed */
			$text .= ' ' . sprintf( _n( '%s post could not be finished.', '%s posts could not be finished.', (int) $run['error_count'], 'draftly' ), number_format_i18n( (int) $run['error_count'] ) );
		}
		if ( 'allowance_used' === $run['stop_reason'] ) {
			$text .= ' ' . __( 'Stopped: the allowance is used up.', 'draftly' );
		} elseif ( 'nothing_to_do' === $run['stop_reason'] ) {
			$text .= ' ' . __( 'Nothing left to do right now.', 'draftly' );
		}
		return $text;
	}

	/**
	 * AJAX: Run auto mode now (manage_options). Draftly answers at once and works in the background.
	 */
	public static function ajax_run() {
		check_ajax_referer( Draftly_Admin::NONCE_AJAX, 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Not allowed.', 'draftly' ) ), 403 );
		}
		$result = Draftly_Connection::signed( 'auto_mode_run', array(), 20 );
		if ( is_wp_error( $result ) ) {
			$data = $result->get_error_data();
			$code = is_array( $data ) && isset( $data['http_status'] ) ? (int) $data['http_status'] : 502;
			wp_send_json_error(
				array(
					'message' => $result->get_error_message(),
					'code'    => sanitize_key( (string) $result->get_error_code() ),
				),
				$code >= 400 && $code < 600 ? $code : 502
			);
		}
		wp_send_json_success( array( 'started' => true ) );
	}

	/**
	 * AJAX: Revert this run. Reverts, here on the site, every post whose last
	 * Draftly change came from the run, then tells Draftly which posts went back.
	 */
	public static function ajax_revert_run() {
		check_ajax_referer( Draftly_Admin::NONCE_AJAX, 'nonce' );
		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_send_json_error( array( 'message' => __( 'Not allowed.', 'draftly' ) ), 403 );
		}
		$run_id   = isset( $_POST['run_id'] ) ? preg_replace( '/[^A-Za-z0-9-]/', '', sanitize_text_field( wp_unslash( $_POST['run_id'] ) ) ) : '';
		$reverted = array();
		$failed   = 0;
		foreach ( Draftly_Posts::posts_in_run( $run_id ) as $post_id ) {
			$post = get_post( $post_id );
			if ( ! $post || ! current_user_can( 'edit_post', $post_id ) ) {
				++$failed;
				continue;
			}
			$restored = Draftly_Posts::revert( $post );
			if ( is_wp_error( $restored ) ) {
				++$failed;
			} else {
				$reverted[] = $post_id;
			}
		}
		if ( $reverted || $run_id ) {
			Draftly_Connection::signed(
				'post_status',
				array(
					'run_id'            => $run_id,
					'reverted_post_ids' => $reverted,
				),
				15
			);
			Draftly_Connection::refresh_status();
		}
		wp_send_json_success(
			array(
				'reverted' => count( $reverted ),
				'failed'   => $failed,
			)
		);
	}

	/**
	 * AJAX: Exclude a post from auto mode, or include it again (row action on Optimize posts).
	 */
	public static function ajax_exclude() {
		check_ajax_referer( Draftly_Admin::NONCE_AJAX, 'nonce' );
		$post_id = isset( $_POST['post_id'] ) ? absint( wp_unslash( $_POST['post_id'] ) ) : 0;
		if ( ! $post_id || ! current_user_can( 'edit_post', $post_id ) ) {
			wp_send_json_error( array( 'message' => __( 'You cannot edit this post.', 'draftly' ) ), 403 );
		}
		$exclude = ! empty( $_POST['exclude'] );
		$result  = Draftly_Connection::signed(
			'auto_mode_settings',
			array(
				'exclude_post' => array(
					'id'       => $post_id,
					'excluded' => $exclude,
				),
			),
			15
		);
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ), 502 );
		}
		Draftly_Connection::remember_auto_mode( $result['auto_mode'] ?? null );
		wp_send_json_success( array( 'excluded' => $exclude ) );
	}
}

=== Draftly – AI Post Optimizer ===
Contributors: draftly
Tags: ai, seo, content, readability, meta description
Requires at least: 6.2
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Improve your existing posts: readability and writing that sounds like you. Approve each edit or use auto mode; every change is a revision.

== Description ==

Draftly looks at the posts you already have and tells you what to fix: hard-to-read sentences and phrasing that sounds machine-written. When you ask it to, it suggests edits in your own brand voice. You review every suggested change side by side, keep the ones you like, and Draftly saves them as a normal WordPress revision. If you change your mind, Revert puts the post back the way it was.

**What you can do from wp-admin**

* **Check** a post to get Human voice and Readability scores.
* **Optimize** a post to get suggested edits. Nothing changes until you approve.
* **Approve** only the edits you want. They are saved as a new revision.
* **Revert** restores the version from before Draftly changed the post.
* **See what is done.** Each post shows Not checked, Needs work or Optimized (with the date), and "Changed since optimized" when someone edits it afterwards. Tabs filter All, Needs work, Optimized and Excluded, and a progress line shows how many posts are optimized.
* **Auto mode (optional, paid plans).** Off until an administrator turns it on in Draftly > Settings. When it is on, Draftly works through your published posts a few at a time and applies edits right away at the level you pick: **Safe** (sentence-level fixes such as overused AI words, Title Case headings and a missing SEO title or description) or **Full** (everything Optimize suggests). Each change is a WordPress revision; Revert undoes a post and Revert this run undoes a whole batch. You can exclude posts and categories, run one batch with Run auto mode now, and turn it off any time. A weekly email lists every change.
* **SEO titles and meta descriptions** are read and written where your SEO plugin keeps them: Yoast SEO, Rank Math or All in One SEO. Without an SEO plugin, the post excerpt is used as the description.

**No passwords to copy.** Click Connect to Draftly, approve the site in your Draftly account, and you're done. The plugin never needs your WordPress password or an application password.

**Light on your site.** The plugin adds two admin screens and a few REST routes. It loads nothing on the front end of your site.

Draftly is a hosted service: the analysis and suggested edits are produced on Draftly's servers. You need a Draftly account, and a free account is created for you during connection if you don't have one. Usage limits depend on your Draftly plan and are applied by Draftly. See [what's included](https://draftly.blog/wordpress-ai-plugin).

== External services ==

This plugin connects to Draftly (https://draftly.blog), a hosted writing and SEO service run by Draftly, to analyze and improve your posts. The plugin does not contact Draftly until an administrator clicks **Connect to Draftly** on the Draftly > Connection screen.

What is sent, and when:

* **When you click Connect to Draftly:** your site address, your site's REST API address, the address of the Connection screen (so Draftly can send you back), the plugin version and the WordPress version are sent to Draftly at https://app.draftly.blog/api/wordpress-plugin, and your browser opens https://app.draftly.blog in a new tab where you sign in and approve the connection. While you approve, the plugin asks Draftly every few seconds whether the connection was approved, and then collects this site's connection key.
* **While connected, when a user clicks Check or Optimize:** that post's title, address and content are sent to Draftly, which returns scores and suggested edits.
* **When a user approves suggested edits:** the post's current content and the list of approved edits are sent to Draftly, which returns the updated content for the plugin to save.
* **When an administrator saves Draftly > Settings, clicks Run auto mode now, or uses Exclude on a post:** the auto-mode settings (on or off, Safe or Full, excluded post and category ids) or the run request are sent to Draftly. When a user reverts a post or a run, the ids of the reverted posts are sent so Draftly can mark them as needing work.
* **Every request to Draftly** includes the plugin version.
* **When an administrator opens the Connection screen:** the plugin asks Draftly for the connected account's email, plan, remaining credits and, on a free account, how many free posts are used.
* **When you disconnect or delete the plugin:** the plugin tells Draftly to revoke this site's connection.
* **Requests from Draftly to your site:** while connected, Draftly can call this plugin's REST routes (under /wp-json/draftly/v1/) to list and read posts, save edits and SEO titles/descriptions you approve in the Draftly app, publish posts you send from Draftly, and revert Draftly's changes. Every request is signed with this site's connection key and acts as the administrator who connected the site.
* **Auto mode, only after an administrator turns it on (or clicks Run auto mode now):** Draftly lists your published posts (titles, addresses, modified dates, categories, word counts), reads the posts it picks, and saves its edits and missing SEO titles/descriptions to them through the same signed REST routes. Each save is a WordPress revision. Auto mode never touches pages, drafts, private or password-protected posts, slugs, featured images or links.

No analytics or tracking data is collected by the plugin.

Draftly's [Terms and Conditions](https://www.draftly.blog/terms-and-conditions) and [Privacy Policy](https://www.draftly.blog/privacy-policy) apply to the data sent to Draftly.

== Installation ==

1. Install and activate the plugin from Plugins > Add New, or upload the `draftly` folder to `/wp-content/plugins/`.
2. Go to **Draftly > Connection** and click **Connect to Draftly**.
3. In the Draftly tab that opens, sign in or create a free account, pick the website, and click **Approve**.
4. Go to **Draftly > Optimize posts** and check or optimize a post.

== Frequently Asked Questions ==

= Does Draftly change my posts without asking? =

Not unless you turn on auto mode. By default Optimize only suggests edits, nothing is saved until you approve, and each approval is saved as a WordPress revision.

If an administrator turns on auto mode in Draftly > Settings (paid plans), Draftly applies edits automatically at the level you chose, without asking each time. Every change is still a revision you can revert, a weekly email lists them, and you can turn auto mode off at any time.

= What is the difference between Safe and Full? =

Safe applies only sentence-level fixes: overused AI words and stock phrases, hedging, em dashes and stray exclamation points, Title Case headings, and a missing SEO title or description (filled from the post title and opening). Full applies everything Optimize suggests, including rewrites of vague or unclear sentences. De-AI rewrites and new links are never applied automatically.

= How much of my plan does auto mode use? =

Each post auto mode works on uses one post optimization from your plan's monthly allowance (on main Draftly plans, one of the month's included auto mode posts). Auto mode never spends credits: when the allowance runs out it waits for the next month. It works on at most a few posts every 15 minutes, so your site is not loaded.

= How do I undo auto mode? =

Revert on a post restores the version from before Draftly's last change. Revert this run (in Draftly > Settings, or from the weekly email) does that for every post a run changed. Turning auto mode off stops further changes.

= How do I undo a change? =

Click Revert next to the post on Draftly > Optimize posts. It restores the version from just before Draftly's last change. The change is also in the post's normal revision history.

= Does the plugin need my WordPress password? =

No. The connection uses a per-site key that only this site and Draftly know. You can disconnect at any time from Draftly > Connection or from your Draftly account.

= Which SEO plugins are supported? =

Yoast SEO, Rank Math and All in One SEO (version 4 or later). Without one of them, the post excerpt is used as the meta description.

= Who can use it? =

Administrators connect and disconnect the site and change auto mode settings. Anyone who can edit a post can check, optimize, approve, revert and exclude that post.

= What does it cost? =

Connecting creates a free Draftly account. On the free account you can check and optimize up to 5 different posts (checking and optimizing the same post counts once, and you can keep working on those posts). To use Draftly on more posts, pick a plan or top up credits. Paid plans are described at https://draftly.blog/wordpress-ai-plugin. Auto mode is on paid plans. Plans set how much you can use; Draftly applies these limits on its side.

== Screenshots ==

1. Draftly > Optimize posts: status, scores and actions for each post.
2. Reviewing suggested edits before approving them.
3. Draftly > Connection.
4. Draftly > Settings: auto mode.

== Changelog ==

= 1.1.0 =
* New: auto mode (paid plans, off by default). Turn it on in Draftly > Settings and pick Auto mode: Safe or Full. Draftly applies edits to published posts a few at a time, each as a revision. Run auto mode now processes one batch without switching it on. Revert this run undoes a whole batch, and a weekly email lists every change.
* New: each post shows its Draftly status: Not checked, Needs work, Optimized (with the date; "nothing to fix" counts) or Changed since optimized. Filter tabs All, Needs work, Optimized and Excluded, and an "Optimized N of M posts" progress line.
* New: Exclude a post from auto mode from the list, or skip whole categories in Settings.
* New: click a score to see what is holding it back, with the points each issue costs.
* Optimize now also fixes exclamation points, em dash overuse and back-to-back "You" sentences, so a post with nothing else wrong can reach 100, and Readability is scored again after edits.

= 1.0.3 =
* Added a support box on the Draftly screens with the support email address, so you can send questions, bugs and feature ideas.

= 1.0.2 =
* Scores now show Human voice and Readability. The SEO score is no longer shown in the plugin.
* Free accounts: the posts screen shows how many of the 5 free posts you've used. When they're used up, the notice says so and offers See plans and Top up credits.

= 1.0.1 =
* Fixed: Check could fail with "Something went wrong" on longer posts. It now works on posts of any supported length.
* Clearer messages when something stops a Check or Optimize: what happened, whether you were charged (you never are for a run that fails), and what to do next, with Top up credits, See plans and Try again buttons.
* Each failed request shows a short reference code you can quote to Draftly support.
* After a Check or Optimize, the notice shows the credits used and what is left on your plan.
* Image captions and other shortcodes are no longer read as part of your text.

= 1.0.0 =
* First release: one-click connect, Check, Optimize with review and approval, Revert, and SEO meta for Yoast SEO, Rank Math and All in One SEO.

== Upgrade Notice ==

= 1.1.0 =
Adds optional auto mode (off until you turn it on), post status with filter tabs, and score breakdowns.

= 1.0.3 =
Adds an easy way to contact Draftly support.

= 1.0.2 =
Shows Human voice and Readability scores only, and shows free accounts how many of their 5 free posts they've used.

= 1.0.1 =
Fixes Check failing on longer posts and explains every error with a next step.

= 1.0.0 =
First release.

<?php
/**
 * Plugin Name:       Draftly – AI Post Optimizer
 * Plugin URI:        https://draftly.blog/wordpress-ai-plugin
 * Description:       Check and improve your existing posts with Draftly: readability and human-sounding writing. Review every suggested edit or turn on auto mode; every change is a new revision you can revert.
 * Version:           1.1.0
 * Requires at least: 6.2
 * Requires PHP:      7.4
 * Author:            Draftly
 * Author URI:        https://draftly.blog
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       draftly
 *
 * @package Draftly
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'DRAFTLY_VERSION', '1.1.0' );
define( 'DRAFTLY_FILE', __FILE__ );

require_once __DIR__ . '/includes/class-draftly-signature.php';
require_once __DIR__ . '/includes/class-draftly-connection.php';
require_once __DIR__ . '/includes/class-draftly-seo-meta.php';
require_once __DIR__ . '/includes/class-draftly-posts.php';
require_once __DIR__ . '/includes/class-draftly-rest.php';

Draftly_Rest::init();
Draftly_Posts::init();

if ( is_admin() ) {
	require_once __DIR__ . '/includes/class-draftly-posts-table.php';
	require_once __DIR__ . '/includes/class-draftly-admin.php';
	require_once __DIR__ . '/includes/class-draftly-auto-mode.php';
	Draftly_Admin::init();
	Draftly_Auto_Mode::init();
}
